package main

import (
	"log"
	"net/http"

	"FriendManagement/config"
	"FriendManagement/db"
	"FriendManagement/routes"

	"github.com/joho/godotenv"
)

func main() {
	if err := godotenv.Load(); err != nil {
		log.Fatal("failed to load env vars ", err)
	}

	cfg := config.Get()
	database, err := db.NewDatabase(cfg.GetDBConnStr())
	if err != nil {
		log.Fatal("Connect to database is failded")
	}
	defer db.Close(database)

	routes := routes.RegisterRoutes(database)
	log.Println("starting server ")
	http.ListenAndServe(cfg.GetAPIPort(), routes)
}
