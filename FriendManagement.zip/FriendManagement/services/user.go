package services

import (
	"FriendManagement/models"
	"FriendManagement/repositories"
)

type IUserService interface {
	CreateUser(*models.UserService) error
	IsExistedUser(string) (bool, error)
	GetUserIDByEmail(string) (int, error)
}

type UserService struct {
	IUserRepo repositories.IUserRepo
}

func (_self UserService) CreateUser(userService *models.UserService) error {
	userRepo := &models.UserRepository{
		Email: userService.Email,
	}

	err := _self.IUserRepo.CreateUser(userRepo)
	return err
}

func (_self UserService) IsExistedUser(email string) (bool, error) {
	isExsits, err := _self.IUserRepo.IsExistedUser(email)
	return isExsits, err
}

func (_self UserService) GetUserIDByEmail(email string) (int, error) {
	result, err := _self.IUserRepo.GetUserIDByEmail(email)
	return result, err
}
