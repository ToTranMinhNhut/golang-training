package handlers

import (
	"bytes"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"FriendManagement/models/api_model"

	"github.com/stretchr/testify/require"
)

func TestFriendHandler_CreateFriend(t *testing.T) {
	type mockGetUserIDByEmail struct {
		input  string
		result int
		err    error
	}
	type mockIsExistedFriend struct {
		firstUserID  int
		secondUserID int
		result       bool
		err          error
	}
	type mockIsBlockedFriend struct {
		firstUserID  int
		secondUserID int
		result       bool
		err          error
	}

	type mockCreateFriendService struct {
		input *api_model.FriendService
		err   error
	}

	testCase := []struct {
		name                    string
		requestBody             interface{}
		expResponseBody         string
		expResponseStatus       int
		mockGetFirstUserID      mockGetUserIDByEmail
		mockGetSecondUserID     mockGetUserIDByEmail
		mockIsExistedFriend     mockIsExistedFriend
		mockIsBlocked           mockIsBlockedFriend
		mockCreateFriendService mockCreateFriendService
	}{
		{
			name: "Create friend is success",
			requestBody: map[string]interface{}{
				"friends": []string{
					"andy@example.com",
					"test@example.com",
				},
			},
			expResponseBody:   "{\"success\":true}\n",
			expResponseStatus: http.StatusOK,
			mockGetFirstUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetSecondUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 2,
				err:    nil,
			},
			mockIsExistedFriend: mockIsExistedFriend{
				firstUserID:  1,
				secondUserID: 2,
				result:       false,
				err:          nil,
			},
			mockIsBlocked: mockIsBlockedFriend{
				firstUserID:  1,
				secondUserID: 2,
				result:       false,
				err:          nil,
			},
			mockCreateFriendService: mockCreateFriendService{
				input: &api_model.FriendService{
					FirstID:  1,
					SecondID: 2,
				},
				err: nil,
			},
		},
		{
			name: "Create friend failed with error",
			requestBody: map[string]interface{}{
				"friends": []string{
					"andy@example.com",
					"test@example.com",
				},
			},
			expResponseBody:   "create failed with error\n",
			expResponseStatus: http.StatusInternalServerError,
			mockGetFirstUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetSecondUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 2,
				err:    nil,
			},
			mockIsExistedFriend: mockIsExistedFriend{
				firstUserID:  1,
				secondUserID: 2,
				result:       false,
				err:          nil,
			},
			mockIsBlocked: mockIsBlockedFriend{
				firstUserID:  1,
				secondUserID: 2,
				result:       false,
				err:          nil,
			},
			mockCreateFriendService: mockCreateFriendService{
				input: &api_model.FriendService{
					FirstID:  1,
					SecondID: 2,
				},
				err: errors.New("create failed with error"),
			},
		},
		{
			name: "Decode failed",
			requestBody: map[string]interface{}{
				"friends": "test",
			},
			expResponseBody:   "json: cannot unmarshal string into Go struct field FriendHandler.friends of type []string\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "No data request body",
			requestBody: map[string]interface{}{
				"": "",
			},
			expResponseBody:   "\"friends\" is required\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "First email format invalid",
			requestBody: map[string]interface{}{
				"friends": []string{
					"andy",
					"test@example.com",
				},
			},
			expResponseBody:   "first \"email\" is not valid. (ex: \"andy@example.com\")\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "Second email format invalid",
			requestBody: map[string]interface{}{
				"friends": []string{
					"test@example.com",
					"andy",
				},
			},
			expResponseBody:   "second \"email\" is not valid. (ex: \"andy@example.com\")\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "Number of emails addresses is wrong",
			requestBody: map[string]interface{}{
				"friends": []string{
					"andy@example.com",
				},
			},
			expResponseBody:   "number of email addresses must be 2\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "Two email address must be different",
			requestBody: map[string]interface{}{
				"friends": []string{
					"andy@example.com",
					"andy@example.com",
				},
			},
			expResponseBody:   "two email addresses must be different\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "Get UserID failed with error",
			requestBody: map[string]interface{}{
				"friends": []string{
					"andy@example.com",
					"test@example.com",
				},
			},
			expResponseBody:   "get UserID failed with error\n",
			expResponseStatus: http.StatusInternalServerError,
			mockGetFirstUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 0,
				err:    errors.New("get UserID failed with error"),
			},
		},
		{
			name: "First email address's user is not exist",
			requestBody: map[string]interface{}{
				"friends": []string{
					"andy@example.com",
					"test@example.com",
				},
			},
			expResponseBody:   "the first email does not exist\n",
			expResponseStatus: http.StatusBadRequest,
			mockGetFirstUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 0,
				err:    nil,
			},
		},
		{
			name: "Second email address's user is not exist",
			requestBody: map[string]interface{}{
				"friends": []string{
					"andy@example.com",
					"test@example.com",
				},
			},
			expResponseBody:   "the second email does not exist\n",
			expResponseStatus: http.StatusBadRequest,
			mockGetFirstUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 10,
				err:    nil,
			},
			mockGetSecondUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 0,
				err:    nil,
			},
		},
		{
			name: "Check existed friend is failed with error",
			requestBody: map[string]interface{}{
				"friends": []string{
					"andy@example.com",
					"test@example.com",
				},
			},
			expResponseBody:   "check existed connection friend failed with error\n",
			expResponseStatus: http.StatusInternalServerError,
			mockGetFirstUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetSecondUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 2,
				err:    nil,
			},
			mockIsExistedFriend: mockIsExistedFriend{
				firstUserID:  1,
				secondUserID: 2,
				result:       false,
				err:          errors.New("check existed connection friend failed with error"),
			},
		},

		{
			name: "Friend is existed",
			requestBody: map[string]interface{}{
				"friends": []string{
					"andy@example.com",
					"test@example.com",
				},
			},
			expResponseBody:   "friend connection existed\n",
			expResponseStatus: http.StatusAlreadyReported,
			mockGetFirstUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetSecondUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 2,
				err:    nil,
			},
			mockIsExistedFriend: mockIsExistedFriend{
				firstUserID:  1,
				secondUserID: 2,
				result:       true,
				err:          nil,
			},
		},
		{
			name: "Check is blocked friend failed with error",
			requestBody: map[string]interface{}{
				"friends": []string{
					"andy@example.com",
					"test@example.com",
				},
			},
			expResponseBody:   "check failed with error\n",
			expResponseStatus: http.StatusInternalServerError,
			mockGetFirstUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetSecondUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 2,
				err:    nil,
			},
			mockIsExistedFriend: mockIsExistedFriend{
				firstUserID:  1,
				secondUserID: 2,
				result:       false,
				err:          nil,
			},
			mockIsBlocked: mockIsBlockedFriend{
				firstUserID:  1,
				secondUserID: 2,
				result:       false,
				err:          errors.New("check failed with error"),
			},
		},
		{
			name: "Email addresses blocked each other",
			requestBody: map[string]interface{}{
				"friends": []string{
					"andy@example.com",
					"test@example.com",
				},
			},
			expResponseBody:   "emails blocked each other\n",
			expResponseStatus: http.StatusPreconditionFailed,
			mockGetFirstUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetSecondUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 2,
				err:    nil,
			},
			mockIsExistedFriend: mockIsExistedFriend{
				firstUserID:  1,
				secondUserID: 2,
				result:       false,
				err:          nil,
			},
			mockIsBlocked: mockIsBlockedFriend{
				firstUserID:  1,
				secondUserID: 2,
				result:       true,
				err:          nil,
			},
		},
	}
	for _, tc := range testCase {
		t.Run(tc.name, func(t *testing.T) {
			mockFriendService := new(MockFriendService)
			mockUserService := new(MockUserService)

			mockUserService.On("GetUserIDByEmail", tc.mockGetFirstUserID.input).
				Return(tc.mockGetFirstUserID.result, tc.mockGetFirstUserID.err)

			mockUserService.On("GetUserIDByEmail", tc.mockGetSecondUserID.input).
				Return(tc.mockGetSecondUserID.result, tc.mockGetSecondUserID.err)

			mockFriendService.On("IsExistedFriend", tc.mockIsExistedFriend.firstUserID, tc.mockIsExistedFriend.secondUserID).
				Return(tc.mockIsExistedFriend.result, tc.mockIsExistedFriend.err)

			mockFriendService.On("IsBlockedFriend", tc.mockIsBlocked.firstUserID, tc.mockIsBlocked.secondUserID).
				Return(tc.mockIsBlocked.result, tc.mockIsBlocked.err)

			mockFriendService.On("CreateFriend", tc.mockCreateFriendService.input).
				Return(tc.mockCreateFriendService.err)

			friendHandler := FriendHandler{
				IUserService:   mockUserService,
				IFriendService: mockFriendService,
			}

			requestBody, err := json.Marshal(tc.requestBody)
			if err != nil {
				t.Error(err)
			}

			request, err := http.NewRequest(http.MethodPost, "/friend/create", bytes.NewBuffer(requestBody))
			if err != nil {
				t.Error(err)
			}

			responseRecorder := httptest.NewRecorder()
			handler := http.HandlerFunc(friendHandler.CreateFriend)
			handler.ServeHTTP(responseRecorder, request)

			require.Equal(t, tc.expResponseStatus, responseRecorder.Code)
			require.Equal(t, tc.expResponseBody, responseRecorder.Body.String())
		})
	}
}

func TestFriendSerive_GetFriendsByEmail(t *testing.T) {
	type mockGetUserIDByEmail struct {
		input  string
		result int
		err    error
	}

	type mockGetFriendsByID struct {
		input  int
		result []string
		err    error
	}
	testCases := []struct {
		name                 string
		requestBody          interface{}
		expResponseBody      string
		expResponseStatus    int
		mockGetUserIDByEmail mockGetUserIDByEmail
		mockGetFriendsByID   mockGetFriendsByID
	}{
		{
			name: "Success request",
			requestBody: map[string]interface{}{
				"email": "andy@example.com",
			},
			expResponseBody:   "{\"success\":true,\"friends\":[\"andy@example.com\"],\"count\":1}\n",
			expResponseStatus: http.StatusOK,
			mockGetUserIDByEmail: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetFriendsByID: mockGetFriendsByID{
				input: 1,
				result: []string{
					"andy@example.com",
				},
				err: nil,
			},
		},
		{
			name: "Get friends list failed with error",
			requestBody: map[string]interface{}{
				"email": "andy@example.com",
			},
			expResponseBody:   "get friends list failed with error\n",
			expResponseStatus: http.StatusInternalServerError,
			mockGetUserIDByEmail: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetFriendsByID: mockGetFriendsByID{
				input:  1,
				result: nil,
				err:    errors.New("get friends list failed with error"),
			},
		},
		{
			name: "Validate request body failed",
			requestBody: map[string]interface{}{
				"email": "",
			},
			expResponseBody:   "\"email\" is required\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "Email request format is not valid",
			requestBody: map[string]interface{}{
				"email": "andy",
			},
			expResponseBody:   "\"email\" format is not valid. (ex: \"andy@example.com\")\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "Get UserID failed with error",
			requestBody: map[string]interface{}{
				"email": "andy@example.com",
			},
			expResponseBody:   "get UserID failed with error\n",
			expResponseStatus: http.StatusInternalServerError,
			mockGetUserIDByEmail: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 0,
				err:    errors.New("get UserID failed with error"),
			},
		},
		{
			name: "Get UserID return not exist",
			requestBody: map[string]interface{}{
				"email": "andy@example.com",
			},
			expResponseBody:   "email does not exist\n",
			expResponseStatus: http.StatusBadRequest,
			mockGetUserIDByEmail: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 0,
				err:    nil,
			},
		},
	}
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockUserService := new(MockUserService)
			mockFriendService := new(MockFriendService)

			mockUserService.On("GetUserIDByEmail", tc.mockGetUserIDByEmail.input).
				Return(tc.mockGetUserIDByEmail.result, tc.mockGetUserIDByEmail.err)
			mockFriendService.On("GetFriendsByID", tc.mockGetFriendsByID.input).
				Return(tc.mockGetFriendsByID.result, tc.mockGetFriendsByID.err)

			friendHandler := FriendHandler{
				IUserService:   mockUserService,
				IFriendService: mockFriendService,
			}

			requestBody, err := json.Marshal(tc.requestBody)
			if err != nil {
				t.Error(err)
			}

			req, err := http.NewRequest(http.MethodGet, "/friend/friendlist", bytes.NewBuffer(requestBody))
			if err != nil {
				t.Error(err)
			}

			responseRecorder := httptest.NewRecorder()
			handler := http.HandlerFunc(friendHandler.GetFriendsByEmail)
			handler.ServeHTTP(responseRecorder, req)

			require.Equal(t, tc.expResponseStatus, responseRecorder.Code)
			require.Equal(t, tc.expResponseBody, responseRecorder.Body.String())
		})
	}
}

func TestFriendHander_GetCommonFriendsByEmails(t *testing.T) {
	type mockGetUserIDByEmail struct {
		input  string
		result int
		err    error
	}

	type mockGetCommonFriendsByIDs struct {
		input  []int
		result []string
		err    error
	}
	testCases := []struct {
		name                       string
		requestBody                interface{}
		expResponseBody            string
		expResponseStatus          int
		mockGetFirstUserIDByEmail  mockGetUserIDByEmail
		mockGetSecondUserIDByEmail mockGetUserIDByEmail
		mockGetCommonFriendList    mockGetCommonFriendsByIDs
	}{
		{
			name: "Get Success",
			requestBody: map[string]interface{}{
				"friends": []string{
					"andy@example.com",
					"test@example.com",
				},
			},
			expResponseBody:   "{\"success\":true,\"friends\":[\"andy@example.com\",\"test@example.com\"],\"count\":2}\n",
			expResponseStatus: http.StatusOK,
			mockGetFirstUserIDByEmail: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetSecondUserIDByEmail: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 2,
				err:    nil,
			},
			mockGetCommonFriendList: mockGetCommonFriendsByIDs{
				input: []int{1, 2},
				result: []string{
					"andy@example.com",
					"test@example.com",
				},
				err: nil,
			},
		},
		{
			name: "Get common friend list failed with error",
			requestBody: map[string]interface{}{
				"friends": []string{
					"andy@example.com",
					"test@example.com",
				},
			},
			expResponseBody:   "get common friend list failed with error\n",
			expResponseStatus: http.StatusInternalServerError,
			mockGetFirstUserIDByEmail: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetSecondUserIDByEmail: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 2,
				err:    nil,
			},
			mockGetCommonFriendList: mockGetCommonFriendsByIDs{
				input:  []int{1, 2},
				result: nil,
				err:    errors.New("get common friend list failed with error"),
			},
		},
		{
			name: "Validate request body failed",
			requestBody: map[string]interface{}{
				"friends": "././",
			},
			expResponseBody:   "json: cannot unmarshal string into Go struct field FriendHandler.friends of type []string\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "No data request body",
			requestBody: map[string]interface{}{
				"": "",
			},
			expResponseBody:   "\"friends\" is required\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "Number of email is wrong",
			requestBody: map[string]interface{}{
				"friends": []string{
					"abc",
				},
			},
			expResponseBody:   "number of email addresses must be 2\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "First email format invalid",
			requestBody: map[string]interface{}{
				"friends": []string{
					"andy",
					"test@example.com",
				},
			},
			expResponseBody:   "first \"email\" is not valid. (ex: \"andy@example.com\")\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "Second email format invalid",
			requestBody: map[string]interface{}{
				"friends": []string{
					"test@gmail.com",
					"andy",
				},
			},
			expResponseBody:   "second \"email\" is not valid. (ex: \"andy@example.com\")\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "Get UserID by email failed with error",
			requestBody: map[string]interface{}{
				"friends": []string{
					"andy@example.com",
					"test@example.com",
				},
			},
			expResponseBody:   "get userID failed with error\n",
			expResponseStatus: http.StatusInternalServerError,
			mockGetFirstUserIDByEmail: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 0,
				err:    errors.New("get userID failed with error"),
			},
		},
		{
			name: "First email is not exist",
			requestBody: map[string]interface{}{
				"friends": []string{
					"andy@example.com",
					"test@example.com",
				},
			},
			expResponseBody:   "the first email does not exist\n",
			expResponseStatus: http.StatusBadRequest,
			mockGetFirstUserIDByEmail: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 0,
				err:    nil,
			},
			mockGetCommonFriendList: mockGetCommonFriendsByIDs{},
		},
		{
			name: "Second email is not exist",
			requestBody: map[string]interface{}{
				"friends": []string{
					"andy@example.com",
					"test@example.com",
				},
			},
			expResponseBody:   "the second email does not exist\n",
			expResponseStatus: http.StatusBadRequest,
			mockGetFirstUserIDByEmail: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetSecondUserIDByEmail: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 0,
				err:    nil,
			},
		},
		{
			name: "Two email must different each other",
			requestBody: map[string]interface{}{
				"friends": []string{
					"andy@example.com",
					"andy@example.com",
				},
			},
			expResponseBody:   "two email addresses must be different\n",
			expResponseStatus: http.StatusBadRequest,
			mockGetFirstUserIDByEmail: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetSecondUserIDByEmail: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
		},
	}
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			//Given
			mockUserService := new(MockUserService)
			mockFriendService := new(MockFriendService)

			mockUserService.On("GetUserIDByEmail", tc.mockGetFirstUserIDByEmail.input).
				Return(tc.mockGetFirstUserIDByEmail.result, tc.mockGetFirstUserIDByEmail.err)
			mockUserService.On("GetUserIDByEmail", tc.mockGetSecondUserIDByEmail.input).
				Return(tc.mockGetSecondUserIDByEmail.result, tc.mockGetSecondUserIDByEmail.err)

			mockFriendService.On("GetCommonFriendsByIDs", tc.mockGetCommonFriendList.input).
				Return(tc.mockGetCommonFriendList.result, tc.mockGetCommonFriendList.err)

			handlers := FriendHandler{
				IUserService:   mockUserService,
				IFriendService: mockFriendService,
			}

			requestBody, err := json.Marshal(tc.requestBody)
			if err != nil {
				t.Error(err)
			}
			//When
			req, err := http.NewRequest(http.MethodGet, "/friend/commonfriends", bytes.NewBuffer(requestBody))
			if err != nil {
				t.Error(err)
			}

			responseRecorder := httptest.NewRecorder()
			handler := http.HandlerFunc(handlers.GetCommonFriendsByEmails)
			handler.ServeHTTP(responseRecorder, req)

			//Then
			require.Equal(t, tc.expResponseStatus, responseRecorder.Code)
			require.Equal(t, tc.expResponseBody, responseRecorder.Body.String())
		})
	}
}

func TestFriendHandler_GetEmailsReceiveUpdate(t *testing.T) {
	type mockGetUserIDByEmail struct {
		input  string
		result int
		err    error
	}

	type mockGetEmailsReceiveUpdate struct {
		senderID int
		text     string
		result   []string
		err      error
	}

	testCases := []struct {
		name                       string
		requestBody                interface{}
		expResponseBody            string
		expResponseStatus          int
		mockGetSenderUser          mockGetUserIDByEmail
		mockGetEmailsReceiveUpdate mockGetEmailsReceiveUpdate
	}{
		{
			name: "Get email is success",
			requestBody: map[string]interface{}{
				"sender": "andy@example.com",
				"text":   "hello example@example.com",
			},
			expResponseBody:   "{\"success\":true,\"recipients\":[\"test@example.com\",\"example@example.com\"]}\n",
			expResponseStatus: http.StatusOK,
			mockGetSenderUser: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetEmailsReceiveUpdate: mockGetEmailsReceiveUpdate{
				senderID: 1,
				text:     "hello example@example.com",
				result:   []string{"test@example.com", "example@example.com"},
				err:      nil,
			},
		},
		{
			name: "Get email list receive updates failed with error",
			requestBody: map[string]interface{}{
				"sender": "andy@example.com",
				"text":   "hello example@example.com",
			},
			expResponseBody:   "failed with error\n",
			expResponseStatus: http.StatusInternalServerError,
			mockGetSenderUser: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetEmailsReceiveUpdate: mockGetEmailsReceiveUpdate{
				senderID: 1,
				text:     "hello example@example.com",
				result:   nil,
				err:      errors.New("failed with error"),
			},
		},
		{
			name: "decode request body failed",
			requestBody: map[string]interface{}{
				"sender": 1,
			},
			expResponseBody:   "json: cannot unmarshal number into Go struct field EmailReceiveUpdateHandler.sender of type string\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "Body no data",
			requestBody: map[string]interface{}{
				"": "",
			},
			expResponseBody:   "\"sender\" is required\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "No text",
			requestBody: map[string]interface{}{
				"sender": "andy@example.com",
			},
			expResponseBody:   "\"text\" is required\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "sender email is invalid",
			requestBody: map[string]interface{}{
				"sender": "abc",
				"text":   "abc",
			},
			expResponseBody:   "\"sender\" is not valid. (ex: \"andy@example.com\")\n",
			expResponseStatus: http.StatusBadRequest,
		},
	}
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockUserService := new(MockUserService)
			mockFriendService := new(MockFriendService)

			mockUserService.On("GetUserIDByEmail", tc.mockGetSenderUser.input).
				Return(tc.mockGetSenderUser.result, tc.mockGetSenderUser.err)

			mockFriendService.On("GetEmailsReceiveUpdate", tc.mockGetEmailsReceiveUpdate.senderID, tc.mockGetEmailsReceiveUpdate.text).
				Return(tc.mockGetEmailsReceiveUpdate.result, tc.mockGetEmailsReceiveUpdate.err)

			friendHandler := FriendHandler{
				IUserService:   mockUserService,
				IFriendService: mockFriendService,
			}

			requestBody, err := json.Marshal(tc.requestBody)
			if err != nil {
				t.Error(err)
			}

			// When
			req, err := http.NewRequest(http.MethodGet, "/friends/emailrecevies", bytes.NewBuffer(requestBody))
			if err != nil {
				t.Error(err)
			}
			responseRecorder := httptest.NewRecorder()
			handler := http.HandlerFunc(friendHandler.GetEmailsReceiveUpdate)
			handler.ServeHTTP(responseRecorder, req)

			require.Equal(t, tc.expResponseStatus, responseRecorder.Code)
			require.Equal(t, tc.expResponseBody, responseRecorder.Body.String())
		})
	}
}
