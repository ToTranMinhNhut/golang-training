package repositories

import (
	"errors"
	"testing"

	"github.com/stretchr/testify/require"

	"FriendManagement/models/api_model"
	"FriendManagement/testhelpers"
)

func TestBlockingRepo_CreateBlocking(t *testing.T) {
	testCases := []struct {
		name        string
		input       *api_model.BlockingRepository
		expError    error
		preparePath string
	}{
		{
			name: "Create success",
			input: &api_model.BlockingRepository{
				Requestor: 1,
				Target:    2,
			},
			expError:    nil,
			preparePath: "../testhelpers/data_dump/blocking/truncate_blocking.sql",
		},
		{
			name: "Create blocking failed with error",
			input: &api_model.BlockingRepository{
				Requestor: 1,
				Target:    2,
			},

			expError:    errors.New("orm: unable to insert into blocks: pq: duplicate key value violates unique constraint \"constraint_blocking\""),
			preparePath: "../testhelpers/data_dump/blocking/blocking.sql",
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockDB := testhelpers.ConnectDB()
			testhelpers.PrepareDBForTest(mockDB, tc.preparePath)

			blockingRepo := BlockingRepo{
				Db: mockDB,
			}

			err := blockingRepo.CreateBlocking(tc.input)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestBlockingRepo_IsExistedBlocking(t *testing.T) {
	testCases := []struct {
		name           string
		input          []int
		expectedResult bool
		expectedErr    error
		preparePath    string
	}{
		{
			name:           "Blocking is not exist",
			input:          []int{2, 1},
			expectedResult: false,
			expectedErr:    nil,
			preparePath:    "../testhelpers/data_dump/blocking/blocking.sql",
		},
		{
			name:           "Blocking existed",
			input:          []int{1, 2},
			expectedResult: true,
			expectedErr:    nil,
			preparePath:    "../testhelpers/data_dump/blocking/blocking.sql",
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockDB := testhelpers.ConnectDB()
			testhelpers.PrepareDBForTest(mockDB, tc.preparePath)

			blockingRepo := BlockingRepo{
				Db: mockDB,
			}

			// When
			result, err := blockingRepo.IsExistedBlocking(tc.input[0], tc.input[1])

			// Then
			if tc.expectedErr != nil {
				require.EqualError(t, err, tc.expectedErr.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expectedResult, result)
			}
		})
	}
}
