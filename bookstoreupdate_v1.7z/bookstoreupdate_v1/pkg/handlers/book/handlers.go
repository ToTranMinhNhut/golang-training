package book

import (
	"net/http"
	"strconv"

	"bookstoreupdate/internal/models"
	"bookstoreupdate/internal/service/bookservice"
	"bookstoreupdate/pkg/errors"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/render"
)

type BookHander struct {
	IBookService bookservice.IBookService
}

func (_self *BookHander) CreateBook(w http.ResponseWriter, r *http.Request) {
	book := &models.Book{}
	if err := render.Bind(r, book); err != nil {
		render.Render(w, r, errors.ErrBadRequest)
	}

	if err := _self.IBookService.CreateBook(book); err != nil {
		render.Render(w, r, errors.ErrorRenderer(err))
	}

	if err := render.Render(w, r, book); err != nil {
		render.Render(w, r, errors.ServerErrorRenderer(err))
	}
}

func (_self *BookHander) GetBook(w http.ResponseWriter, r *http.Request) {
	BookId := chi.URLParam(r, "bookid")
	id, err := strconv.Atoi(BookId)
	if err != nil {
		render.Render(w, r, errors.ErrorRenderer(err))
	}

	book, err := _self.IBookService.GetBook(id)
	if err != nil {
		if err == errors.ErrNoMatch {
			render.Render(w, r, errors.ErrNotFound)
		} else {
			render.Render(w, r, errors.ErrorRenderer(err))
		}
	}
	if err := render.Render(w, r, &book); err != nil {
		render.Render(w, r, errors.ServerErrorRenderer(err))
	}
}
