package handlers

import (
	"FriendManagement/models/api_model"

	"github.com/stretchr/testify/mock"
)

type MockFriendService struct {
	mock.Mock
}

func (_self *MockFriendService) CreateFriend(service *api_model.FriendService) error {
	args := _self.Called(service)
	var r error
	if args.Get(0) != nil {
		r = args.Get(0).(error)
	}
	return r
}

func (_self *MockFriendService) IsExistedFriend(firstUserID int, secondUserID int) (bool, error) {
	args := _self.Called(firstUserID, secondUserID)
	r1 := args.Get(0).(bool)
	var r2 error
	if args.Get(1) != nil {
		r2 = args.Get(1).(error)
	}
	return r1, r2
}

func (_self *MockFriendService) IsBlockedFriend(firstUserID int, secondUserID int) (bool, error) {
	args := _self.Called(firstUserID, secondUserID)
	r1 := args.Get(0).(bool)
	var r2 error
	if args.Get(1) != nil {
		r2 = args.Get(1).(error)
	}
	return r1, r2
}

func (_self *MockFriendService) GetFriendsByID(id int) ([]string, error) {
	args := _self.Called(id)
	r1 := args.Get(0).([]string)
	var r2 error
	if args.Get(1) != nil {
		r2 = args.Get(1).(error)
	}
	return r1, r2
}

func (_self *MockFriendService) GetCommonFriendsByIDs(IDs []int) ([]string, error) {
	args := _self.Called(IDs)
	r1 := args.Get(0).([]string)
	var r2 error
	if args.Get(1) != nil {
		r2 = args.Get(1).(error)
	}
	return r1, r2
}

func (_self *MockFriendService) GetEmailsReceiveUpdate(senderID int, text string) ([]string, error) {
	args := _self.Called(senderID, text)
	r1 := args.Get(0).([]string)
	var r2 error
	if args.Get(1) != nil {
		r2 = args.Get(1).(error)
	}
	return r1, r2
}
