package models

import (
	"errors"

	"FriendManagement/utils"
)

type UserHandler struct {
	Email string `json:"email"`
}

const EmailRegex = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$"

func (_self UserHandler) Validate() error {
	if _self.Email == "" {
		return errors.New("\"email\" is required")
	}

	isValid, err := utils.IsValidEmail(_self.Email)
	if err != nil || !isValid {
		return errors.New("\"email\"" + _self.Email + " format is not valid. (ex: \"andy@example.com\")")
	}

	return nil
}

type UserService struct {
	Email string `json:"email"`
}

type UserRepository struct {
	Email string `json:"email"`
}

type SuccessResponse struct {
	Success bool `json:"success"`
}
