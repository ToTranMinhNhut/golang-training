package repositories

import (
	"FriendManagement/models"
	"context"
	"database/sql"
	"log"
)

type IUserRepo interface {
	CreateUser(*models.UserRepository) error
	IsExistedUser(string) (bool, error)
}

type UserRepo struct {
	Db *sql.DB
}

func (_self UserRepo) CreateUser(user *models.UserRepository) error {
	ctx := context.Background()
	tx, err := _self.Db.BeginTx(ctx, nil)
	if err != nil {
		log.Fatal(err)
	}
	query := `INSERT INTO users (email) VALUES ($1)`
	_, err = tx.Exec(query, user.Email)
	if err != nil {
		return err
	}

	tx.Commit()
	return nil
}

func (_self UserRepo) IsExistedUser(email string) (bool, error) {
	query := `SELECT EXISTS (SELECT true FROM users WHERE email=$1)`
	var existed bool
	err := _self.Db.QueryRow(query, email).Scan(&existed)
	if err != nil {
		return false, err
	}
	if existed {
		return true, nil
	}
	return false, nil
}
