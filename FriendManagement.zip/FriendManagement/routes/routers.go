package routes

import (
	"database/sql"

	"FriendManagement/handlers"
	"FriendManagement/repositories"
	"FriendManagement/services"

	"github.com/go-chi/chi/v5"
)

func RegisterRoutes(db *sql.DB) *chi.Mux {
	route := chi.NewRouter()

	route.Route("/user", func(route chi.Router) {
		userHandler := handlers.UserHandler{
			IUserService: services.UserService{
				IUserRepo: repositories.UserRepo{
					Db: db,
				},
			},
		}
		route.Post("/create", userHandler.CreateUser)
	})

	route.Route("/friend", func(route chi.Router) {
		friendHandler := handlers.FriendHandler{
			IUserService: services.UserService{
				IUserRepo: repositories.UserRepo{
					Db: db,
				},
			},
			IFriendService: services.FriendService{
				IFriendRepo: repositories.FriendRepo{
					Db: db,
				},
				IUserRepo: repositories.UserRepo{
					Db: db,
				},
			},
		}
		route.Post("/create", friendHandler.CreateFriend)
		route.Get("/friendlist", friendHandler.GetFriendsByEmail)
		route.Get("/commonfriends", friendHandler.GetCommonFriendsByEmails)
		route.Get("/emailrecevies", friendHandler.GetEmailsReceiveUpdate)
	})

	route.Route("/subscription", func(route chi.Router) {
		subscriptionHandler := handlers.SubscriptionHandler{
			ISubscriptionService: services.SubscriptionService{
				ISubscriptionRepo: repositories.SubscriptionRepo{
					Db: db,
				},
			},
			IUserService: services.UserService{
				IUserRepo: repositories.UserRepo{
					Db: db,
				},
			},
		}
		route.Post("/create", subscriptionHandler.CreateSubscription)
	})

	route.Route("/blocking", func(route chi.Router) {
		blockingHandler := handlers.BlockingHandler{
			IBlockingService: services.BlockingService{
				IBlockingRepo: repositories.BlockingRepo{
					Db: db,
				},
			},
			IUserService: services.UserService{
				IUserRepo: repositories.UserRepo{
					Db: db,
				},
			},
		}
		route.Post("/create", blockingHandler.CreateBlocking)
	})

	return route
}
