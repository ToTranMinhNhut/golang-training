package errors

import (
	"bookstoreupdate/cmd/book/errors"
	"net/http"

	"github.com/go-chi/render"
)

func MethodNotAllowedHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-type", "application/json")
	w.WriteHeader(405)
	render.Render(w, r, errors.ErrMethodNotAllowed)
}
func NotFoundHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-type", "application/json")
	w.WriteHeader(400)
	render.Render(w, r, errors.ErrNotFound)
}
