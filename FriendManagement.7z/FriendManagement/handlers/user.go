package handlers

import (
	"FriendManagement/models"
	"FriendManagement/services"
	"encoding/json"
	"errors"
	"net/http"
)

type UserHandler struct {
	IUserService services.IUserService
}

func (_self *UserHandler) CreateUser(w http.ResponseWriter, r *http.Request) {
	//Decode request body
	UserHandler := models.UserHandler{}
	if err := json.NewDecoder(r.Body).Decode(&UserHandler); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	if err := UserHandler.Validate(); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	if statusCode, err := _self.IsExistedUser(UserHandler.Email); err != nil {
		http.Error(w, err.Error(), statusCode)
		return
	}

	userService := &models.UserService{
		Email: UserHandler.Email,
	}

	if err := _self.IUserService.CreateUser(userService); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	//Response
	json.NewEncoder(w).Encode(&models.SuccessResponse{
		Success: true,
	})
}

func (_self *UserHandler) IsExistedUser(email string) (int, error) {
	//Call services
	existed, err := _self.IUserService.IsExistedUser(email)
	if err != nil {
		return http.StatusInternalServerError, err
	}
	if existed {
		return http.StatusAlreadyReported, errors.New("this email address existed")
	}
	return 0, nil
}
