package models

import (
	"fmt"
	"net/http"
)

type Book struct {
	BookId int16  `json:"bookid"`
	Title  string `json:"title"`
	Author string `json:"author"`
	Price  int64  `json:"price"`
}

func (i *Book) Bind(r *http.Request) error {
	if i.Title == "" {
		return fmt.Errorf("title is a required field")
	}
	return nil
}
func (*Book) Render(w http.ResponseWriter, r *http.Request) error {
	return nil
}
