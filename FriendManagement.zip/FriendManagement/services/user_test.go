package services

import (
	"FriendManagement/models"
	"errors"
	"testing"

	"github.com/stretchr/testify/require"
)

func TestUserSerice_CreateUser(t *testing.T) {
	testCases := []struct {
		name              string
		input             *models.UserService
		mockUserRepoInput *models.UserRepository
		mockRepoErr       error
		expError          error
	}{
		{
			name: "Create user success",
			input: &models.UserService{
				Email: "andy@example.com",
			},
			mockUserRepoInput: &models.UserRepository{
				Email: "andy@example.com",
			},
			mockRepoErr: nil,
			expError:    nil,
		},
		{
			name: "Create user failed with error",
			input: &models.UserService{
				Email: "andy@example.com",
			},
			mockUserRepoInput: &models.UserRepository{
				Email: "andy@example.com",
			},
			mockRepoErr: errors.New("create user failed with error"),
			expError:    errors.New("create user failed with error"),
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			//Given
			mockUserRepo := new(MockUserRepo)

			mockUserRepo.On("CreateUser", tc.mockUserRepoInput).
				Return(tc.mockRepoErr)

			userService := UserService{
				IUserRepo: mockUserRepo,
			}

			//When
			err := userService.CreateUser(tc.input)

			//Then
			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestUserSerice_IsExistedUser(t *testing.T) {
	testCases := []struct {
		name              string
		input             string
		expResult         bool
		expError          error
		mockUserRepoInput string
		mockUserResult    bool
		mockUserErr       error
	}{
		{
			name:              "Check existed success",
			input:             "andy@example.com",
			expResult:         true,
			expError:          nil,
			mockUserRepoInput: "andy@example.com",
			mockUserResult:    true,
			mockUserErr:       nil,
		}, {
			name:              "Check existed user failed with error",
			input:             "andy@example.com",
			expResult:         false,
			expError:          errors.New("check existed failed with error"),
			mockUserRepoInput: "andy@example.com",
			mockUserResult:    false,
			mockUserErr:       errors.New("check existed failed with error"),
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockUserRepo := new(MockUserRepo)
			mockUserRepo.On("IsExistedUser", tc.mockUserRepoInput).Return(tc.mockUserResult, tc.mockUserErr)

			userService := UserService{
				IUserRepo: mockUserRepo,
			}

			isExisted, err := userService.IsExistedUser(tc.input)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expResult, isExisted)
			}
		})
	}
}

func TestUserSerice_GetUserIDByEmail(t *testing.T) {
	testCases := []struct {
		name              string
		input             string
		expResult         int
		expError          error
		mockUserRepoInput string
		mockUserResult    int
		mockUserError     error
	}{
		{
			name:              "Check existed success",
			input:             "andy@example.com",
			expResult:         10,
			expError:          nil,
			mockUserRepoInput: "andy@example.com",
			mockUserResult:    10,
			mockUserError:     nil,
		},
		{
			name:              "Get failed with error",
			input:             "andy@example.com",
			expResult:         0,
			expError:          errors.New("get failed with error"),
			mockUserRepoInput: "andy@example.com",
			mockUserResult:    0,
			mockUserError:     errors.New("get failed with error"),
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockUserRepo := new(MockUserRepo)
			mockUserRepo.On("GetUserIDByEmail", tc.mockUserRepoInput).Return(tc.mockUserResult, tc.mockUserError)

			userService := UserService{
				IUserRepo: mockUserRepo,
			}
			userID, err := userService.GetUserIDByEmail(tc.input)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expResult, userID)
			}
		})
	}
}
