package models

type FriendHandler struct {
}
