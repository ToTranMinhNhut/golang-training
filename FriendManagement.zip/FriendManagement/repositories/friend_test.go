package repositories

import (
	"errors"
	"testing"

	"FriendManagement/models/api_model"
	"FriendManagement/testhelpers"

	"github.com/stretchr/testify/require"
)

func TestFriendRepo_CreateFriend(t *testing.T) {
	testCases := []struct {
		name        string
		input       *api_model.FriendRepository
		expError    error
		preparePath string
	}{
		{
			name: "Create friend is success",
			input: &api_model.FriendRepository{
				FirstID:  1,
				SecondID: 2,
			},
			expError:    nil,
			preparePath: "../testhelpers/data_dump/friend/truncate_friends.sql",
		},
		{
			name: "Create failed with error",
			input: &api_model.FriendRepository{
				FirstID:  1,
				SecondID: 2,
			},
			expError:    errors.New("orm: unable to insert into friends: pq: duplicate key value violates unique constraint \"constraint_friends\""),
			preparePath: "../testhelpers/data_dump/friend/friend.sql",
		},
	}
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockDB := testhelpers.ConnectDB()
			testhelpers.PrepareDBForTest(mockDB, tc.preparePath)

			friendRepo := FriendRepo{
				Db: mockDB,
			}

			err := friendRepo.CreateFriend(tc.input)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestFriendRepo_IsExistedFriend(t *testing.T) {
	testCases := []struct {
		name         string
		firstUserID  int
		secondUserID int
		expResult    bool
		expError     error
		preparePath  string
	}{
		{
			name:         "Friend is existed",
			firstUserID:  1,
			secondUserID: 2,
			expResult:    true,
			expError:     nil,
			preparePath:  "../testhelpers/data_dump/friend/friend.sql",
		},
		{
			name:         "Friend  is not exist",
			firstUserID:  1,
			secondUserID: 3,
			expResult:    false,
			expError:     nil,
			preparePath:  "../testhelpers/data_dump/friend/truncate_friends.sql",
		},
	}
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockDB := testhelpers.ConnectDB()
			testhelpers.PrepareDBForTest(mockDB, tc.preparePath)
			friendRepo := FriendRepo{
				Db: mockDB,
			}

			resutl, err := friendRepo.IsExistedFriend(tc.firstUserID, tc.secondUserID)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expResult, resutl)
			}
		})
	}
}

func TestFriendRepo_IsBlockedFriend(t *testing.T) {
	testCases := []struct {
		name         string
		firstUserID  int
		secondUserID int
		expResult    bool
		expError     error
		preparePath  string
	}{
		{
			name:         "Blocked friend is existed",
			firstUserID:  1,
			secondUserID: 2,
			expResult:    true,
			expError:     nil,
			preparePath:  "../testhelpers/data_dump/blocking/blocking.sql",
		},
		{
			name:         "Blocked friend is not existed",
			firstUserID:  2,
			secondUserID: 1,
			expResult:    false,
			expError:     nil,
			preparePath:  "../testhelpers/data_dump/blocking/truncate_blocking.sql",
		},
	}
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockDB := testhelpers.ConnectDB()
			testhelpers.PrepareDBForTest(mockDB, tc.preparePath)

			friendRepo := FriendRepo{
				Db: mockDB,
			}

			resutl, err := friendRepo.IsBlockedFriend(tc.firstUserID, tc.secondUserID)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expResult, resutl)
			}
		})
	}
}

func TestFriendRepo_GetFriendsByID(t *testing.T) {
	testCases := []struct {
		name        string
		input       int
		expResult   []int
		expError    error
		preparePath string
	}{
		{
			name:        "Get friends list success",
			input:       1,
			expResult:   []int{2},
			expError:    nil,
			preparePath: "../testhelpers/data_dump/friend/friend.sql",
		},
		{
			name:        "Get friend list failed with error",
			input:       4,
			expResult:   []int{},
			expError:    nil,
			preparePath: "../testhelpers/data_dump/friend/truncate_friends.sql",
		},
	}
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockDB := testhelpers.ConnectDB()
			testhelpers.PrepareDBForTest(mockDB, tc.preparePath)

			friendRepo := FriendRepo{
				Db: mockDB,
			}

			resutl, err := friendRepo.GetFriendsByID(tc.input)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expResult, resutl)
			}
		})
	}
}

func TestFriendRepo_GetBlockingFriendsByID(t *testing.T) {
	testCases := []struct {
		name           string
		input          int
		expectedResult []int
		expectedErr    error
		preparePath    string
	}{
		{
			name:           "Get blocking friends list success",
			input:          2,
			expectedResult: []int{1},
			expectedErr:    nil,
			preparePath:    "../testhelpers/data_dump/blocking/blocking.sql",
		},
		{
			name:           "Get blocking friends failed with error",
			input:          1,
			expectedResult: []int{},
			expectedErr:    nil,
			preparePath:    "../testhelpers/data_dump/blocking/blocking.sql",
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockDB := testhelpers.ConnectDB()
			testhelpers.PrepareDBForTest(mockDB, tc.preparePath)

			friendRepo := FriendRepo{
				Db: mockDB,
			}

			result, err := friendRepo.GetBlockingFriendsByID(tc.input)

			if tc.expectedErr != nil {
				require.EqualError(t, err, tc.expectedErr.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expectedResult, result)
			}
		})
	}
}

func TestFriendRepo_GetBlockedFriendsByID(t *testing.T) {
	testCases := []struct {
		name           string
		input          int
		expectedResult []int
		expectedErr    error
		preparePath    string
	}{
		{
			name:           "Get blocked friend list success",
			input:          2,
			expectedResult: []int{1},
			expectedErr:    nil,
			preparePath:    "../testhelpers/data_dump/blocking/blocking.sql",
		},
		{
			name:           "Get blocked friend list failed with error",
			input:          1,
			expectedResult: []int{},
			expectedErr:    nil,
			preparePath:    "../testhelpers/data_dump/blocking/blocking.sql",
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockDB := testhelpers.ConnectDB()
			testhelpers.PrepareDBForTest(mockDB, tc.preparePath)

			friendRepo := FriendRepo{
				Db: mockDB,
			}

			// When
			result, err := friendRepo.GetBlockingFriendsByID(tc.input)

			// Then
			if tc.expectedErr != nil {
				require.EqualError(t, err, tc.expectedErr.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expectedResult, result)
			}
		})
	}
}

func TestFriendRepo_GetUserIDsNoBlocked(t *testing.T) {
	testCases := []struct {
		name           string
		input          int
		expectedResult []int
		expectedErr    error
		preparePath    string
	}{
		{
			name:           "Get success with no block",
			input:          1,
			expectedResult: []int{2},
			expectedErr:    nil,
			preparePath:    "../testhelpers/data_dump/friend/non_blocking.sql",
		},
		{
			name:           "Get success with user is being blocked",
			input:          4,
			expectedResult: []int{},
			expectedErr:    nil,
			preparePath:    "../testhelpers/data_dump/friend/non_blocking.sql",
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockDB := testhelpers.ConnectDB()
			testhelpers.PrepareDBForTest(mockDB, tc.preparePath)

			friendRepo := FriendRepo{
				Db: mockDB,
			}

			result, err := friendRepo.GetUserIDsNoBlocked(tc.input)

			if tc.expectedErr != nil {
				require.EqualError(t, err, tc.expectedErr.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expectedResult, result)
			}
		})
	}
}
