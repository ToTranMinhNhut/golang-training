package handlers

import (
	"FriendManagement/models/api_model"

	"github.com/stretchr/testify/mock"
)

type MockSubscriptionService struct {
	mock.Mock
}

func (_self *MockSubscriptionService) CreateSubscription(service *api_model.SubscriptionService) error {
	args := _self.Called(service)
	var r error
	if args.Get(0) != nil {
		r = args.Get(0).(error)
	}
	return r
}

func (_self *MockSubscriptionService) IsExistedSubscription(requestorUserID int, targetUserID int) (bool, error) {
	args := _self.Called(requestorUserID, targetUserID)
	r0 := args.Get(0).(bool)
	var r1 error
	if args.Get(1) != nil {
		r1 = args.Get(1).(error)
	}
	return r0, r1
}

func (_self *MockSubscriptionService) IsBlockedFriend(requestorUserID int, targetUserID int) (bool, error) {
	args := _self.Called(requestorUserID, targetUserID)
	r0 := args.Get(0).(bool)
	var r1 error
	if args.Get(1) != nil {
		r1 = args.Get(1).(error)
	}
	return r0, r1
}
