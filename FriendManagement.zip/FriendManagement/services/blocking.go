package services

import (
	"FriendManagement/models"
	"FriendManagement/repositories"
)

type IBlockingService interface {
	CreateBlocking(*models.BlockingService) error
	IsExistedBlocking(int, int) (bool, error)
}

type BlockingService struct {
	IBlockingRepo repositories.IBlockingRepo
}

func (_self BlockingService) CreateBlocking(blocking *models.BlockingService) error {
	//Create repo input model
	blockingRepo := &models.BlockingRepository{
		Requestor: blocking.Requestor,
		Target:    blocking.Target,
	}
	err := _self.IBlockingRepo.CreateBlocking(blockingRepo)
	return err
}

func (_self BlockingService) IsExistedBlocking(requestorID int, targetID int) (bool, error) {
	exist, err := _self.IBlockingRepo.IsExistedBlocking(requestorID, targetID)
	return exist, err
}
