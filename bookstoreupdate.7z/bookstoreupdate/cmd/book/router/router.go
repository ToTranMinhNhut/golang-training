package router

// import (
// 	"bookstoreupdate/cmd/book/handlers/errors"
// 	"bookstoreupdate/cmd/book/router/book"
// 	"bookstoreupdate/pkg/application"
// 	"bookstoreupdate/pkg/db"

// 	"github.com/go-chi/chi/v5"
// )

// var dbInstance db.DB

// func Get(app *application.Application) *chi.Mux {
// 	dbInstance = *app.DB
// 	mux := chi.NewRouter()
// 	mux.MethodNotAllowed(errors.MethodNotAllowedHandler)
// 	mux.NotFound(errors.NotFoundHandler)
// 	mux.Route("/books", book.GetBookRouter)
// 	return mux
// }
