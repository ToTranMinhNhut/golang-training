package models

import (
	"FriendManagement/utils"
	"errors"
)

type SupscriptionHandler struct {
	Requestor string `json:"requestor"`
	Target    string `json:"target"`
}

func (_self SupscriptionHandler) Validate() error {
	if _self.Requestor == "" {
		return errors.New("\"requestor\" is required")
	}

	if _self.Target == "" {
		return errors.New("\"target\" is required")
	}

	isValidRequestEmail, requestErr := utils.IsValidEmail(_self.Requestor)
	if !isValidRequestEmail || requestErr != nil {
		return errors.New("\"email\"" + _self.Requestor + " format is not valid. (ex: \"andy@example.com\")")
	}

	isValidTargetEmail, targetErr := utils.IsValidEmail(_self.Requestor)
	if !isValidTargetEmail || targetErr != nil {
		return errors.New("\"	email\"" + _self.Requestor + " format is not valid. (ex: \"andy@example.com\")")
	}
	return nil
}

type SupscriptionService struct {
	Requestor string `json:"requestor"`
	Target    string `json:"target"`
}

type SupscriptionRepository struct {
	Requestor string `json:"requestor"`
	Target    string `json:"target"`
}
