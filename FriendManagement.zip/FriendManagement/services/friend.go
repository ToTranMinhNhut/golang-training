package services

import (
	"FriendManagement/models"
	"FriendManagement/repositories"
	"FriendManagement/utils"
)

type IFriendService interface {
	CreateFriend(*models.FriendService) error
	IsExistedFriend(int, int) (bool, error)
	IsBlockedFriend(int, int) (bool, error)
	GetFriendsByID(int) ([]string, error)
	GetCommonFriendsByIDs([]int) ([]string, error)
	GetEmailsReceiveUpdate(int, string) ([]string, error)
}

type FriendService struct {
	IFriendRepo repositories.IFriendRepo
	IUserRepo   repositories.IUserRepo
}

func (_self FriendService) CreateFriend(friendService *models.FriendService) error {
	//convert to repo input model
	friendsRepoInput := &models.FriendRepository{
		FirstID:  friendService.FirstID,
		SecondID: friendService.SecondID,
	}

	//Call repo
	err := _self.IFriendRepo.CreateFriend(friendsRepoInput)
	return err
}

func (_self FriendService) IsExistedFriend(firstUserID int, secondUserID int) (bool, error) {
	existed, err := _self.IFriendRepo.IsExistedFriend(firstUserID, secondUserID)
	return existed, err
}

func (_self FriendService) IsBlockedFriend(firstUserID int, secondUserID int) (bool, error) {
	isBlocked, err := _self.IFriendRepo.IsBlockedFriend(firstUserID, secondUserID)
	return isBlocked, err
}

func (_self FriendService) GetFriendsByID(userID int) ([]string, error) {
	blockList := make(map[int]bool)
	//Get all friend connection
	friendIDs, err := _self.IFriendRepo.GetFriendsByID(userID)
	if err != nil {
		return nil, err
	}

	//Get list friends who have blocked user
	blockingIDs, err := _self.IFriendRepo.GetBlockingFriendsByID(userID)
	if err != nil {
		return nil, err
	}

	for _, id := range blockingIDs {
		blockList[id] = true
	}

	//Get list friend who have been blocked by user
	blockedIDs, err := _self.IFriendRepo.GetBlockedFriendsByID(userID)
	if err != nil {
		return nil, err
	}

	for _, id := range blockedIDs {
		blockList[id] = true
	}

	//Get UserID list with no blocked
	friendIDsNonBlock := make([]int, 0)
	for _, id := range friendIDs {
		if _, isBlock := blockList[id]; !isBlock {
			friendIDsNonBlock = append(friendIDsNonBlock, id)
		}
	}

	friendEmails, err := _self.IUserRepo.GetEmailsByIDs(friendIDsNonBlock)
	if err != nil {
		return nil, err
	}
	return friendEmails, err
}

func (_self FriendService) GetCommonFriendsByIDs(userIDList []int) ([]string, error) {
	firstFriends, err := _self.GetFriendsByID(userIDList[0])
	if err != nil {
		return nil, err
	}
	secondFriends, err := _self.GetFriendsByID(userIDList[1])
	if err != nil {
		return nil, err
	}

	//Get common friends
	commonFriends := make([]string, 0)
	commonMap := make(map[string]bool)
	for _, firstEmail := range firstFriends {
		commonMap[firstEmail] = true
	}

	for _, secondEmail := range secondFriends {
		if _, ok := commonMap[secondEmail]; ok {
			commonFriends = append(commonFriends, secondEmail)
		}
	}

	return commonFriends, nil
}

func (_self FriendService) GetEmailsReceiveUpdate(senderID int, text string) ([]string, error) {
	result := make([]string, 0)
	resultIDs := make([]int, 0)
	existedResultIDsMap := make(map[int]bool)
	existedEmailsMap := make(map[string]bool)
	//Get friend connections and subscribers with no blocked
	userIDs, err := _self.IFriendRepo.GetUserIDsNoBlocked(senderID)
	if err != nil {
		return nil, err
	}

	for _, ID := range userIDs {
		resultIDs = append(resultIDs, ID)
		existedResultIDsMap[ID] = true
	}

	//Get emails to return
	emails, err := _self.IUserRepo.GetEmailsByIDs(resultIDs)
	if err != nil {
		return nil, err
	}

	for _, email := range emails {
		result = append(result, email)
		existedEmailsMap[email] = true
	}

	//Add mentionedEmails to result
	mentionedEmails := utils.GetEmailFromText(text)
	for _, email := range mentionedEmails {
		if _, ok := existedEmailsMap[email]; !ok {
			result = append(result, email)
		}
	}

	return result, nil
}
