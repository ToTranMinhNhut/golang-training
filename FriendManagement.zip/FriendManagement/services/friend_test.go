package services

import (
	"FriendManagement/models"
	"errors"
	"testing"

	"github.com/stretchr/testify/require"
)

func TestFriendService_CreateFriend(t *testing.T) {
	testCases := []struct {
		name            string
		input           *models.FriendService
		expError        error
		mockFriendInput *models.FriendRepository
		mockError       error
	}{
		{
			name: "Create friend connection success",
			input: &models.FriendService{
				FirstID:  1,
				SecondID: 2,
			},
			expError: nil,
			mockFriendInput: &models.FriendRepository{
				FirstID:  1,
				SecondID: 2,
			},
			mockError: nil,
		},
		{
			name: "Create friend connection failed with error",
			input: &models.FriendService{
				FirstID:  1,
				SecondID: 2,
			},
			expError: errors.New("create friend connection failed with error"),
			mockFriendInput: &models.FriendRepository{
				FirstID:  1,
				SecondID: 2,
			},
			mockError: errors.New("create friend connection failed with error"),
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockFriendRepo := new(MockFriendRepo)
			mockFriendRepo.On("CreateFriend", tc.mockFriendInput).Return(tc.mockError)

			friendService := FriendService{
				IFriendRepo: mockFriendRepo,
			}

			err := friendService.CreateFriend(tc.input)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
			}

		})
	}
}

func TestFriendService_IsExistedFriend(t *testing.T) {
	testCases := []struct {
		name              string
		firstUserIDInput  int
		secondUserIDInput int
		expResult         bool
		expError          error
		mockFirstUserID   int
		mockSecondUserID  int
		mockResult        bool
		mockError         error
	}{
		{
			name:              "check is existed friend successfully",
			firstUserIDInput:  1,
			secondUserIDInput: 2,
			expResult:         true,
			expError:          nil,
			mockFirstUserID:   1,
			mockSecondUserID:  2,
			mockResult:        true,
			mockError:         nil,
		},
		{
			name:              "check is existed friend failed",
			firstUserIDInput:  1,
			secondUserIDInput: 2,
			expResult:         false,
			expError:          errors.New("query database failed"),
			mockFirstUserID:   1,
			mockSecondUserID:  2,
			mockResult:        false,
			mockError:         errors.New("query database failed"),
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockFriendRepo := new(MockFriendRepo)
			mockFriendRepo.On("IsExistedFriend", tc.mockFirstUserID, tc.mockSecondUserID).Return(tc.mockResult, tc.mockError)

			friendService := FriendService{
				IFriendRepo: mockFriendRepo,
			}

			isExisted, err := friendService.IsExistedFriend(tc.firstUserIDInput, tc.secondUserIDInput)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, isExisted, tc.expResult)
			}
		})
	}
}

func TestFriendService_IsBlockedFriend(t *testing.T) {
	testCases := []struct {
		name              string
		firstUserIDInput  int
		secondUserIDInput int
		expResult         bool
		expError          error
		mockFirstUserID   int
		mockSecondUserID  int
		mockResult        bool
		mockError         error
	}{
		{
			name:              "check is blocked friend successfully",
			firstUserIDInput:  1,
			secondUserIDInput: 2,
			expResult:         true,
			expError:          nil,
			mockFirstUserID:   1,
			mockSecondUserID:  2,
			mockResult:        true,
			mockError:         nil,
		},
		{
			name:              "check is blocked friend failed",
			firstUserIDInput:  1,
			secondUserIDInput: 2,
			expResult:         false,
			expError:          errors.New("query database failed"),
			mockFirstUserID:   1,
			mockSecondUserID:  2,
			mockResult:        false,
			mockError:         errors.New("query database failed"),
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockFriendRepo := new(MockFriendRepo)
			mockFriendRepo.On("IsBlockedFriend", tc.mockFirstUserID, tc.mockSecondUserID).
				Return(tc.mockResult, tc.mockError)

			friendService := FriendService{
				IFriendRepo: mockFriendRepo,
			}

			blocked, err := friendService.IsBlockedFriend(tc.firstUserIDInput, tc.secondUserIDInput)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, blocked, tc.expResult)
			}
		})
	}
}

func TestFriendService_GetFriendsByID(t *testing.T) {
	type mockGetFriendsByID struct {
		input  int
		result []int
		err    error
	}
	type mockGetBlockingFriendsByID struct {
		input  int
		result []int
		err    error
	}
	type mockGetBlockedFriendsByID struct {
		input  int
		result []int
		err    error
	}
	type mockGetEmailsByIDs struct {
		input  []int
		result []string
		err    error
	}

	testCases := []struct {
		name                   string
		input                  int
		expectedResult         []string
		expectedErr            error
		mockGetFriends         mockGetFriendsByID
		mockGetBlockingFriends mockGetBlockingFriendsByID
		mockGetBlockedFriends  mockGetBlockedFriendsByID
		mockGetEmails          mockGetEmailsByIDs
	}{
		{
			name:           "Get friend list success",
			input:          1,
			expectedResult: []string{"andy@example.com"},
			expectedErr:    nil,
			mockGetFriends: mockGetFriendsByID{
				input:  1,
				result: []int{2, 3, 4},
				err:    nil,
			},
			mockGetBlockingFriends: mockGetBlockingFriendsByID{
				input:  1,
				result: []int{2},
				err:    nil,
			},
			mockGetBlockedFriends: mockGetBlockedFriendsByID{
				input:  1,
				result: []int{3},
				err:    nil,
			},
			mockGetEmails: mockGetEmailsByIDs{
				input:  []int{4},
				result: []string{"andy@example.com"},
				err:    nil,
			},
		},
		{
			name:           "Get friends list failed with error",
			input:          1,
			expectedResult: nil,
			expectedErr:    errors.New("get friends list failed with error"),
			mockGetFriends: mockGetFriendsByID{
				input:  1,
				result: nil,
				err:    errors.New("get friends list failed with error"),
			},
		},
		{
			name:           "get blocking friends list failed",
			input:          1,
			expectedResult: nil,
			expectedErr:    errors.New("get blocking friends failed with error"),
			mockGetFriends: mockGetFriendsByID{
				input:  1,
				result: []int{2},
				err:    nil,
			},
			mockGetBlockingFriends: mockGetBlockingFriendsByID{
				input:  1,
				result: []int{3},
				err:    errors.New("get blocking friends failed with error"),
			},
		},
		{
			name:           "get blocked friends list failed",
			input:          1,
			expectedResult: nil,
			expectedErr:    errors.New("get blocked friends failed with error"),
			mockGetFriends: mockGetFriendsByID{
				input:  1,
				result: []int{2},
				err:    nil,
			},
			mockGetBlockingFriends: mockGetBlockingFriendsByID{
				input:  1,
				result: []int{3},
				err:    nil,
			},
			mockGetBlockedFriends: mockGetBlockedFriendsByID{
				input:  1,
				result: nil,
				err:    errors.New("get blocked friends failed with error"),
			},
		},
		{
			name:           "Get email list by IDs failed with error",
			input:          1,
			expectedResult: nil,
			expectedErr:    errors.New("get email list by userIDs failed with error"),
			mockGetFriends: mockGetFriendsByID{
				input:  1,
				result: []int{2, 3, 4},
				err:    nil,
			},
			mockGetBlockingFriends: mockGetBlockingFriendsByID{
				input:  1,
				result: []int{2},
				err:    nil,
			},
			mockGetBlockedFriends: mockGetBlockedFriendsByID{
				input:  1,
				result: []int{3},
				err:    nil,
			},
			mockGetEmails: mockGetEmailsByIDs{
				input:  []int{4},
				result: nil,
				err:    errors.New("get email list by userIDs failed with error"),
			},
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			// Given
			mockFriendRepo := new(MockFriendRepo)
			mockUserRepo := new(MockUserRepo)
			mockFriendRepo.On("GetFriendsByID", tc.mockGetFriends.input).
				Return(tc.mockGetFriends.result, tc.mockGetFriends.err)

			mockFriendRepo.On("GetBlockingFriendsByID", tc.mockGetBlockingFriends.input).
				Return(tc.mockGetBlockingFriends.result, tc.mockGetBlockingFriends.err)

			mockFriendRepo.On("GetBlockedFriendsByID", tc.mockGetBlockedFriends.input).
				Return(tc.mockGetBlockedFriends.result, tc.mockGetBlockedFriends.err)

			mockUserRepo.On("GetEmailsByIDs", tc.mockGetEmails.input).
				Return(tc.mockGetEmails.result, tc.mockGetEmails.err)

			service := FriendService{
				IFriendRepo: mockFriendRepo,
				IUserRepo:   mockUserRepo,
			}

			// When
			result, err := service.GetFriendsByID(tc.input)

			// Then
			if tc.expectedErr != nil {
				require.EqualError(t, err, tc.expectedErr.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expectedResult, result)
			}
		})
	}

}

func TestFriendService_GetCommonFriendsByIDs(t *testing.T) {
	type mockFriendsByID struct {
		input  int
		result []int
		err    error
	}
	type mockBlockingFriendsByID struct {
		input  int
		result []int
		err    error
	}
	type mockBlockedFriendsByID struct {
		input  int
		result []int
		err    error
	}
	type mockEmailsByIDs struct {
		input  []int
		result []string
		err    error
	}
	testCases := []struct {
		name                          string
		input                         []int
		expectedResult                []string
		expectedErr                   error
		mockFriendsFirstUser          mockFriendsByID
		mockBlockingFriendsFirstUser  mockBlockingFriendsByID
		mockBlockedFriendsFirstUser   mockBlockedFriendsByID
		mockEmailsByFirstUSerList     mockEmailsByIDs
		mockFriendsSecondUser         mockFriendsByID
		mockBlockingFriendsSecondUser mockBlockingFriendsByID
		mockBlockedFriendsSecondUser  mockBlockedFriendsByID
		mockEmailsBySecondUSerList    mockEmailsByIDs
	}{
		{
			name:           "Get common friends success",
			input:          []int{1, 3},
			expectedResult: []string{"andy@example.com"},
			expectedErr:    nil,
			mockFriendsFirstUser: mockFriendsByID{
				input:  1,
				result: []int{2},
				err:    nil,
			},
			mockBlockingFriendsFirstUser: mockBlockingFriendsByID{
				input:  1,
				result: []int{3},
				err:    nil,
			},
			mockBlockedFriendsFirstUser: mockBlockedFriendsByID{
				input:  1,
				result: []int{3},
				err:    nil,
			},
			mockEmailsByFirstUSerList: mockEmailsByIDs{
				input:  []int{2},
				result: []string{"andy@example.com"},
				err:    nil,
			},
			mockFriendsSecondUser: mockFriendsByID{
				input:  3,
				result: []int{1, 2},
				err:    nil,
			},
			mockBlockingFriendsSecondUser: mockBlockingFriendsByID{
				input:  3,
				result: []int{1},
				err:    nil,
			},
			mockBlockedFriendsSecondUser: mockBlockedFriendsByID{
				input:  3,
				result: []int{1},
				err:    nil,
			},
			mockEmailsBySecondUSerList: mockEmailsByIDs{
				input:  []int{2},
				result: []string{"andy@example.com"},
				err:    nil,
			},
		},
		{
			name:           "Get friends of first user failed with error",
			input:          []int{1, 2},
			expectedResult: nil,
			expectedErr:    errors.New("get friends of first user failed with error"),
			mockFriendsFirstUser: mockFriendsByID{
				input:  1,
				result: nil,
				err:    errors.New("get friends of first user failed with error"),
			},
		},
		{
			name:           "Get friends of second user failed with error",
			input:          []int{1, 3},
			expectedResult: nil,
			expectedErr:    errors.New("get friends of second user failed with error"),
			mockFriendsFirstUser: mockFriendsByID{
				input:  1,
				result: []int{2},
				err:    nil,
			},
			mockBlockingFriendsFirstUser: mockBlockingFriendsByID{
				input:  1,
				result: []int{},
				err:    nil,
			},
			mockBlockedFriendsFirstUser: mockBlockedFriendsByID{
				input:  1,
				result: []int{},
				err:    nil,
			},
			mockEmailsByFirstUSerList: mockEmailsByIDs{
				input:  []int{2},
				result: []string{"andy@example.com"},
				err:    nil,
			},
			mockFriendsSecondUser: mockFriendsByID{
				input:  3,
				result: []int{},
				err:    errors.New("get friends of second user failed with error"),
			},
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockFriendRepo := new(MockFriendRepo)
			mockUserRepo := new(MockUserRepo)

			mockFriendRepo.On("GetFriendsByID", tc.mockFriendsFirstUser.input).
				Return(tc.mockFriendsFirstUser.result, tc.mockFriendsFirstUser.err)
			mockFriendRepo.On("GetBlockingFriendsByID", tc.mockBlockingFriendsFirstUser.input).
				Return(tc.mockBlockingFriendsFirstUser.result, tc.mockBlockingFriendsFirstUser.err)
			mockFriendRepo.On("GetBlockedFriendsByID", tc.mockBlockedFriendsFirstUser.input).
				Return(tc.mockBlockedFriendsFirstUser.result, tc.mockBlockedFriendsFirstUser.err)
			mockUserRepo.On("GetEmailsByIDs", tc.mockEmailsByFirstUSerList.input).
				Return(tc.mockEmailsByFirstUSerList.result, tc.mockEmailsByFirstUSerList.err)

			mockFriendRepo.On("GetFriendsByID", tc.mockFriendsSecondUser.input).
				Return(tc.mockFriendsSecondUser.result, tc.mockFriendsSecondUser.err)
			mockFriendRepo.On("GetBlockingFriendsByID", tc.mockBlockingFriendsSecondUser.input).
				Return(tc.mockBlockingFriendsSecondUser.result, tc.mockBlockingFriendsSecondUser.err)
			mockFriendRepo.On("GetBlockedFriendsByID", tc.mockBlockedFriendsSecondUser.input).
				Return(tc.mockBlockedFriendsSecondUser.result, tc.mockBlockedFriendsSecondUser.err)
			mockUserRepo.On("GetEmailsByIDs", tc.mockEmailsBySecondUSerList.input).
				Return(tc.mockEmailsBySecondUSerList.result, tc.mockEmailsBySecondUSerList.err)

			friendService := FriendService{
				IFriendRepo: mockFriendRepo,
				IUserRepo:   mockUserRepo,
			}

			result, err := friendService.GetCommonFriendsByIDs(tc.input)

			if tc.expectedErr != nil {
				require.EqualError(t, err, tc.expectedErr.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expectedResult, result)
			}
		})
	}
}

func TestFriendService_GetEmailsReceiveUpdate(t *testing.T) {
	type mockGetUserIDsNoBlocked struct {
		input  int
		result []int
		err    error
	}
	type mockGetEmailsByIDs struct {
		input  []int
		result []string
		err    error
	}
	testCase := []struct {
		name                 string
		sender               int
		text                 string
		expectedResult       []string
		expectedErr          error
		mockUserIDsNoBlocked mockGetUserIDsNoBlocked
		requestorID          int
		mockGetEmailsByIDs   mockGetEmailsByIDs
	}{
		{
			name:           "Get emails which receive updates success",
			sender:         1,
			text:           "hello test@example.com",
			expectedResult: []string{"andy@gmail.com", "subscriber@example.com", "test@example.com"},
			expectedErr:    nil,
			mockUserIDsNoBlocked: mockGetUserIDsNoBlocked{
				input:  1,
				result: []int{2, 3},
				err:    nil,
			},
			requestorID: 1,
			mockGetEmailsByIDs: mockGetEmailsByIDs{
				input:  []int{2, 3},
				result: []string{"andy@gmail.com", "subscriber@example.com"},
				err:    nil,
			},
		},
		{
			name:           "Get email of users who is not blocked failed with error",
			sender:         1,
			expectedResult: nil,
			expectedErr:    errors.New("failed with error"),
			mockUserIDsNoBlocked: mockGetUserIDsNoBlocked{
				input:  1,
				result: nil,
				err:    errors.New("failed with error"),
			},
		},
		{
			name:           "Get emails which receive updates failed with error",
			sender:         1,
			text:           "",
			expectedResult: []string{"andy@gmail.com"},
			expectedErr:    errors.New("failed with error"),
			requestorID:    1,
			mockUserIDsNoBlocked: mockGetUserIDsNoBlocked{
				input:  1,
				result: []int{2, 3},
				err:    nil,
			},
			mockGetEmailsByIDs: mockGetEmailsByIDs{
				input:  []int{2, 3},
				result: nil,
				err:    errors.New("failed with error"),
			},
		},
	}

	for _, tc := range testCase {
		t.Run(tc.name, func(t *testing.T) {
			mockFriendRepo := new(MockFriendRepo)
			mockUserRepo := new(MockUserRepo)

			mockFriendRepo.On("GetUserIDsNoBlocked", tc.mockUserIDsNoBlocked.input).
				Return(tc.mockUserIDsNoBlocked.result, tc.mockUserIDsNoBlocked.err)

			mockUserRepo.On("GetEmailsByIDs", tc.mockGetEmailsByIDs.input).
				Return(tc.mockGetEmailsByIDs.result, tc.mockGetEmailsByIDs.err)

			friendService := FriendService{
				IFriendRepo: mockFriendRepo,
				IUserRepo:   mockUserRepo,
			}

			result, err := friendService.GetEmailsReceiveUpdate(tc.sender, tc.text)

			if tc.expectedErr != nil {
				require.EqualError(t, err, tc.expectedErr.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expectedResult, result)
			}
		})
	}
}
