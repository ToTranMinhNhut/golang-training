package handlers

import (
	"encoding/json"
	"errors"
	"net/http"

	"FriendManagement/models"
	"FriendManagement/services"
)

type FriendHandler struct {
	IUserService   services.IUserService
	IFriendService services.IFriendService
}

func (_self FriendHandler) CreateFriend(w http.ResponseWriter, r *http.Request) {
	// Decode request body
	friendHandler := models.FriendHandler{}
	if err := json.NewDecoder(r.Body).Decode(&friendHandler); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	//Validation
	if err := friendHandler.Validate(); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	// Validate before creating friend
	IDs, statusCode, err := _self.GetUserIDsByEmail(friendHandler.Friends)
	if err != nil {
		http.Error(w, err.Error(), statusCode)
		return
	}

	firstUserID, secondUserID := IDs[0], IDs[1]
	// Check friend connection exists
	statusCode, err = _self.IsExistedFriend(firstUserID, secondUserID)
	if err != nil {
		http.Error(w, err.Error(), statusCode)
		return
	}

	// //check blocking between 2 emails
	statusCode, err = _self.IsBlockedFriend(firstUserID, secondUserID)
	if err != nil {
		http.Error(w, err.Error(), statusCode)
		return
	}

	//Model UserIDs services input
	friendsInputModel := &models.FriendService{
		FirstID:  IDs[0],
		SecondID: IDs[1],
	}

	//Call services to create friend connection
	if err := _self.IFriendService.CreateFriend(friendsInputModel); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	//Response
	json.NewEncoder(w).Encode(models.SuccessResponse{
		Success: true,
	})
}

func (_self FriendHandler) GetUserIDsByEmail(friends []string) ([]int, int, error) {
	//Check first email valid
	firstUserID, err := _self.IUserService.GetUserIDByEmail(friends[0])

	if err != nil {
		return nil, http.StatusInternalServerError, err
	}
	if firstUserID == 0 {
		return nil, http.StatusBadRequest, errors.New("the first email does not exist")
	}

	//Check first email valid
	secondUserID, err := _self.IUserService.GetUserIDByEmail(friends[1])

	if err != nil {
		return nil, http.StatusInternalServerError, err
	}
	if secondUserID == 0 {
		return nil, http.StatusBadRequest, errors.New("the second email does not exist")
	}

	return []int{firstUserID, secondUserID}, 0, nil
}

func (_self FriendHandler) IsExistedFriend(firstUserID int, secondUserID int) (int, error) {
	existed, err := _self.IFriendService.IsExistedFriend(firstUserID, secondUserID)
	if err != nil {
		return http.StatusInternalServerError, err
	}
	if existed {
		return http.StatusAlreadyReported, errors.New("friend connection existed")
	}
	return http.StatusOK, nil
}

func (_self FriendHandler) IsBlockedFriend(firstUserID int, secondUserID int) (int, error) {
	blocked, err := _self.IFriendService.IsBlockedFriend(firstUserID, secondUserID)
	if err != nil {
		return http.StatusInternalServerError, err
	}
	if blocked {
		return http.StatusPreconditionFailed, errors.New("emails blocked each other")
	}
	return http.StatusOK, nil
}

func (_self FriendHandler) GetFriendsByEmail(w http.ResponseWriter, r *http.Request) {
	// Decode request body
	friendHandler := models.FriendGetFriendsHandler{}
	if err := json.NewDecoder(r.Body).Decode(&friendHandler); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return

	}
	if err := friendHandler.Validate(); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	//Check existed email and get ID by email
	userID, statusCode, err := _self.GetUserIDByEmail(friendHandler.Email)
	if err != nil {
		http.Error(w, err.Error(), statusCode)
		return
	}

	//Call services
	friendList, err := _self.IFriendService.GetFriendsByID(userID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	//Response

	json.NewEncoder(w).Encode(models.FriendsResponse{
		Success: true,
		Friends: friendList,
		Count:   len(friendList),
	})
}

func (_self FriendHandler) GetUserIDByEmail(email string) (int, int, error) {
	//Check first email valid
	userID, err := _self.IUserService.GetUserIDByEmail(email)

	if err != nil {
		return 0, http.StatusInternalServerError, err
	}

	if userID == 0 {
		return 0, http.StatusBadRequest, errors.New("email does not exist")
	}

	return userID, 0, nil
}

func (_self FriendHandler) GetCommonFriendsByEmails(w http.ResponseWriter, r *http.Request) {
	//Decode request body
	friendRequest := models.FriendHandler{}
	if err := json.NewDecoder(r.Body).Decode(&friendRequest); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	//Validation
	if err := friendRequest.Validate(); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	//Check Existed email and get IDList
	userIDList, statusCode, err := _self.GetUserIDsByEmail(friendRequest.Friends)
	if err != nil {
		http.Error(w, err.Error(), statusCode)
		return
	}

	//Call services
	friendList, err := _self.IFriendService.GetCommonFriendsByIDs(userIDList)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	//Response
	json.NewEncoder(w).Encode(models.FriendsResponse{
		Success: true,
		Friends: friendList,
		Count:   len(friendList),
	})
}

func (_self FriendHandler) GetEmailsReceiveUpdate(w http.ResponseWriter, r *http.Request) {
	//decode request body
	emailReceiveUpdateHandler := models.EmailReceiveUpdateHandler{}
	if err := json.NewDecoder(r.Body).Decode(&emailReceiveUpdateHandler); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	// Validate request body
	if err := emailReceiveUpdateHandler.Validate(); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	// Check existed email and get userID
	senderID, statusCode, err := _self.GetUserIDByEmail(emailReceiveUpdateHandler.Sender)
	if err != nil {
		http.Error(w, err.Error(), statusCode)
		return
	}

	//Call services
	recipientList, err := _self.IFriendService.GetEmailsReceiveUpdate(senderID, emailReceiveUpdateHandler.Text)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Response
	json.NewEncoder(w).Encode(models.EmailReceiveUpdateResponse{
		Success:    true,
		Recipients: recipientList,
	})
	return
}
