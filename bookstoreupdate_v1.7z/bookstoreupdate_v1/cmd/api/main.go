package main

import (
	"log"
	"net/http"

	"bookstoreupdate/pkg/config"
	"bookstoreupdate/pkg/logger"
	"bookstoreupdate/pkg/routes"

	"bookstoreupdate/pkg/db"

	"github.com/joho/godotenv"
)

func main() {
	if err := godotenv.Load("../../.env"); err != nil {
		log.Println("failed to load env vars ", err)
	}

	cfg := config.Get()
	db, err := db.Get(cfg.GetDBConnStr())
	if err != nil {
		log.Println("Connect to database is failded")
	}

	routes := routes.RegisterRoutes(db)
	logger.Info.Printf("starting server ")
	http.ListenAndServe(":8080", routes)
}
