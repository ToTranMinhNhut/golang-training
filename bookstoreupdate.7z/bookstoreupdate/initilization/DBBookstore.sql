create table IF NOT EXISTS book(
	BookId integer,
	Title varchar(200),
	Author varchar(500),
	Price bigint,
	primary key(bookid)
);