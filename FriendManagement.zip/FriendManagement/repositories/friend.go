package repositories

import (
	"FriendManagement/models"
	"database/sql"
	"log"
)

type IFriendRepo interface {
	CreateFriend(*models.FriendRepository) error
	IsExistedFriend(int, int) (bool, error)
	IsBlockedFriend(firstUserID int, secondUserID int) (bool, error)
	GetFriendsByID(userID int) ([]int, error)
	GetBlockingFriendsByID(userID int) ([]int, error)
	GetBlockedFriendsByID(userID int) ([]int, error)
	GetEmailsNoBlocked(userID int) ([]int, error)
}

type FriendRepo struct {
	Db *sql.DB
}

func (_self FriendRepo) CreateFriend(friend *models.FriendRepository) error {
	tx, err := _self.Db.Begin()
	if err != nil {
		log.Fatal(err)
	}

	query := `INSERT INTO friends(firstid, secondid) VALUES ($1, $2)`
	_, err = _self.Db.Exec(query, friend.FirstID, friend.SecondID)

	if err != nil {
		return err
	}

	tx.Commit()
	return nil
}

func (_self FriendRepo) IsExistedFriend(firstUserID int, secondUserID int) (bool, error) {
	tx, err := _self.Db.Begin()
	if err != nil {
		log.Fatal(err)
	}

	query := `SELECT EXISTS (SELECT true FROM friends
		 WHERE (firstid IN ($1, $2) AND secondid IN ($1, $2)))`
	var existed bool
	err = tx.QueryRow(query, firstUserID, secondUserID).Scan(&existed)
	if err != nil {
		return true, err
	}
	if existed {
		return true, nil
	}
	tx.Commit()
	return false, nil
}

func (_self FriendRepo) IsBlockedFriend(firstUserID int, secondUserID int) (bool, error) {
	tx, err := _self.Db.Begin()
	if err != nil {
		log.Fatal(err)
	}

	query := `SELECT EXISTS (SELECT true FROM blocks
		 WHERE (requestorid IN ($1, $2) AND targetid IN ($1, $2)))`
	var isBlocked bool
	err = tx.QueryRow(query, firstUserID, secondUserID).Scan(&isBlocked)
	if err != nil {
		return true, err
	}
	if isBlocked {
		return true, nil
	}

	tx.Commit()
	return false, nil
}

func (_self FriendRepo) GetFriendsByID(userID int) ([]int, error) {
	tx, err := _self.Db.Begin()
	if err != nil {
		log.Fatal(err)
	}

	query := `SELECT firstid, secondid FROM friends WHERE firstid=$1 OR secondid = $1`
	var friendListID = make([]int, 0)
	rows, err := tx.Query(query, userID)
	if err != nil {
		return nil, err
	}

	for rows.Next() {
		var firstID, secondID int
		if err := rows.Scan(&firstID, &secondID); err != nil {
			return nil, err
		}
		if firstID == userID {
			friendListID = append(friendListID, secondID)
		}
		if secondID == userID {
			friendListID = append(friendListID, firstID)
		}
	}

	tx.Commit()
	return friendListID, err
}

func (_self FriendRepo) GetBlockingFriendsByID(userID int) ([]int, error) {
	tx, err := _self.Db.Begin()
	if err != nil {
		log.Fatal(err)
	}

	query := `SELECT requestorid FROM blocks WHERE targetid = $1`

	var blockingListID = make([]int, 0)
	rows, err := tx.Query(query, userID)
	if err != nil {
		return nil, err
	}

	for rows.Next() {
		var blockingUserID int
		if err := rows.Scan(&blockingUserID); err != nil {
			return nil, err
		}
		blockingListID = append(blockingListID, blockingUserID)
	}
	tx.Commit()
	return blockingListID, err
}

func (_self FriendRepo) GetBlockedFriendsByID(userID int) ([]int, error) {
	query := `select targetid from blocks where requestorid = $1`

	var blockedListID = make([]int, 0)
	rows, err := _self.Db.Query(query, userID)
	if err != nil {
		return nil, err
	}

	for rows.Next() {
		var blockedUserID int
		if err := rows.Scan(&blockedUserID); err != nil {
			return nil, err
		}
		blockedListID = append(blockedListID, blockedUserID)
	}
	return blockedListID, err
}

func (_self FriendRepo) GetEmailsNoBlocked(userID int) ([]int, error) {
	query := `SELECT DISTINCT val.ID FROM (
					SELECT u.ID FROM users u
						JOIN friends f ON (u.id = f.firstid or u.id = f.secondid)
							WHERE u.id <> $1 AND (f.firstid = $1 or f.secondid = $1)
					UNION
					SELECT u.ID FROM subscriptions s
						JOIN users u ON s.targetid = u.id
							WHERE u.id <> $1
				) AS val WHERE NOT EXISTS (
				    SELECT 1 FROM blocks b WHERE b.requestorid = val.id AND b.targetid = $1
				)`
	rows, err := _self.Db.Query(query, userID)
	if err != nil {
		return nil, err
	}

	UserIDs := make([]int, 0)
	for rows.Next() {
		var id int
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		UserIDs = append(UserIDs, id)
	}
	return UserIDs, nil
}
