create table if not exists public.users
(
    id intnot null generated always as identity primary key,
    email varchar(100) not null
);

-- drop table public.useremails

create table if not exists public.friends
(
    id intnot null generated always as identity primary key,
    firstid intnot null,
    secondid int not null,
    constraint firstemail_fk foreign key (firstid) references public.useremails(id),
    constraint secondemail_fk foreign key (secondid) references public.useremails(id)
);

-- drop table public.friends

create table if not exists public.subscriptions
(
    id int not null generated always as identity primary key,
    requestorid int not null,
    targetid int not null,
    constraint requestid_fk foreign key (requestorid) references public.useremails(id),
    constraint targetid_fk foreign key (targetid) references public.useremails(id)
);

--drop table public.subscriptions

create table if not exists public.blocks
(
    id int not null generated always as identity primary key,
    requestorid int not null,
    targetid int not null,
    constraint requestid_fk foreign key (requestorid) references public.useremails(id),
    constraint targetid_fk foreign key (targetid) references public.useremails(id)
);
