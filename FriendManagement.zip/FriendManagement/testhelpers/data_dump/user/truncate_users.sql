TRUNCATE TABLE users, friends, subscriptions, blocks;

alter sequence users_id_seq RESTART WITH 1;

