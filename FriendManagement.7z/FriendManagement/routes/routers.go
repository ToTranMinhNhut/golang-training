package routes

import (
	"database/sql"

	"FriendManagement/handlers"
	"FriendManagement/repositories"
	"FriendManagement/services"

	"github.com/go-chi/chi/v5"
)

func RegisterRoutes(db *sql.DB) *chi.Mux {
	route := chi.NewRouter()

	route.Route("/user", func(route chi.Router) {
		userHandler := handlers.UserHandler{
			IUserService: services.UserService{
				IUserRepo: repositories.UserRepo{
					Db: db,
				},
			},
		}
		route.Post("/create", userHandler.CreateUser)
	})

	route.Route("friend", func(route chi.Router) {

	})

	// mux.Route("/books", func(mux chi.Router) {
	// 	mux.Post("/create", handler.CreateBook)
	// 	mux.Get("/{bookid}", handler.GetBook)
	// 	mux.MethodFunc()
	// })
	return route
}
