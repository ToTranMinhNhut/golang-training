package db

import (
	"bookstore/models"
	"database/sql"
	"log"
)

// func (db Database) GetAllItems() (*models.ItemList, error) {
//     list := &models.ItemList{}
//     rows, err := db.Conn.Query("SELECT * FROM items ORDER BY ID DESC")
//     if err != nil {
//         return list, err
//     }
//     for rows.Next() {
//         var item models.Item
//         err := rows.Scan(&item.ID, &item.Name, &item.Description, &item.CreatedAt)
//         if err != nil {
//             return list, err
//         }
//         list.Items = append(list.Items, item)
//     }
//     return list, nil
// }
func (db Database) AddBook(book *models.Book) error {
	var id int16
	var title string
	log.Println("create new book", book)
	query := `INSERT INTO book (bookid, title, author, price) VALUES ($1, $2, $3, $4) RETURNING bookid, title`
	err := db.Conn.QueryRow(query, book.BookId, book.Title, book.Author, book.Price).Scan(&id, &title)
	if err != nil {
		return err
	}
	book.BookId = id
	book.Title = title
	return nil
}

func (db Database) GetBookById(BookId int) (models.Book, error) {
	book := models.Book{}
	query := `SELECT * FROM book WHERE bookid = $1;`
	row := db.Conn.QueryRow(query, BookId)
	switch err := row.Scan(&book.BookId, &book.Title, &book.Author, &book.Price); err {
	case sql.ErrNoRows:
		return book, ErrNoMatch
	default:
		return book, err
	}

}
