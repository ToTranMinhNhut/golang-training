package main

// import (
// 	"bookstoreupdate/pkg/application"
// 	"bookstoreupdate/pkg/exithandler"
// 	"log"

// 	"github.com/joho/godotenv"

// 	"bookstoreupdate/cmd/book/router"
// 	"bookstoreupdate/pkg/logger"
// 	"bookstoreupdate/pkg/server"
// )

// func main() {
// 	if err := godotenv.Load("../../.env"); err != nil {
// 		log.Println("failed to load env vars ", err)
// 	}

// 	app, err := application.New()
// 	if err != nil {
// 		logger.Error.Fatal(err.Error())
// 	}

// 	srv := server.
// 		New().
// 		WithAddr(app.Cfg.GetAPIPort()).
// 		WithRouter(router.Get(app)).
// 		WithErrLogger(logger.Error)

// 	go func() {
// 		logger.Info.Printf("starting server at %s", app.Cfg.GetAPIPort())
// 		if err := srv.Start(); err != nil {
// 			logger.Error.Fatal(err.Error())
// 		}
// 	}()

// 	exithandler.Init(func() {
// 		if err := srv.Close(); err != nil {
// 			logger.Error.Println(err.Error())
// 		}

// 		if err := app.DB.Close(); err != nil {
// 			logger.Error.Println(err.Error())
// 		}
// 	})
// }
