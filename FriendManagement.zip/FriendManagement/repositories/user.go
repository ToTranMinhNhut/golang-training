package repositories

import (
	"FriendManagement/models"
	"context"
	"database/sql"
	"log"
	"strconv"

	"github.com/lib/pq"
)

type IUserRepo interface {
	CreateUser(*models.UserRepository) error
	IsExistedUser(string) (bool, error)
	GetUserIDByEmail(string) (int, error)
	GetEmailsByIDs(userIDs []int) ([]string, error)
}

type UserRepo struct {
	Db *sql.DB
}

func (_self UserRepo) CreateUser(user *models.UserRepository) error {
	ctx := context.Background()
	tx, err := _self.Db.BeginTx(ctx, nil)
	if err != nil {
		log.Fatal(err)
	}
	query := `INSERT INTO users (email) VALUES ($1)`
	_, err = tx.Exec(query, user.Email)
	if err != nil {
		return err
	}

	tx.Commit()
	return nil
}

func (_self UserRepo) IsExistedUser(email string) (bool, error) {
	ctx := context.Background()
	tx, err := _self.Db.BeginTx(ctx, nil)
	if err != nil {
		log.Fatal(err)
	}

	query := `SELECT EXISTS (SELECT true FROM users WHERE email=$1)`
	var existed bool
	err = tx.QueryRow(query, email).Scan(&existed)
	if err != nil {
		return false, err
	}
	if existed {
		return true, nil
	}
	tx.Commit()
	return false, nil
}

func (_self UserRepo) GetUserIDByEmail(email string) (int, error) {
	ctx := context.Background()
	tx, err := _self.Db.BeginTx(ctx, nil)
	if err != nil {
		log.Fatal(err)
	}

	query := `SELECT id FROM users WHERE email=$1`
	var userID int
	err = tx.QueryRow(query, email).Scan(&userID)
	if err != nil {
		if err == sql.ErrNoRows {
			return 0, nil
		}
		return 0, err
	}
	tx.Commit()
	return userID, nil
}

func (_self UserRepo) GetEmailsByIDs(userIDs []int) ([]string, error) {
	ctx := context.Background()
	tx, err := _self.Db.BeginTx(ctx, nil)
	if err != nil {
		log.Fatal(err)
	}

	if len(userIDs) == 0 {
		return []string{}, nil
	}

	IDs := make([]string, len(userIDs))
	for i, id := range userIDs {
		IDs[i] = strconv.Itoa(id)
	}

	query := `SELECT email FROM users WHERE id = ANY($1)`
	rows, err := tx.Query(query, pq.Array(IDs))
	if err != nil {
		return nil, err
	}

	emails := make([]string, 0)
	for rows.Next() {
		var email string
		if err := rows.Scan(&email); err != nil {
			return nil, err
		}
		emails = append(emails, email)
	}

	tx.Commit()
	return emails, nil
}
