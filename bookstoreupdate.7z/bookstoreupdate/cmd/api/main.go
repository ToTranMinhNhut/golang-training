package main

import (
	"bookstoreupdate/pkg/application"
	"bookstoreupdate/pkg/exithandler"
	"bookstoreupdate/pkg/handlers"

	"log"

	"github.com/joho/godotenv"

	"bookstoreupdate/pkg/logger"
	"bookstoreupdate/pkg/server"
)

func main() {
	if err := godotenv.Load("../../.env"); err != nil {
		log.Println("failed to load env vars ", err)
	}

	handler := handlers.NewBookHandler()
	app, err := application.New(handler)
	if err != nil {
		logger.Error.Fatal(err.Error())
	}

	routes := registerRoutes(app)

	srv := server.
		New().
		WithAddr(app.Cfg.GetAPIPort()).
		WithRouter(routes).
		WithErrLogger(logger.Error)

	go func() {
		logger.Info.Printf("starting server at %s", app.Cfg.GetAPIPort())
		if err := srv.Start(); err != nil {
			logger.Error.Fatal(err.Error())
		}
	}()

	exithandler.Init(func() {
		if err := srv.Close(); err != nil {
			logger.Error.Println(err.Error())
		}

		if err := app.DB.Close(); err != nil {
			logger.Error.Println(err.Error())
		}
	})
}
