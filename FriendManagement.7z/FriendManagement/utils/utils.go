package utils

import (
	"regexp"
)

const EmailRegex = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$"

func IsValidEmail(email string) (bool, error) {
	isValid, err := regexp.MatchString(EmailRegex, email)

	if err != nil || !isValid {
		return false, err
	}

	return true, nil
}
