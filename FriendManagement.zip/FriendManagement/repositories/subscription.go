package repositories

import (
	"database/sql"
	"log"

	"FriendManagement/models"
)

type ISubscriptionRepo interface {
	CreateSubscription(*models.SubscriptionRepository) error
	IsExistedSubscription(int, int) (bool, error)
	IsBlockedFriend(int, int) (bool, error)
}

type SubscriptionRepo struct {
	Db *sql.DB
}

func (_self SubscriptionRepo) CreateSubscription(subscription *models.SubscriptionRepository) error {
	tx, err := _self.Db.Begin()
	if err != nil {
		log.Fatal(err)
	}

	query := `INSERT INTO subscriptions(requestorid, targetid) VALUES ($1, $2)`
	_, err = _self.Db.Exec(query, subscription.Requestor, subscription.Target)
	if err != nil {
		return err
	}

	tx.Commit()
	return nil
}

func (_self SubscriptionRepo) IsExistedSubscription(requestorID int, targetID int) (bool, error) {
	query := `SELECT EXISTS (SELECT true FROM subscriptions WHERE requestorid=$1 AND targetid=$2)`
	var exist bool
	err := _self.Db.QueryRow(query, requestorID, targetID).Scan(&exist)
	if err != nil {
		return true, err
	}
	if exist {
		return true, nil
	}
	return false, nil
}

func (_self SubscriptionRepo) IsBlockedFriend(requestorID int, targetID int) (bool, error) {
	query := `SELECT EXISTS (SELECT true FROM blocks
		WHERE (requestorid=$1 AND targetid=$2) OR (requestorid=$2 and targetid=$1))`
	var isBlock bool
	err := _self.Db.QueryRow(query, requestorID, targetID).Scan(&isBlock)
	if err != nil {
		return true, err
	}
	if isBlock {
		return true, nil
	}
	return false, nil
}
