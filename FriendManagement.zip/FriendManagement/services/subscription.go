package services

import (
	"FriendManagement/models"
	"FriendManagement/repositories"
)

type ISubscriptionService interface {
	CreateSubscription(*models.SubscriptionService) error
	IsExistedSubscription(int, int) (bool, error)
	IsBlockedFriend(int, int) (bool, error)
}

type SubscriptionService struct {
	ISubscriptionRepo repositories.ISubscriptionRepo
}

func (_self SubscriptionService) CreateSubscription(subscriptionService *models.SubscriptionService) error {
	//Create repo input model
	subscriptionRepo := &models.SubscriptionRepository{
		Requestor: subscriptionService.Requestor,
		Target:    subscriptionService.Target,
	}
	err := _self.ISubscriptionRepo.CreateSubscription(subscriptionRepo)
	return err
}

func (_self SubscriptionService) IsExistedSubscription(requestorID int, targetID int) (bool, error) {
	exist, err := _self.ISubscriptionRepo.IsExistedSubscription(requestorID, targetID)
	return exist, err
}

func (_self SubscriptionService) IsBlockedFriend(requestorID int, targetID int) (bool, error) {
	blocked, err := _self.ISubscriptionRepo.IsBlockedFriend(requestorID, targetID)
	return blocked, err
}
