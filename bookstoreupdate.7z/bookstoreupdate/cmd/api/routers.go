package main

import (
	"bookstoreupdate/cmd/book/handlers/errors"
	"bookstoreupdate/pkg/application"

	"github.com/go-chi/chi/v5"
)

func registerRoutes(app *application.Application) *chi.Mux {
	mux := chi.NewRouter()
	mux.MethodNotAllowed(errors.MethodNotAllowedHandler)
	mux.NotFound(errors.NotFoundHandler)
	// mux.Get("/books/{bookid}", app.BookHander.GetBook)
	// mux.Use(app.BookHander.BookContext)
	// Sub routers
	mux.Route("/book", func(r chi.Router) {
		mux.Route("/{bookid}", func(router chi.Router) {
			mux.Use(app.BookHander.BookContext)
			mux.Get("/", app.BookHander.GetBook)
		})
	})
	return mux
}
