package api_model

import (
	"FriendManagement/utils"
	"errors"
)

type FriendHandler struct {
	Friends []string `json:"friends"`
}

type FriendService struct {
	FirstID  int `json:"first_id"`
	SecondID int `json:"second_id"`
}

//Repo model
type FriendRepository struct {
	FirstID  int `json:"first_id"`
	SecondID int `json:"second_id"`
}

type FriendGetFriendsHandler struct {
	Email string `json:"email"`
}
type EmailReceiveUpdateHandler struct {
	Sender string `json:"sender"`
	Text   string `json:"text"`
}

type EmailReceiveUpdateResponse struct {
	Success    bool     `json:"success"`
	Recipients []string `json:"recipients"`
}

type FriendsResponse struct {
	Success bool     `json:"success"`
	Friends []string `json:"friends"`
	Count   int      `json:"count"`
}

func (_self FriendHandler) Validate() error {
	if _self.Friends == nil {
		return errors.New("\"friends\" is required")
	}
	if len(_self.Friends) != 2 {
		return errors.New("number of email addresses must be 2")
	}
	if _self.Friends[0] == _self.Friends[1] {
		return errors.New("two email addresses must be different")
	}

	isValidFirstEmail, firstErr := utils.IsValidEmail(_self.Friends[0])
	if !isValidFirstEmail || firstErr != nil {
		return errors.New("first \"email\" is not valid. (ex: \"andy@example.com\")")
	}

	isValidSecondEmail, secondErr := utils.IsValidEmail(_self.Friends[1])
	if !isValidSecondEmail || secondErr != nil {
		return errors.New("second \"email\" is not valid. (ex: \"andy@example.com\")")
	}

	return nil
}

func (_self FriendGetFriendsHandler) Validate() error {
	if _self.Email == "" {
		return errors.New("\"email\" is required")
	}

	isValid, err := utils.IsValidEmail(_self.Email)
	if err != nil || !isValid {
		return errors.New("\"email\" format is not valid. (ex: \"andy@example.com\")")
	}

	return nil
}

func (_self EmailReceiveUpdateHandler) Validate() error {
	if _self.Sender == "" {
		return errors.New("\"sender\" is required")
	}
	if _self.Text == "" {
		return errors.New("\"text\" is required")
	}
	isValidEmail, err := utils.IsValidEmail(_self.Sender)
	if err != nil {
		return errors.New("validate \"sender\" format failed")
	}
	if !isValidEmail {
		return errors.New("\"sender\" is not valid. (ex: \"andy@example.com\")")
	}
	return nil
}
