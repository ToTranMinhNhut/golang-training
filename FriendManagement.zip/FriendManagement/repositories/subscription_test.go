package repositories

import (
	"errors"
	"testing"

	"FriendManagement/models/api_model"
	"FriendManagement/testhelpers"

	"github.com/stretchr/testify/require"
)

func TestSubscriptionRepo_CreateSubscription(t *testing.T) {
	testCases := []struct {
		name        string
		input       *api_model.SubscriptionRepository
		expectedErr error
		preparePath string
	}{
		{
			name: "Create subscription success",
			input: &api_model.SubscriptionRepository{
				Requestor: 1,
				Target:    2,
			},
			expectedErr: nil,
			preparePath: "../testhelpers/data_dump/subscription/truncate_subscription.sql",
		},
		{
			name: "Create subscription failed with error",
			input: &api_model.SubscriptionRepository{
				Requestor: 1,
				Target:    2,
			},
			expectedErr: errors.New("orm: unable to insert into subscriptions: pq: duplicate key value violates unique constraint \"constraint_subscription\""),
			preparePath: "../testhelpers/data_dump/subscription/subscription.sql",
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockDB := testhelpers.ConnectDB()
			testhelpers.PrepareDBForTest(mockDB, tc.preparePath)

			subscriptionRepo := SubscriptionRepo{
				Db: mockDB,
			}

			err := subscriptionRepo.CreateSubscription(tc.input)

			if tc.expectedErr != nil {
				require.EqualError(t, err, tc.expectedErr.Error())
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestSubscriptionRepo_IsExistedSubscription(t *testing.T) {
	testCases := []struct {
		name        string
		requestID   int
		targetid    int
		expResult   bool
		expError    error
		preparePath string
	}{
		{
			name:        "subscription exists",
			requestID:   1,
			targetid:    2,
			expResult:   true,
			expError:    nil,
			preparePath: "../testhelpers/data_dump/subscription/subscription.sql",
		},
		{
			name:        "subscription does not exist",
			requestID:   2,
			targetid:    1,
			expResult:   false,
			expError:    nil,
			preparePath: "../testhelpers/data_dump/subscription/truncate_subscription.sql",
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockDB := testhelpers.ConnectDB()
			testhelpers.PrepareDBForTest(mockDB, tc.preparePath)

			subscriptionRepo := SubscriptionRepo{
				Db: mockDB,
			}

			result, err := subscriptionRepo.IsExistedSubscription(tc.requestID, tc.targetid)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expResult, result)
			}
		})
	}
}

func TestSubsripctionRepo_IsBlockedFriend(t *testing.T) {
	testCases := []struct {
		name        string
		requestorID int
		targetID    int
		expResult   bool
		expError    error
		preparePath string
	}{
		{
			name:        "Is blocked",
			requestorID: 1,
			targetID:    2,
			expResult:   true,
			expError:    nil,
			preparePath: "../testhelpers/data_dump/blocking/blocking.sql",
		},
		{
			name:        "Not blocked",
			requestorID: 2,
			targetID:    1,
			expResult:   false,
			expError:    nil,
			preparePath: "../testhelpers/data_dump/blocking/truncate_blocking.sql",
		},
	}
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockDB := testhelpers.ConnectDB()
			testhelpers.PrepareDBForTest(mockDB, tc.preparePath)

			subscriptionRepo := SubscriptionRepo{
				Db: mockDB,
			}

			result, err := subscriptionRepo.IsBlockedFriend(tc.requestorID, tc.targetID)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expResult, result)
			}
		})
	}
}
