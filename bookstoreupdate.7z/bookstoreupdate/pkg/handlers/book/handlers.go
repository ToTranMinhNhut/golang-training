package book

import (
	"bookstoreupdate/internal/models"
	"bookstoreupdate/internal/service/book"
	"bookstoreupdate/pkg/db"
	"bookstoreupdate/pkg/errors"
	"context"
	"fmt"
	"log"
	"net/http"
	"strconv"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/render"
)

// Service struct containing list of dependency from service order
type BookHander struct {
	service book.BookDB
}

func NewBookHandler() *BookHander {
	handler := &BookHander{}
	return handler
}

var BookIdKey = "bookid"

func (handler *BookHander) BookContext(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		bookId := chi.URLParam(r, "bookid")
		log.Println("bookid ", bookId)
		if bookId == "" {
			render.Render(w, r, errors.ErrorRenderer(fmt.Errorf("book ID is required")))
			return
		}

		id, err := strconv.Atoi(bookId)
		if err != nil {
			render.Render(w, r, errors.ErrorRenderer(fmt.Errorf("invalid book ID")))
		}
		ctx := context.WithValue(r.Context(), BookIdKey, id)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

func (handler *BookHander) CreateBook(dbInstance *db.DB) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		book := &models.Book{}
		if err := render.Bind(r, book); err != nil {
			render.Render(w, r, errors.ErrBadRequest)
			return
		}
		handler.service.Conn = dbInstance
		if err := handler.service.AddBook(book); err != nil {
			render.Render(w, r, errors.ErrorRenderer(err))
			return
		}
		if err := render.Render(w, r, book); err != nil {
			render.Render(w, r, errors.ServerErrorRenderer(err))
			return
		}
	}
}

func (handler *BookHander) GetBook(dbInstance *db.DB) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		BookId := r.Context().Value(BookIdKey).(int)
		handler.service.Conn = dbInstance
		book, err := handler.service.GetBookById(BookId)
		if err != nil {
			if err == errors.ErrNoMatch {
				render.Render(w, r, errors.ErrNotFound)
			} else {
				render.Render(w, r, errors.ErrorRenderer(err))
			}
			return
		}
		if err := render.Render(w, r, &book); err != nil {
			render.Render(w, r, errors.ServerErrorRenderer(err))
			return
		}
	}
}
