package handlers

import (
	"encoding/json"
	"errors"
	"net/http"

	"FriendManagement/models"
	"FriendManagement/services"
)

type SubscriptionHandler struct {
	ISubscriptionService services.SubscriptionService
	IUserService         services.IUserService
}

func (_self SubscriptionHandler) CreateSubscription(w http.ResponseWriter, r *http.Request) {
	//Decode request body
	subscriptionHandler := models.SubscriptionHandler{}
	if err := json.NewDecoder(r.Body).Decode(&subscriptionHandler); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	//Validate request
	if err := subscriptionHandler.Validate(); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	//Validate and get UserID by email
	userIDs, statusCode, err := _self.GetUserIDsByEmails(subscriptionHandler)
	if err != nil {
		http.Error(w, err.Error(), statusCode)
		return
	}
	requestorUSerID, targetUserID := userIDs[0], userIDs[1]

	// Check friend connection exists
	statusCode, err = _self.isExistedSubscription(requestorUSerID, targetUserID)
	if err != nil {
		http.Error(w, err.Error(), statusCode)
		return
	}

	// //check blocking between 2 emails
	statusCode, err = _self.IsBlockedFriend(requestorUSerID, targetUserID)
	if err != nil {
		http.Error(w, err.Error(), statusCode)
		return
	}

	//Create input services model
	modelServiceInput := &models.SubscriptionService{
		Requestor: requestorUSerID,
		Target:    targetUserID,
	}
	//Call services
	if err := _self.ISubscriptionService.CreateSubscription(modelServiceInput); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Response
	json.NewEncoder(w).Encode(models.SuccessResponse{
		Success: true,
	})
}

func (_self SubscriptionHandler) GetUserIDsByEmails(subscriptionHandler models.SubscriptionHandler) ([]int, int, error) {
	//Check requestor email
	requestorUSerID, err := _self.IUserService.GetUserIDByEmail(subscriptionHandler.Requestor)
	if err != nil {
		return nil, http.StatusInternalServerError, err
	}
	if requestorUSerID == 0 {
		return nil, http.StatusBadRequest, errors.New("requestor email does not exist")
	}

	//Check target email
	targetUserID, err := _self.IUserService.GetUserIDByEmail(subscriptionHandler.Target)
	if err != nil {
		return nil, http.StatusInternalServerError, err
	}
	if targetUserID == 0 {
		return nil, http.StatusBadRequest, errors.New("target email does not exist")
	}

	return []int{requestorUSerID, targetUserID}, 0, nil
}

func (_self SubscriptionHandler) isExistedSubscription(requestorUSerID int, targetUserID int) (int, error) {
	//Check subscription existed
	exist, err := _self.ISubscriptionService.IsExistedSubscription(requestorUSerID, targetUserID)
	if err != nil {
		return http.StatusInternalServerError, err
	}
	if exist {
		return http.StatusAlreadyReported, errors.New("those email address have already subscribed the each other")
	}
	return http.StatusOK, nil
}

func (_self SubscriptionHandler) IsBlockedFriend(requestorUSerID int, targetUserID int) (int, error) {
	//Check blocked
	blocked, err := _self.ISubscriptionService.IsBlockedFriend(requestorUSerID, targetUserID)
	if err != nil {
		return http.StatusInternalServerError, err
	}
	if blocked {
		return http.StatusPreconditionFailed, errors.New("those emails have already been blocked by the each other")
	}
	return http.StatusOK, nil

}
