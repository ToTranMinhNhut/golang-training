package repositories

import (
	"FriendManagement/models/api_model"
	"FriendManagement/models/orm"
	"context"
	"database/sql"
	"log"

	"github.com/volatiletech/sqlboiler/v4/boil"
	"github.com/volatiletech/sqlboiler/v4/queries/qm"
)

type IFriendRepo interface {
	CreateFriend(*api_model.FriendRepository) error
	IsExistedFriend(int, int) (bool, error)
	IsBlockedFriend(int, int) (bool, error)
	GetFriendsByID(int) ([]int, error)
	GetBlockingFriendsByID(int) ([]int, error)
	GetBlockedFriendsByID(int) ([]int, error)
	GetUserIDsNoBlocked(int) ([]int, error)
}

type FriendRepo struct {
	Db *sql.DB
}

func (_self FriendRepo) CreateFriend(friendRepo *api_model.FriendRepository) error {
	tx, err := _self.Db.Begin()
	if err != nil {
		log.Fatal(err)
	}

	friend := orm.Friend{
		Firstid:  friendRepo.FirstID,
		Secondid: friendRepo.SecondID,
	}

	if err := friend.Insert(context.Background(), _self.Db, boil.Infer()); err != nil {
		return err
	}

	tx.Commit()
	return nil
}

func (_self FriendRepo) IsExistedFriend(firstUserID int, secondUserID int) (bool, error) {

	// query := `SELECT EXISTS (SELECT true FROM friends
	// 	 WHERE (firstid IN ($1, $2) AND secondid IN ($1, $2)))`
	// var existed bool
	// err := _self.Db.QueryRow(query, firstUserID, secondUserID).Scan(&existed)

	existed, err := orm.Friends(
		qm.WhereIn("firstid in ?", firstUserID, secondUserID),
		qm.AndIn("secondid in ?", firstUserID, secondUserID)).
		Exists(context.Background(), _self.Db)

	if err != nil {
		return true, err
	}
	if existed {
		return true, nil
	}
	return false, nil
}

func (_self FriendRepo) IsBlockedFriend(firstUserID int, secondUserID int) (bool, error) {
	// query := `SELECT EXISTS (SELECT true FROM blocks
	// 	 WHERE (requestorid IN ($1, $2) AND targetid IN ($1, $2)))`

	// var isBlocked bool
	// err := _self.Db.QueryRow(query, firstUserID, secondUserID).Scan(&isBlocked)

	isBlocked, err := orm.Blocks(
		qm.WhereIn("requestorid in ?", firstUserID, secondUserID),
		qm.AndIn("targetid in ?", firstUserID, secondUserID)).
		Exists(context.Background(), _self.Db)

	if err != nil {
		return true, err
	}
	if isBlocked {
		return true, nil
	}

	return false, nil
}

func (_self FriendRepo) GetFriendsByID(userID int) ([]int, error) {
	tx, err := _self.Db.Begin()
	if err != nil {
		log.Fatal(err)
	}

	var friendListID = make([]int, 0)

	friendSlice, err := orm.Friends(
		qm.Select(orm.FriendColumns.Firstid, orm.FriendColumns.Secondid),
		qm.Where("firstid = ?", userID), qm.Or("secondid = ?", userID)).
		All(context.Background(), _self.Db)

	if err != nil {
		return nil, err
	}
	for _, f := range friendSlice {
		if f.Firstid == userID {
			friendListID = append(friendListID, f.Secondid)
		}
		if f.Secondid == userID {
			friendListID = append(friendListID, f.Firstid)
		}
	}

	tx.Commit()
	return friendListID, err
}

func (_self FriendRepo) GetBlockingFriendsByID(userID int) ([]int, error) {
	tx, err := _self.Db.Begin()
	if err != nil {
		log.Fatal(err)
	}

	var blockingListID = make([]int, 0)

	blockingFriends, err := orm.Blocks(
		qm.Select(orm.BlockColumns.Requestorid),
		qm.Where("targetid = ?", userID)).
		All(context.Background(), _self.Db)

	if err != nil {
		return nil, err
	}

	for _, f := range blockingFriends {
		blockingListID = append(blockingListID, f.Requestorid)
	}
	tx.Commit()
	return blockingListID, err
}

func (_self FriendRepo) GetBlockedFriendsByID(userID int) ([]int, error) {
	var blockedListID = make([]int, 0)

	blockedFriends, err := orm.Blocks(
		qm.Select(orm.BlockColumns.Targetid),
		qm.Where("requestorid = ?", userID)).
		All(context.Background(), _self.Db)

	if err != nil {
		return nil, err
	}

	for _, f := range blockedFriends {
		blockedListID = append(blockedListID, f.Targetid)
	}

	return blockedListID, err
}

func (_self FriendRepo) GetUserIDsNoBlocked(userID int) ([]int, error) {
	query := `SELECT DISTINCT val.ID FROM (
					SELECT u.ID FROM users u
						JOIN friends f ON (u.id = f.firstid or u.id = f.secondid)
							WHERE u.id <> $1 AND (f.firstid = $1 or f.secondid = $1)
					UNION
					SELECT u.ID FROM subscriptions s
						JOIN users u ON s.targetid = u.id
							WHERE u.id <> $1
				) AS val WHERE NOT EXISTS (
				    SELECT 1 FROM blocks b WHERE b.requestorid = val.id AND b.targetid = $1
				)`
	rows, err := _self.Db.Query(query, userID)
	if err != nil {
		return nil, err
	}

	UserIDs := make([]int, 0)
	for rows.Next() {
		var id int
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		UserIDs = append(UserIDs, id)
	}
	return UserIDs, nil
}
