package handlers

type FriendHandler struct {
}
