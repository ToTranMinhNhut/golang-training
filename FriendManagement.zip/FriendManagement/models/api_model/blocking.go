package api_model

import (
	"errors"

	"FriendManagement/utils"
)

type BlockingHandler struct {
	Requestor string `json:"requestor"`
	Target    string `json:"target"`
}

type BlockingService struct {
	Requestor int `json:"requestor"`
	Target    int `json:"target"`
}

type BlockingRepository struct {
	Requestor int `json:"requestor"`
	Target    int `json:"target"`
}

func (_self BlockingHandler) Validate() error {
	if _self.Requestor == "" {
		return errors.New("\"requestor\" is required")
	}

	if _self.Target == "" {
		return errors.New("\"target\" is required")
	}

	if _self.Target == _self.Requestor {
		return errors.New("two email addresses must be different")
	}

	isValidRequestEmail, requestErr := utils.IsValidEmail(_self.Requestor)
	if !isValidRequestEmail || requestErr != nil {
		return errors.New("\"requestor\" format is not valid. (ex: \"andy@example.com\")")
	}

	isValidTargetEmail, targetErr := utils.IsValidEmail(_self.Target)
	if !isValidTargetEmail || targetErr != nil {
		return errors.New("\"target\" format is not valid. (ex: \"andy@example.com\")")
	}
	return nil
}
