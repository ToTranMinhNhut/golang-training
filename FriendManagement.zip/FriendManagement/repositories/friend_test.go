package repositories

import (
	"FriendManagement/models"
	"FriendManagement/testhelpers"
	"database/sql"
	"errors"
	"testing"

	"github.com/stretchr/testify/require"
)

func TestFriendRepo_CreateFriend(t *testing.T) {
	testCases := []struct {
		name        string
		input       *models.FriendRepository
		expError    error
		mockDB      *sql.DB
		preparePath string
	}{
		{
			name: "Create friend is success",
			input: &models.FriendRepository{
				FirstID:  1,
				SecondID: 2,
			},
			expError:    nil,
			preparePath: "./testhelpers/preparedata",
			mockDB:      testhelpers.ConnectDB(),
		},
		{
			name: "Create failed with error",
			input: &models.FriendRepository{
				FirstID:  1,
				SecondID: 2,
			},
			expError:    errors.New("pq: duplicate key value violates unique constraint \"constraint_friends\""),
			preparePath: "../testhelpers/preparedata",
			mockDB:      testhelpers.ConnectDB(),
		},
	}
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			// Given
			testhelpers.PrepareDBForTest(tc.mockDB, tc.preparePath)

			friendRepo := FriendRepo{
				Db: tc.mockDB,
			}

			// When
			err := friendRepo.CreateFriend(tc.input)

			// Then
			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestFriendRepo_IsExistedFriend(t *testing.T) {
	testCases := []struct {
		name         string
		firstUserID  int
		secondUserID int
		expResult    bool
		expError     error
		mockDB       *sql.DB
		preparePath  string
	}{
		{
			name:         "Friend is existed",
			firstUserID:  1,
			secondUserID: 2,
			expResult:    true,
			expError:     nil,
			mockDB:       testhelpers.ConnectDB(),
			preparePath:  "../testhelpers/preparedata",
		},
		{
			name:         "Friend  is not exist",
			firstUserID:  1,
			secondUserID: 4,
			expResult:    false,
			expError:     nil,
			mockDB:       testhelpers.ConnectDB(),
			preparePath:  "../testhelpers/preparedata",
		},
	}
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			// Given
			testhelpers.PrepareDBForTest(tc.mockDB, tc.preparePath)

			friendRepo := FriendRepo{
				Db: tc.mockDB,
			}

			// When
			resutl, err := friendRepo.IsExistedFriend(tc.firstUserID, tc.secondUserID)

			// Then
			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expResult, resutl)
			}
		})
	}
}

func TestFriendRepo_IsBlockedFriend(t *testing.T) {
	testCases := []struct {
		name         string
		firstUserID  int
		secondUserID int
		expResult    bool
		expError     error
		mockDB       *sql.DB
		preparePath  string
	}{
		{
			name:         "Blocked friend is existed",
			firstUserID:  1,
			secondUserID: 2,
			expResult:    true,
			expError:     nil,
			mockDB:       testhelpers.ConnectDB(),
			preparePath:  "../testhelpers/preparedata",
		},
		{
			name:         "Blocked friend is not existed",
			firstUserID:  3,
			secondUserID: 4,
			expResult:    false,
			expError:     nil,
			mockDB:       testhelpers.ConnectDB(),
			preparePath:  "../testhelpers/preparedata",
		},
	}
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			// Given
			testhelpers.PrepareDBForTest(tc.mockDB, tc.preparePath)

			friendRepo := FriendRepo{
				Db: tc.mockDB,
			}

			// When
			resutl, err := friendRepo.IsExistedFriend(tc.firstUserID, tc.secondUserID)

			// Then
			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expResult, resutl)
			}
		})
	}
}

func TestFriendRepo_GetFriendsByID(t *testing.T) {
	testCases := []struct {
		name        string
		input       int
		expResult   []int
		expError    error
		preparePath string
		mockDB      *sql.DB
	}{
		{
			name:        "Get friends list success",
			input:       1,
			expResult:   []int{2},
			expError:    nil,
			preparePath: "../testhelpers/preparedata",
			mockDB:      testhelpers.ConnectDB(),
		},
		{
			name:        "Get friend list failed with error",
			input:       4,
			expResult:   nil,
			expError:    errors.New("Friend is not exists"),
			preparePath: "../testhelpers/preparedata",
			mockDB:      testhelpers.ConnectDB(),
		},
	}
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			// Given
			testhelpers.PrepareDBForTest(tc.mockDB, tc.preparePath)

			friendRepo := FriendRepo{
				Db: tc.mockDB,
			}

			// When
			resutl, err := friendRepo.GetFriendsByID(tc.input)

			// Then
			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expResult, resutl)
			}
		})
	}
}

func TestFriendRepo_GetBlockingFriendsByID(t *testing.T) {
	testCases := []struct {
		name           string
		input          int
		expectedResult []int
		expectedErr    error
		preparePath    string
		mockDb         *sql.DB
	}{
		{
			name:           "Get blocking friends list success",
			input:          2,
			expectedResult: []int{1},
			expectedErr:    nil,
			preparePath:    "../testhelpers/preparedata",
			mockDb:         testhelpers.ConnectDB(),
		},
		{
			name:           "Get blocking friends failed with error",
			input:          4,
			expectedResult: nil,
			expectedErr:    errors.New("Blocking friend is not is exists"),
			preparePath:    "../testhelpers/preparedata",
			mockDb:         testhelpers.ConnectDB(),
		},
	}

	for _, testCase := range testCases {
		t.Run(testCase.name, func(t *testing.T) {
			// Given
			testhelpers.PrepareDBForTest(testCase.mockDb, testCase.preparePath)

			friendRepo := FriendRepo{
				Db: testCase.mockDb,
			}

			// When
			result, err := friendRepo.GetBlockingFriendsByID(testCase.input)

			// Then
			if testCase.expectedErr != nil {
				require.EqualError(t, err, testCase.expectedErr.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, testCase.expectedResult, result)
			}
		})
	}
}

func TestFriendRepo_GetBlockedFriendsByID(t *testing.T) {
	testCases := []struct {
		name           string
		input          int
		expectedResult []int
		expectedErr    error
		preparePath    string
		mockDb         *sql.DB
	}{
		{
			name:           "Get blocked friend list success",
			input:          2,
			expectedResult: []int{1},
			expectedErr:    nil,
			preparePath:    "../testhelpers/preparedata",
			mockDb:         testhelpers.ConnectDB(),
		},
		{
			name:           "Get blocked friend list failed with error",
			input:          4,
			expectedResult: nil,
			expectedErr:    errors.New("Blocked friend is not is exists"),
			preparePath:    "../testhelpers/preparedata",
			mockDb:         testhelpers.ConnectDB(),
		},
	}

	for _, testCase := range testCases {
		t.Run(testCase.name, func(t *testing.T) {
			// Given
			testhelpers.PrepareDBForTest(testCase.mockDb, testCase.preparePath)

			friendRepo := FriendRepo{
				Db: testCase.mockDb,
			}

			// When
			result, err := friendRepo.GetBlockingFriendsByID(testCase.input)

			// Then
			if testCase.expectedErr != nil {
				require.EqualError(t, err, testCase.expectedErr.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, testCase.expectedResult, result)
			}
		})
	}
}

func TestFriendRepo_GetUserIDsNoBlocked(t *testing.T) {
	testCases := []struct {
		name           string
		input          int
		expectedResult []int
		expectedErr    error
		preparePath    string
		mockDb         *sql.DB
	}{
		{
			name:           "Get success with no block",
			input:          1,
			expectedResult: []int{2},
			expectedErr:    nil,
			preparePath:    "../testhelpers/preparedata",
			mockDb:         testhelpers.ConnectDB(),
		},
		{
			name:           "Get success with removed block",
			input:          2,
			expectedResult: []int{},
			expectedErr:    nil,
			preparePath:    "../testhelpers/preparedata",
			mockDb:         testhelpers.ConnectDB(),
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			// Given
			testhelpers.PrepareDBForTest(tc.mockDb, tc.preparePath)

			friendRepo := FriendRepo{
				Db: tc.mockDb,
			}

			// When
			result, err := friendRepo.GetUserIDsNoBlocked(tc.input)

			// Then
			if tc.expectedErr != nil {
				require.EqualError(t, err, tc.expectedErr.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expectedResult, result)
			}
		})
	}
}
