package handlers

import (
	"FriendManagement/models/api_model"

	"github.com/stretchr/testify/mock"
)

type MockBlockingService struct {
	mock.Mock
}

func (_self *MockBlockingService) CreateBlocking(service *api_model.BlockingService) error {
	args := _self.Called(service)

	var r error
	if args.Get(0) != nil {
		r = args.Get(0).(error)
	}
	return r
}

func (_self *MockBlockingService) IsExistedBlocking(requestor int, target int) (bool, error) {
	args := _self.Called(requestor, target)
	r1 := args.Get(0).(bool)

	var r2 error
	if args.Get(1) != nil {
		r2 = args.Get(1).(error)
	}
	return r1, r2

}
