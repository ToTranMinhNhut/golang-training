-- drop table users, friends, subscriptions, blocks;

create table if not exists public.users
(
    id int not null generated always as identity primary key,
    email varchar(100) not null
);

ALTER TABLE users ADD CONSTRAINT constraint_email UNIQUE (email);

-- drop table public.useremails

create table if not exists public.friends
(
    id int not null generated always as identity primary key,
    firstid int not null,
    secondid int not null,
    constraint firstemail_fk foreign key (firstid) references public.users(id),
    constraint secondemail_fk foreign key (secondid) references public.users(id)
);

ALTER TABLE friends ADD CONSTRAINT constraint_friends UNIQUE (firstid, secondid);

-- drop table public.friends

create table if not exists public.subscriptions
(
    id int not null generated always as identity primary key,
    requestorid int not null,
    targetid int not null,
    constraint requestid_fk foreign key (requestorid) references public.users(id),
    constraint targetid_fk foreign key (targetid) references public.users(id)
);

ALTER TABLE subscriptions ADD CONSTRAINT constraint_subscription UNIQUE (requestorid, targetid);

--drop table public.subscriptions

create table if not exists public.blocks
(
    id int not null generated always as identity primary key,
    requestorid int not null,
    targetid int not null,
    constraint requestid_fk foreign key (requestorid) references public.users(id),
    constraint targetid_fk foreign key (targetid) references public.users(id)
);

ALTER TABLE blocks ADD CONSTRAINT constraint_blocking UNIQUE (requestorid, targetid);
