package book

import (
	"bookstoreupdate/internal/models"
	"bookstoreupdate/pkg/db"
	"bookstoreupdate/pkg/errors"
	"context"
	"database/sql"
	"log"
)

type BookDB struct {
	Conn *db.DB
}

func (db BookDB) AddBook(book *models.Book) error {
	ctx := context.Background()
	tx, err := db.Conn.Client.BeginTx(ctx, nil)
	if err != nil {
		log.Fatal(err)
	}
	var id int16
	query := `INSERT INTO book (bookid, title, author, price) VALUES ($1, $2, $3, $4) RETURNING bookid`
	err = tx.QueryRow(query, book.BookId, book.Title, book.Author, book.Price).Scan(&id)
	if err != nil {
		tx.Rollback()
		return err
	}
	err = tx.Commit()
	if err != nil {
		log.Fatal(err)
	}
	return nil
}

func (db BookDB) GetBookById(BookId int) (models.Book, error) {
	ctx := context.Background()
	tx, err := db.Conn.Client.BeginTx(ctx, nil)
	if err != nil {
		log.Fatal(err)
	}
	book := models.Book{}
	query := `SELECT * FROM book WHERE bookid = $1;`
	row := tx.QueryRow(query, BookId)
	switch err := row.Scan(&book.BookId, &book.Title, &book.Author, &book.Price); err {
	case sql.ErrNoRows:
		tx.Rollback()
		return book, errors.ErrNoMatch
	default:
		err = tx.Commit()
		if err != nil {
			log.Fatal(err)
		}
		return book, err
	}
}
