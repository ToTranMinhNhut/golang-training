package bookservice

// type MyMockedObject struct {
// 	mock.Mock
// }

// func (m *MyMockedObject) AddBook(book *models.Book) (bool, error) {

// 	args := m.Called(book)
// 	return args.Bool(0), args.Error(1)
// }

// var testService *BookSV
// var dbTesting *db.DB

// func initService() *BookSV {
// 	return &BookSV{
// 		Repo: &repository.BookDB{
// 			Conn: dbTesting,
// 		},
// 	}
// }

// func setup() {
// 	if err := godotenv.Load("../../../.env"); err != nil {
// 		log.Println("failed to load env vars ", err)
// 	}
// 	cfg := config.Get()
// 	db, err := db.Get(cfg.GetDBConnStr())
// 	if err != nil {
// 		log.Println("connect failed")
// 	}
// 	dbTesting = db
// 	testService = initService()
// }

// func tearDown() {
// 	dbTesting.Client.Close()
// }

// func TestMain(m *testing.M) {
// 	setup()
// 	code := m.Run()
// 	tearDown()
// 	os.Exit(code)
// }

// func Test_GetBook(t *testing.T) {
// 	book, err := testService.GetBookById(1)
// 	assert.NotNil(t, book)
// 	assert.NoError(t, err)
// }

// func Test_GetBookError(t *testing.T) {
// 	book, err := testService.GetBookById(199)
// 	assert.Empty(t, book)
// 	assert.Error(t, err)
// }

// func Test_AddBook(t *testing.T) {
// 	book := &models.Book{
// 		BookId: 60,
// 		Title:  "ttt",
// 		Author: "a",
// 		Price:  260,
// 	}

// 	err := testService.AddBook(book)
// 	assert.NoError(t, err)
// }

// func Test_AddBookError(t *testing.T) {
// 	book := &models.Book{
// 		BookId: 18,
// 		Title:  "ttt",
// 		Author: "a",
// 		Price:  260,
// 	}
// 	err := testService.AddBook(book)
// 	assert.Error(t, err)
// }

// func Test_GetBookTableDriven(t *testing.T) {
// 	var testBooks = []struct {
// 		id       int
// 		expTitle string
// 	}{
// 		{1, "Zebra in Greek"},
// 		{2, "Into the air"},
// 		{3, "Clean code"},
// 		{4, "Design patern"},
// 		{-1, "aa"},
// 	}

// 	for _, tb := range testBooks {
// 		testname := fmt.Sprintf("%d", tb.id)
// 		t.Run(testname, func(t *testing.T) {
// 			book := models.Book{}
// 			book, err := testService.GetBookById(tb.id)
// 			if book.Title != tb.expTitle && err != nil {
// 				t.Error("Get book was failed")
// 			}
// 		})
// 	}
// }

// func Test_AddBookTableDriver(t *testing.T) {
// 	book := &models.Book{
// 		BookId: 12,
// 		Title:  "ttat",
// 		Author: "a",
// 		Price:  260,
// 	}
// 	book1 := &models.Book{
// 		BookId: 17,
// 		Title:  "tttt",
// 		Author: "a",
// 		Price:  260,
// 	}
// 	book2 := &models.Book{
// 		BookId: 20,
// 		Title:  "ttet",
// 		Author: "a",
// 		Price:  260,
// 	}
// 	var testBooks = []struct {
// 		book *models.Book
// 		err  error
// 	}{
// 		{book, nil},
// 		{book1, nil},
// 		{book2, nil},
// 	}

// 	for _, tb := range testBooks {
// 		testname := fmt.Sprintf("%d", tb.book.BookId)
// 		t.Run(testname, func(t *testing.T) {
// 			expErr := testService.AddBook(tb.book)
// 			if expErr != nil {
// 				t.Error("Add book was failed")
// 			}
// 		})
// 	}
// }
