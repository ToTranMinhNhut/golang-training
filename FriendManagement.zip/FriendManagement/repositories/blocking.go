package repositories

import (
	"database/sql"
	"log"

	"FriendManagement/models"
)

type IBlockingRepo interface {
	CreateBlocking(*models.BlockingRepository) error
	IsExistedBlocking(int, int) (bool, error)
}

type BlockingRepo struct {
	Db *sql.DB
}

func (_self BlockingRepo) CreateBlocking(blocking *models.BlockingRepository) error {
	tx, err := _self.Db.Begin()
	if err != nil {
		log.Fatal(err)
	}

	query := `INSERT INTO blocks(requestorid, targetid) VALUES ($1, $2)`
	_, err = _self.Db.Exec(query, blocking.Requestor, blocking.Target)
	if err != nil {
		return err
	}

	tx.Commit()
	return nil
}

func (_self BlockingRepo) IsExistedBlocking(requestorID int, targetID int) (bool, error) {
	query := `SELECT EXISTS (SELECT true FROM blocks WHERE requestorID=$1 AND targetid=$2)`
	var exist bool
	err := _self.Db.QueryRow(query, requestorID, targetID).Scan(&exist)
	if err != nil {
		return true, err
	}
	if exist {
		return true, nil
	}
	return false, nil
}
