package application

import (
	"bookstoreupdate/pkg/config"
	"bookstoreupdate/pkg/db"
	"bookstoreupdate/pkg/handlers/book"
	"log"
)

type Application struct {
	BookHander *book.BookHander
	DB         *db.DB
	Cfg        *config.Config
}

func New(bookHander *book.BookHander) (*Application, error) {
	cfg := config.Get()
	db, err := db.Get(cfg.GetDBConnStr())
	if err != nil {
		return nil, err
	}
	handler := bookHander
	log.Println("Successfully connect to database!!!")
	return &Application{
		DB:         db,
		Cfg:        cfg,
		BookHander: handler,
	}, nil
}
