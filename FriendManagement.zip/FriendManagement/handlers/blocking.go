package handlers

import (
	"encoding/json"
	"errors"
	"net/http"

	"FriendManagement/models/api_model"
	"FriendManagement/services"
)

type BlockingHandler struct {
	IBlockingService services.IBlockingService
	IUserService     services.IUserService
}

func (_self BlockingHandler) CreateBlocking(w http.ResponseWriter, r *http.Request) {
	//Decode request body
	blockingRequest := api_model.BlockingHandler{}
	if err := json.NewDecoder(r.Body).Decode(&blockingRequest); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	// Validate request
	if err := blockingRequest.Validate(); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	// Validate and get UserID by email
	userIDs, statusCode, err := _self.GetUserIDsByEmails(blockingRequest)
	if err != nil {
		http.Error(w, err.Error(), statusCode)
		return
	}
	requestorUserID, targetUserID := userIDs[0], userIDs[1]
	statusCode, err = _self.IsExistedBlocking(requestorUserID, targetUserID)
	if err != nil {
		http.Error(w, err.Error(), statusCode)
		return
	}

	//Create block services input model
	blockingServiceInput := &api_model.BlockingService{
		Requestor: requestorUserID,
		Target:    targetUserID,
	}

	//Call services
	if err := _self.IBlockingService.CreateBlocking(blockingServiceInput); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	//Response
	json.NewEncoder(w).Encode(api_model.SuccessResponse{
		Success: true,
	})
}

func (_self BlockingHandler) GetUserIDsByEmails(blockingHandler api_model.BlockingHandler) ([]int, int, error) {
	// Get user id of the requestor
	requestorUserID, err := _self.IUserService.GetUserIDByEmail(blockingHandler.Requestor)

	if err != nil {
		return nil, http.StatusInternalServerError, err
	}
	if requestorUserID == 0 {
		return nil, http.StatusBadRequest, errors.New("the requestor does not exist")
	}

	// Get user id of the target
	targetUserID, err := _self.IUserService.GetUserIDByEmail(blockingHandler.Target)
	if err != nil {
		return nil, http.StatusInternalServerError, err
	}
	if targetUserID == 0 {
		return nil, http.StatusBadRequest, errors.New("the target does not exist")
	}

	//Check blocked
	return []int{requestorUserID, targetUserID}, 0, nil
}

func (_self BlockingHandler) IsExistedBlocking(requestorUserID int, targetUserID int) (int, error) {
	blocked, err := _self.IBlockingService.IsExistedBlocking(requestorUserID, targetUserID)
	if err != nil {
		return http.StatusInternalServerError, err
	}
	if blocked {
		return http.StatusPreconditionFailed, errors.New("target's email have already been blocked by requestor's email")
	}
	return http.StatusOK, nil

}
