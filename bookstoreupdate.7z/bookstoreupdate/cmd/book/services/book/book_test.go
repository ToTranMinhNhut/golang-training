package book

import "testing"

func Test_GetBook(t testing.T) {
	// do test
}
