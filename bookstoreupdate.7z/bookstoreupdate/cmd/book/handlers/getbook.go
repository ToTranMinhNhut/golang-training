package handlers

// import (
// 	"bookstoreupdate/pkg/application"
// 	"net/http"
// )

// func Do(app *application.Application) http.Handle {
// 	return func(w http.ResponseWriter, r *http.Request) {
// 		w.Write([]byte("hi"))
// 	}
// }
