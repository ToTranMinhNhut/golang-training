package handlers

import (
	"bytes"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"FriendManagement/models/api_model"

	"github.com/stretchr/testify/require"
)

func TestSubscriptionService_CreateSubscription(t *testing.T) {

	type mockGetUserIDByEmail struct {
		input  string
		result int
		err    error
	}

	type mockIsExistedSubscription struct {
		requestorID int
		targetID    int
		result      bool
		err         error
	}

	type mockIsBlockedFriend struct {
		requestorID int
		targetID    int
		result      bool
		err         error
	}

	type mockCreateSubscription struct {
		input *api_model.SubscriptionService
		err   error
	}
	testCases := []struct {
		name                      string
		requestBody               interface{}
		expResponseBody           string
		expResponseStatus         int
		mockGetRequestorUserID    mockGetUserIDByEmail
		mockGetTargetUserID       mockGetUserIDByEmail
		mockIsExistedSubscription mockIsExistedSubscription
		mockIsBlocked             mockIsBlockedFriend
		mockCreateSubscription    mockCreateSubscription
	}{
		{
			name: "Create success",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
				"target":    "test@example.com",
			},
			expResponseBody:   "{\"success\":true}\n",
			expResponseStatus: http.StatusOK,
			mockGetRequestorUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetTargetUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 2,
				err:    nil,
			},
			mockIsExistedSubscription: mockIsExistedSubscription{
				requestorID: 1,
				targetID:    2,
				result:      false,
				err:         nil,
			},
			mockIsBlocked: mockIsBlockedFriend{
				requestorID: 1,
				targetID:    2,
				result:      false,
				err:         nil,
			},
			mockCreateSubscription: mockCreateSubscription{
				input: &api_model.SubscriptionService{
					Requestor: 1,
					Target:    2,
				},
				err: nil,
			},
		},
		{
			name: "Create failed with error",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
				"target":    "test@example.com",
			},
			expResponseBody:   "failed with error\n",
			expResponseStatus: http.StatusInternalServerError,
			mockGetRequestorUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetTargetUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 2,
				err:    nil,
			},
			mockIsExistedSubscription: mockIsExistedSubscription{
				requestorID: 1,
				targetID:    2,
				result:      false,
				err:         nil,
			},
			mockIsBlocked: mockIsBlockedFriend{
				requestorID: 1,
				targetID:    2,
				result:      false,
				err:         nil,
			},
			mockCreateSubscription: mockCreateSubscription{
				input: &api_model.SubscriptionService{
					Requestor: 1,
					Target:    2,
				},
				err: errors.New("failed with error"),
			},
		},
		{
			name: "Body no data",
			requestBody: map[string]interface{}{
				"": "",
			},
			expResponseBody:   "\"requestor\" is required\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "No target email",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
			},
			expResponseBody:   "\"target\" is required\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "Requestor email is invalid",
			requestBody: map[string]interface{}{
				"requestor": "andy",
				"target":    "test@example.com",
			},
			expResponseBody:   "\"requestor\" format is not valid. (ex: \"andy@example.com\")\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "Target email is invalid",
			requestBody: map[string]interface{}{
				"requestor": "test@example.com",
				"target":    "andy",
			},
			expResponseBody:   "\"target\" format is not valid. (ex: \"andy@example.com\")\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "Two email addresses must be different",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
				"target":    "andy@example.com",
			},
			expResponseBody:   "two email addresses must be different\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "Get requestor user ID failed with error",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
				"target":    "test@example.com",
			},
			expResponseBody:   "get requestor userID failed with error\n",
			expResponseStatus: http.StatusInternalServerError,
			mockGetRequestorUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 0,
				err:    errors.New("get requestor userID failed with error"),
			},
		},
		{
			name: "Get target user ID failed with error",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
				"target":    "test@example.com",
			},
			expResponseBody:   "get target userID failed with error\n",
			expResponseStatus: http.StatusInternalServerError,
			mockGetRequestorUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetTargetUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 0,
				err:    errors.New("get target userID failed with error"),
			},
		},
		{
			name: "Requestor userID is not exist",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
				"target":    "test@example.com",
			},
			expResponseBody:   "requestor email does not exist\n",
			expResponseStatus: http.StatusBadRequest,
			mockGetRequestorUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 0,
				err:    nil,
			},
		},
		{
			name: "Target userID is not exist",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
				"target":    "test@example.com",
			},
			expResponseBody:   "target email does not exist\n",
			expResponseStatus: http.StatusBadRequest,
			mockGetRequestorUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetTargetUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 0,
				err:    nil,
			},
		},
		{
			name: "Check exist subscription failed with error",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
				"target":    "test@example.com",
			},
			expResponseBody:   "failed with error\n",
			expResponseStatus: http.StatusInternalServerError,
			mockGetRequestorUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetTargetUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 2,
				err:    nil,
			},
			mockIsExistedSubscription: mockIsExistedSubscription{
				requestorID: 1,
				targetID:    2,
				result:      false,
				err:         errors.New("failed with error"),
			},
		},
		{
			name: "Existed subscription",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
				"target":    "test@example.com",
			},
			expResponseBody:   "those email address have already subscribed the each other\n",
			expResponseStatus: http.StatusAlreadyReported,
			mockGetRequestorUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetTargetUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 2,
				err:    nil,
			},
			mockIsExistedSubscription: mockIsExistedSubscription{
				requestorID: 1,
				targetID:    2,
				result:      true,
				err:         nil,
			},
		},
		{
			name: "Check is blocked friend is failed with error",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
				"target":    "test@example.com",
			},
			expResponseBody:   "failed with error\n",
			expResponseStatus: http.StatusInternalServerError,
			mockGetRequestorUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetTargetUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 2,
				err:    nil,
			},
			mockIsExistedSubscription: mockIsExistedSubscription{
				requestorID: 1,
				targetID:    2,
				result:      false,
				err:         nil,
			},
			mockIsBlocked: mockIsBlockedFriend{
				requestorID: 1,
				targetID:    2,
				result:      false,
				err:         errors.New("failed with error"),
			},
		},

		{
			name: "Is Blocked by each other",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
				"target":    "test@example.com",
			},
			expResponseBody:   "those emails have already been blocked by the each other\n",
			expResponseStatus: http.StatusPreconditionFailed,
			mockGetRequestorUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetTargetUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 2,
				err:    nil,
			},
			mockIsExistedSubscription: mockIsExistedSubscription{
				requestorID: 1,
				targetID:    2,
				result:      false,
				err:         nil,
			},
			mockIsBlocked: mockIsBlockedFriend{
				requestorID: 1,
				targetID:    2,
				result:      true,
				err:         nil,
			},
		},
	}
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			//Given
			mockUserService := new(MockUserService)
			mockSubscriptionService := new(MockSubscriptionService)

			mockUserService.On("GetUserIDByEmail", tc.mockGetRequestorUserID.input).
				Return(tc.mockGetRequestorUserID.result, tc.mockGetRequestorUserID.err)

			mockUserService.On("GetUserIDByEmail", tc.mockGetTargetUserID.input).
				Return(tc.mockGetTargetUserID.result, tc.mockGetTargetUserID.err)

			mockSubscriptionService.On("IsExistedSubscription", tc.mockIsExistedSubscription.requestorID, tc.mockIsExistedSubscription.targetID).
				Return(tc.mockIsExistedSubscription.result, tc.mockIsExistedSubscription.err)

			mockSubscriptionService.On("IsBlockedFriend", tc.mockIsBlocked.requestorID, tc.mockIsBlocked.targetID).
				Return(tc.mockIsBlocked.result, tc.mockIsBlocked.err)

			mockSubscriptionService.On("CreateSubscription", tc.mockCreateSubscription.input).
				Return(tc.mockCreateSubscription.err)

			handlers := SubscriptionHandler{
				IUserService:         mockUserService,
				ISubscriptionService: mockSubscriptionService,
			}

			requestBody, err := json.Marshal(tc.requestBody)
			if err != nil {
				t.Error(err)
			}
			//When
			req, err := http.NewRequest(http.MethodPost, "/subscription", bytes.NewBuffer(requestBody))
			if err != nil {
				t.Error(err)
			}

			responseRecorder := httptest.NewRecorder()
			handler := http.HandlerFunc(handlers.CreateSubscription)
			handler.ServeHTTP(responseRecorder, req)

			// Then
			require.Equal(t, tc.expResponseStatus, responseRecorder.Code)
			require.Equal(t, tc.expResponseBody, responseRecorder.Body.String())
		})
	}

}
