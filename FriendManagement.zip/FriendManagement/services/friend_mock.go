package services

import (
	"FriendManagement/models/api_model"

	"github.com/stretchr/testify/mock"
)

type MockFriendRepo struct {
	mock.Mock
}

func (_self *MockFriendRepo) CreateFriend(friend *api_model.FriendRepository) error {
	args := _self.Called(friend)

	var r error
	if args.Get(0) != nil {
		r = args.Get(0).(error)
	}
	return r
}

func (_self *MockFriendRepo) IsExistedFriend(firstUserID int, secondUserID int) (bool, error) {
	args := _self.Called(firstUserID, secondUserID)
	r1 := args.Get(0).(bool)

	var r2 error
	if args.Get(1) != nil {
		r2 = args.Get(1).(error)
	}
	return r1, r2
}

func (_self *MockFriendRepo) IsBlockedFriend(firstUserID int, secondUserID int) (bool, error) {
	args := _self.Called(firstUserID, secondUserID)
	r1 := args.Get(0).(bool)

	var r2 error
	if args.Get(1) != nil {
		r2 = args.Get(1).(error)
	}
	return r1, r2
}

func (_self *MockFriendRepo) GetFriendsByID(userID int) ([]int, error) {
	args := _self.Called(userID)
	r1 := args.Get(0).([]int)

	var r2 error
	if args.Get(1) != nil {
		r2 = args.Get(1).(error)
	}
	return r1, r2
}

func (_self *MockFriendRepo) GetBlockingFriendsByID(userID int) ([]int, error) {
	args := _self.Called(userID)
	r1 := args.Get(0).([]int)

	var r2 error
	if args.Get(1) != nil {
		r2 = args.Get(1).(error)
	}
	return r1, r2
}

func (_self *MockFriendRepo) GetBlockedFriendsByID(userID int) ([]int, error) {
	args := _self.Called(userID)
	r1 := args.Get(0).([]int)

	var r2 error
	if args.Get(1) != nil {
		r2 = args.Get(1).(error)
	}
	return r1, r2
}

func (_self *MockFriendRepo) GetUserIDsNoBlocked(userID int) ([]int, error) {
	args := _self.Called(userID)
	r1 := args.Get(0).([]int)

	var r2 error
	if args.Get(1) != nil {
		r2 = args.Get(1).(error)
	}
	return r1, r2
}
