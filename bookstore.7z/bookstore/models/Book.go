package models

import (
	"fmt"
	"net/http"
)

type Book struct {
	BookId int16  `json:"bookid"`
	Title  string `json:"title"`
	Author string `json:"author"`
	Price  int64  `json:"price"`
}

type BookList struct {
	Books []Book `json:"books"`
}

func (i *Book) Bind(r *http.Request) error {
	if i.Title == "" {
		return fmt.Errorf("title is a required field")
	}
	return nil
}
func (*BookList) Render(w http.ResponseWriter, r *http.Request) error {
	return nil
}
func (*Book) Render(w http.ResponseWriter, r *http.Request) error {
	return nil
}

// const (
// 	host     = "localhost"
// 	port     = 5432
// 	user     = "postgres"
// 	password = "nhuttmt"
// 	dbname   = "bookstore"
// )

// psqlInfo := fmt.Sprintf("host=%s port=%d user=%s "+
// "password=%s dbname=%s sslmode=disable",
// host, port, user, password, dbname)
// db, err := sql.Open("postgres", psqlInfo)
// if err != nil {
// panic(err)
// }
// defer db.Close()

// err = db.Ping()
// if err != nil {
// panic(err)
// }

// // sqlStatement := ` INSERT INTO book (bookid, title, author, price) VALUES ($1, $2, $3, $4) RETURNING bookid`
// // BookId := 0
// // err = db.QueryRow(sqlStatement, 1, "Zebra in Greek", "xxx", "50").Scan(&BookId)
// // if err != nil {
// // 	panic(err)
// // }
// // fmt.Println("New record ID is:", BookId)

// sqlStatement := `SELECT * FROM book WHERE bookid=$1;`
// var book models.Book
// row := db.QueryRow(sqlStatement, 1)
// err = row.Scan(&book.BookId, &book.Title, &book.Author, &book.Price)
// switch err {
// case sql.ErrNoRows:
// fmt.Println("No rows were returned!")
// return
// case nil:
// fmt.Println(book)
// default:
// panic(book)
// }
