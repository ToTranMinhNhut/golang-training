package bookservice

import (
	"bookstoreupdate/internal/models"
	"bookstoreupdate/internal/repository"
	"log"
)

type IBookService interface {
	CreateBook(book *models.Book) error
	GetBook(BookId int) (models.Book, error)
}

type BookSV struct {
	IBookRepo repository.IBookRepo
}

func (_self *BookSV) CreateBook(book *models.Book) error {
	var id int
	id, err := _self.IBookRepo.CreateBook(book)
	if err != nil {
		return err
	}
	log.Println(id)
	return nil
}

func (_self *BookSV) GetBook(BookId int) (models.Book, error) {
	book := models.Book{}
	book, err := _self.IBookRepo.GetBook(BookId)
	return book, err
}
