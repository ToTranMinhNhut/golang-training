package repositories

import (
	"context"
	"database/sql"
	"log"

	"FriendManagement/models/api_model"
	"FriendManagement/models/orm"

	"github.com/volatiletech/sqlboiler/v4/boil"
	"github.com/volatiletech/sqlboiler/v4/queries/qm"
)

type ISubscriptionRepo interface {
	CreateSubscription(*api_model.SubscriptionRepository) error
	IsExistedSubscription(int, int) (bool, error)
	IsBlockedFriend(int, int) (bool, error)
}

type SubscriptionRepo struct {
	Db *sql.DB
}

func (_self SubscriptionRepo) CreateSubscription(subscriptionRepo *api_model.SubscriptionRepository) error {
	tx, err := _self.Db.Begin()
	if err != nil {
		log.Fatal(err)
	}

	subscription := orm.Subscription{
		Requestorid: subscriptionRepo.Requestor,
		Targetid:    subscriptionRepo.Target,
	}

	if err := subscription.Insert(context.Background(), _self.Db, boil.Infer()); err != nil {
		return err
	}

	tx.Commit()
	return nil
}

func (_self SubscriptionRepo) IsExistedSubscription(requestorID int, targetID int) (bool, error) {
	existed, err := orm.Subscriptions(qm.Where("requestorid = ?", requestorID), qm.And("targetid = ?", targetID)).
		Exists(context.Background(), _self.Db)

	if err != nil {
		return true, err
	}
	if existed {
		return true, nil
	}
	return false, nil
}

func (_self SubscriptionRepo) IsBlockedFriend(requestorID int, targetID int) (bool, error) {
	query := `SELECT EXISTS (SELECT true FROM blocks
		WHERE (requestorid=$1 AND targetid=$2) OR (requestorid=$2 and targetid=$1))`
	var isBlock bool
	err := _self.Db.QueryRow(query, requestorID, targetID).Scan(&isBlock)
	if err != nil {
		return true, err
	}
	if isBlock {
		return true, nil
	}
	return false, nil
}
