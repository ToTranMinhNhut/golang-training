package repositories

import (
	"database/sql"
	"errors"
	"testing"

	"FriendManagement/models"
	"FriendManagement/testhelpers"

	"github.com/stretchr/testify/require"
)

func TestSubscriptionRepo_CreateSubscription(t *testing.T) {
	testCases := []struct {
		name        string
		input       *models.SubscriptionRepository
		expectedErr error
		preparePath string
		mockDB      *sql.DB
	}{
		{
			name: "Create subscription success",
			input: &models.SubscriptionRepository{
				Requestor: 1,
				Target:    2,
			},
			expectedErr: nil,
			preparePath: "../testhelpers/preparedata",
			mockDB:      testhelpers.ConnectDB(),
		},
		{
			name: "Create subscription failed with error",
			input: &models.SubscriptionRepository{
				Requestor: 1,
				Target:    2,
			},
			expectedErr: errors.New("pq: duplicate key value violates unique constraint \"constraint_subscription\""),
			preparePath: "../testhelpers/preparedata",
			mockDB:      testhelpers.ConnectDB(),
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			// Given
			testhelpers.PrepareDBForTest(tc.mockDB, tc.preparePath)

			subscriptionRepo := SubscriptionRepo{
				Db: tc.mockDB,
			}

			// When
			err := subscriptionRepo.CreateSubscription(tc.input)

			// Then
			if tc.expectedErr != nil {
				require.EqualError(t, err, tc.expectedErr.Error())
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestSubscriptionRepo_IsExistedSubscription(t *testing.T) {
	testCases := []struct {
		name        string
		requestID   int
		targetid    int
		expResult   bool
		expError    error
		preparePath string
		mockDB      *sql.DB
	}{
		{
			name:        "subscription exists",
			requestID:   1,
			targetid:    2,
			expResult:   true,
			expError:    nil,
			mockDB:      testhelpers.ConnectDB(),
			preparePath: "../testhelpers/preparedata",
		},
		{
			name:        "subscription does not exist",
			requestID:   3,
			targetid:    4,
			expResult:   false,
			expError:    nil,
			mockDB:      testhelpers.ConnectDB(),
			preparePath: "../testhelpers/preparedata",
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			testhelpers.PrepareDBForTest(tc.mockDB, tc.preparePath)

			subscriptionRepo := SubscriptionRepo{
				Db: tc.mockDB,
			}

			result, err := subscriptionRepo.IsExistedSubscription(tc.requestID, tc.targetid)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expResult, result)
			}
		})
	}
}

func TestSubsripctionRepo_IsBlockedFriend(t *testing.T) {
	testCases := []struct {
		name        string
		requestorID int
		targetID    int
		expResult   bool
		expError    error
		mockDB      *sql.DB
		preparePath string
	}{
		{
			name:        "Is blocked",
			requestorID: 1,
			targetID:    2,
			expResult:   true,
			expError:    nil,
			mockDB:      testhelpers.ConnectDB(),
			preparePath: "../testhelpers/preparedata",
		},
		{
			name:        "Not blocked",
			requestorID: 3,
			targetID:    4,
			expResult:   false,
			expError:    nil,
			mockDB:      testhelpers.ConnectDB(),
			preparePath: "../testhelpers/preparedata",
		},
	}
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			testhelpers.PrepareDBForTest(tc.mockDB, tc.preparePath)

			subscriptionRepo := SubscriptionRepo{
				Db: tc.mockDB,
			}

			result, err := subscriptionRepo.IsBlockedFriend(tc.requestorID, tc.targetID)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expResult, result)
			}
		})
	}
}
