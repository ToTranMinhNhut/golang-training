package repositories

import (
	"FriendManagement/models"
	"FriendManagement/testhelpers"
	"database/sql"
	"errors"
	"testing"

	"github.com/stretchr/testify/require"
)

func TestBlockingRepo_CreateBlocking(t *testing.T) {
	testCases := []struct {
		name        string
		input       *models.BlockingRepository
		expError    error
		mockDB      *sql.DB
		preparePath string
	}{
		{
			name: "Create success",
			input: &models.BlockingRepository{
				Requestor: 1,
				Target:    2,
			},
			expError:    nil,
			preparePath: "../testhelpers/preparedata",
			mockDB:      testhelpers.ConnectDB(),
		},
		{
			name: "Create blocking failed with error",
			input: &models.BlockingRepository{
				Requestor: 1,
				Target:    2,
			},
			expError:    errors.New("pq: duplicate key value violates unique constraint \"constraint_blocking\""),
			mockDB:      testhelpers.ConnectDB(),
			preparePath: "../testhelpers/preparedata",
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			testhelpers.PrepareDBForTest(tc.mockDB, tc.preparePath)

			blockingRepo := BlockingRepo{
				Db: tc.mockDB,
			}

			err := blockingRepo.CreateBlocking(tc.input)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestBlockingRepo_IsExistedBlocking(t *testing.T) {
	testCases := []struct {
		name           string
		input          []int
		expectedResult bool
		expectedErr    error
		preparePath    string
		mockDb         *sql.DB
	}{
		{
			name:           "Blocking is not exist",
			input:          []int{3, 4},
			expectedResult: false,
			expectedErr:    nil,
			mockDb:         testhelpers.ConnectDB(),
			preparePath:    "../testhelpers/preparedata",
		},
		{
			name:           "Blocking existed",
			input:          []int{1, 2},
			expectedResult: true,
			expectedErr:    nil,
			preparePath:    "../testhelpers/preparedata",
			mockDb:         testhelpers.ConnectDB(),
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			// Given
			testhelpers.PrepareDBForTest(tc.mockDb, tc.preparePath)

			blockingRepo := BlockingRepo{
				Db: tc.mockDb,
			}

			// When
			result, err := blockingRepo.IsExistedBlocking(tc.input[0], tc.input[1])

			// Then
			if tc.expectedErr != nil {
				require.EqualError(t, err, tc.expectedErr.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expectedResult, result)
			}
		})
	}
}
