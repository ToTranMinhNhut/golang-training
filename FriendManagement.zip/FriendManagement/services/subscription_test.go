package services

import (
	"FriendManagement/models"
	"errors"
	"testing"

	"github.com/stretchr/testify/require"
)

func TestSubscriptionService_CreateSubscription(t *testing.T) {
	testCase := []struct {
		name                      string
		input                     *models.SubscriptionService
		expError                  error
		mockSubscriptionRepoInput *models.SubscriptionRepository
		mockError                 error
	}{
		{
			name: "create subscription successfully",
			input: &models.SubscriptionService{
				Requestor: 1,
				Target:    2,
			},
			expError: nil,
			mockSubscriptionRepoInput: &models.SubscriptionRepository{
				Requestor: 1,
				Target:    2,
			},
			mockError: nil,
		},
		{
			name: "create subscription failed",
			input: &models.SubscriptionService{
				Requestor: 1,
				Target:    2,
			},
			expError: errors.New("create failed with error"),
			mockSubscriptionRepoInput: &models.SubscriptionRepository{
				Requestor: 1,
				Target:    2,
			},
			mockError: errors.New("create failed with error"),
		},
	}

	for _, tc := range testCase {
		t.Run(tc.name, func(t *testing.T) {
			mockSubscriptionRepo := new(MockSubscriptionRepo)

			mockSubscriptionRepo.On("CreateSubscription", tc.mockSubscriptionRepoInput).
				Return(tc.mockError)

			subscriptionService := SubscriptionService{
				ISubscriptionRepo: mockSubscriptionRepo,
			}

			err := subscriptionService.CreateSubscription(tc.input)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestSubsctiptionService_IsExistedSubscription(t *testing.T) {
	testCases := []struct {
		name            string
		requestorID     int
		targetID        int
		expResult       bool
		expError        error
		mockRequestorID int
		mockTargetID    int
		mockResult      bool
		mockError       error
	}{
		{
			name:            "Verify is existed subscription success",
			requestorID:     1,
			targetID:        2,
			expResult:       true,
			expError:        nil,
			mockRequestorID: 1,
			mockTargetID:    2,
			mockResult:      true,
			mockError:       nil,
		},
		{
			name:            "Verify is existed subscription failed with error",
			requestorID:     1,
			targetID:        2,
			expResult:       false,
			expError:        errors.New("Verify is existed subscription failed with error"),
			mockRequestorID: 1,
			mockTargetID:    2,
			mockResult:      false,
			mockError:       errors.New("Verify is existed subscription failed with error"),
		},
		{
			name:            "Subscription is not exist",
			requestorID:     1,
			targetID:        2,
			expResult:       false,
			expError:        nil,
			mockRequestorID: 1,
			mockTargetID:    2,
			mockResult:      false,
			mockError:       nil,
		},
	}
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockSubscriptionRepo := new(MockSubscriptionRepo)
			mockSubscriptionRepo.On("IsExistedSubscription", tc.mockRequestorID, tc.mockTargetID).
				Return(tc.mockResult, tc.mockError)

			subscriptionService := SubscriptionService{
				ISubscriptionRepo: mockSubscriptionRepo,
			}

			result, err := subscriptionService.IsExistedSubscription(tc.requestorID, tc.targetID)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expResult, result)
			}
		})
	}
}

func TestSubscriptionService_IsBlockedFriend(t *testing.T) {
	testCases := []struct {
		name            string
		requestorID     int
		targetID        int
		expResult       bool
		expError        error
		mockRequestorID int
		mockTargetID    int
		mockResult      bool
		mockError       error
	}{
		{
			name:            "Verify is blocked friend success",
			requestorID:     1,
			targetID:        2,
			expResult:       true,
			expError:        nil,
			mockRequestorID: 1,
			mockTargetID:    2,
			mockResult:      true,
			mockError:       nil,
		},
		{
			name:            "Verify is blocked friend failed with error",
			requestorID:     1,
			targetID:        2,
			expResult:       false,
			expError:        errors.New("Verify is blocked friend failed with error"),
			mockRequestorID: 1,
			mockTargetID:    2,
			mockResult:      false,
			mockError:       errors.New("Verify is blocked friend failed with error"),
		},
		{
			name:            "Blocked friend is not exist",
			requestorID:     1,
			targetID:        2,
			expResult:       false,
			expError:        nil,
			mockRequestorID: 1,
			mockTargetID:    2,
			mockResult:      false,
			mockError:       nil,
		},
	}
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockSubscriptionRepo := new(MockSubscriptionRepo)
			mockSubscriptionRepo.On("IsBlockedFriend", tc.mockRequestorID, tc.mockTargetID).
				Return(tc.mockResult, tc.mockError)

			subscriptionService := SubscriptionService{
				ISubscriptionRepo: mockSubscriptionRepo,
			}

			result, err := subscriptionService.IsBlockedFriend(tc.requestorID, tc.targetID)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expResult, result)
			}
		})
	}
}
