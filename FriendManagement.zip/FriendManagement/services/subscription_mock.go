package services

import (
	"FriendManagement/models"

	"github.com/stretchr/testify/mock"
)

type MockSubscriptionRepo struct {
	mock.Mock
}

func (_self *MockSubscriptionRepo) CreateSubscription(subscription *models.SubscriptionRepository) error {
	args := _self.Called(subscription)

	var r error
	if args.Get(0) != nil {
		r = args.Get(0).(error)
	}

	return r
}

func (_self *MockSubscriptionRepo) IsExistedSubscription(requestorID int, targetID int) (bool, error) {
	args := _self.Called(requestorID, targetID)

	r1 := args.Get(0).(bool)
	var r2 error
	if args.Get(1) != nil {
		r2 = args.Get(1).(error)
	}

	return r1, r2
}

func (_self *MockSubscriptionRepo) IsBlockedFriend(firstUserID int, secondUserID int) (bool, error) {
	args := _self.Called(firstUserID, secondUserID)

	r1 := args.Get(0).(bool)
	var r2 error
	if args.Get(1) != nil {
		r2 = args.Get(1).(error)
	}

	return r1, r2
}
