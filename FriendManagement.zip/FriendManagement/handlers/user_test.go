package handlers

import (
	"bytes"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"FriendManagement/models/api_model"

	"github.com/stretchr/testify/require"
)

func TestUserHandler_CreateUser(t *testing.T) {
	type mockIsExistedUser struct {
		input  string
		result bool
		err    error
	}

	type mockCreateUserService struct {
		input *api_model.UserService
		err   error
	}

	testCases := []struct {
		name                  string
		requestBody           interface{}
		expResponseBody       string
		expResponseStatus     int
		mockIsExistedUser     mockIsExistedUser
		mockCreateUserService mockCreateUserService
	}{
		{
			name: "Create user is success",
			requestBody: map[string]interface{}{
				"email": "andy@example.com",
			},
			expResponseBody:   "{\"success\":true}\n",
			expResponseStatus: http.StatusOK,
			mockIsExistedUser: mockIsExistedUser{
				input:  "andy@example.com",
				result: false,
				err:    nil,
			},
			mockCreateUserService: mockCreateUserService{
				input: &api_model.UserService{
					Email: "andy@example.com",
				},
				err: nil,
			},
		},
		{
			name: "Validate request body failed",
			requestBody: map[string]interface{}{
				"email": "",
			},
			expResponseBody:   "\"email\" is required\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "Email's format is not valid",
			requestBody: map[string]interface{}{
				"email": "test",
			},
			expResponseBody:   "\"email\" format is not valid. (ex: \"andy@example.com\")\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "User email existed",
			requestBody: map[string]interface{}{
				"email": "andy@example.com",
			},
			expResponseBody:   "this email address existed\n",
			expResponseStatus: http.StatusAlreadyReported,
			mockIsExistedUser: mockIsExistedUser{
				input:  "andy@example.com",
				result: true,
				err:    nil,
			},
		},
		{
			name: "Check existed user's email with error",
			requestBody: map[string]interface{}{
				"email": "andy@example.com",
			},
			expResponseBody:   "check existed user's email process error\n",
			expResponseStatus: http.StatusInternalServerError,
			mockIsExistedUser: mockIsExistedUser{
				input:  "andy@example.com",
				result: false,
				err:    errors.New("check existed user's email process error"),
			},
		},
		{
			name: "Call services return with error",
			requestBody: map[string]interface{}{
				"email": "andy@example.com",
			},
			expResponseBody:   "services error\n",
			expResponseStatus: http.StatusInternalServerError,
			mockIsExistedUser: mockIsExistedUser{
				input:  "andy@example.com",
				result: false,
				err:    nil,
			},
			mockCreateUserService: mockCreateUserService{
				input: &api_model.UserService{
					Email: "andy@example.com",
				},
				err: errors.New("services error"),
			},
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockUserService := new(MockUserService)

			mockUserService.On("IsExistedUser", tc.mockIsExistedUser.input).
				Return(tc.mockIsExistedUser.result, tc.mockIsExistedUser.err)

			mockUserService.On("CreateUser", tc.mockCreateUserService.input).
				Return(tc.mockCreateUserService.err)

			userHandler := UserHandler{
				IUserService: mockUserService,
			}

			requestBody, err := json.Marshal(tc.requestBody)
			if err != nil {
				t.Error(err)
			}

			//When
			req, err := http.NewRequest(http.MethodPost, "/user/create", bytes.NewBuffer(requestBody))
			if err != nil {
				t.Error(err)
			}

			responseRecorder := httptest.NewRecorder()
			handler := http.HandlerFunc(userHandler.CreateUser)
			handler.ServeHTTP(responseRecorder, req)

			//Then
			require.Equal(t, tc.expResponseStatus, responseRecorder.Code)
			require.Equal(t, tc.expResponseBody, responseRecorder.Body.String())
		})
	}
}
