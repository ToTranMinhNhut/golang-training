package services

import (
	"FriendManagement/models/api_model"
	"FriendManagement/repositories"
)

type IUserService interface {
	CreateUser(*api_model.UserService) error
	IsExistedUser(string) (bool, error)
	GetUserIDByEmail(string) (int, error)
}

type UserService struct {
	IUserRepo repositories.IUserRepo
}

func (_self UserService) CreateUser(userService *api_model.UserService) error {
	userRepo := &api_model.UserRepository{
		Email: userService.Email,
	}

	err := _self.IUserRepo.CreateUser(userRepo)
	return err
}

func (_self UserService) IsExistedUser(email string) (bool, error) {
	isExsits, err := _self.IUserRepo.IsExistedUser(email)
	return isExsits, err
}

func (_self UserService) GetUserIDByEmail(email string) (int, error) {
	result, err := _self.IUserRepo.GetUserIDByEmail(email)
	return result, err
}
