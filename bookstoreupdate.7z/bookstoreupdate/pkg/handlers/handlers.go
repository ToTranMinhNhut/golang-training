package handlers

import (
	"bookstoreupdate/cmd/book/errors"
	"bookstoreupdate/cmd/book/models"
	"context"
	"fmt"
	"log"
	"net/http"
	"strconv"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/render"
)

type BookService interface {
	GetBookById(BookId int) (models.Book, error)
}

// Service struct containing list of dependency from service order
type BookHander struct {
	bookService BookService
}

func NewBookHandler() *BookHander {
	handler := &BookHander{}
	return handler
}

var BookIdKey = "bookid"

func (handler *BookHander) BookContext(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		bookId := chi.URLParam(r, "bookid")
		log.Println("book id: ", r)
		if bookId == "" {
			render.Render(w, r, errors.ErrorRenderer(fmt.Errorf("book ID is required")))
			return
		}

		id, err := strconv.Atoi(bookId)
		if err != nil {
			render.Render(w, r, errors.ErrorRenderer(fmt.Errorf("invalid book ID")))
		}
		ctx := context.WithValue(r.Context(), BookIdKey, id)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

func (handler *BookHander) GetBook(w http.ResponseWriter, r *http.Request) {
	log.Println("Get Book")

	BookId := r.Context().Value(BookIdKey).(int)
	book, err := handler.bookService.GetBookById(BookId)
	if err != nil {
		if err == errors.ErrNoMatch {
			render.Render(w, r, errors.ErrNotFound)
		} else {
			render.Render(w, r, errors.ErrorRenderer(err))
		}
		return
	}
	if err := render.Render(w, r, &book); err != nil {
		render.Render(w, r, errors.ServerErrorRenderer(err))
		return
	}
}

// func createBook(w http.ResponseWriter, r *http.Request) {
// 	book := &models.Book{}
// 	if err := render.Bind(r, book); err != nil {
// 		render.Render(w, r, ErrBadRequest)
// 		return
// 	}
// 	if err := dbInstance.AddBook(book); err != nil {
// 		render.Render(w, r, ErrorRenderer(err))
// 		return
// 	}
// 	if err := render.Render(w, r, book); err != nil {
// 		render.Render(w, r, ServerErrorRenderer(err))
// 		return
// 	}
// }

// func GetBook(dbInstance db.DB) http.HandlerFunc {
// 	return func(w http.ResponseWriter, r *http.Request) {
// 		BookId := r.Context().Value(BookIdKey).(int)
// 		book, err := dbInstance.GetBookById(BookId)
// 		if err != nil {
// 			if err == errors.ErrNoMatch {
// 				render.Render(w, r, errors.ErrNotFound)
// 			} else {
// 				render.Render(w, r, errors.ErrorRenderer(err))
// 			}
// 			return
// 		}
// 		if err := render.Render(w, r, &book); err != nil {
// 			render.Render(w, r, errors.ServerErrorRenderer(err))
// 			return
// 		}
// 	}
// }
