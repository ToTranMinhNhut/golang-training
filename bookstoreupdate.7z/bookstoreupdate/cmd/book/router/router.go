package router

import (
	"bookstoreupdate/pkg/application"
	"log"
	"net/http"

	"github.com/go-chi/chi/v5"
)

func Get(app *application.Application) *chi.Mux {
	mux := chi.NewRouter()

	mux.Get("/book", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("hi"))
	})
	log.Println("test routing")
	return mux

}
