TRUNCATE TABLE users, friends, subscriptions, blocks;

alter sequence users_id_seq RESTART WITH 1;
alter sequence subscriptions_id_seq RESTART WITH 1;

INSERT INTO users(email) VALUES ('andy@example.com');
INSERT INTO users(email) VALUES ('test@example.com');


INSERT INTO subscriptions(requestorid, targetid) VALUES (1, 2)