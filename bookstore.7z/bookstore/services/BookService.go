package services

import (
	"database/sql"

	"bookstore/models"
)

// func (db Database) GetAllBooks() (*models.ItemList, error) {
// 	list := &models.ItemList{}
// 	rows, err := db.Conn.Query("SELECT * FROM items ORDER BY ID DESC")
// 	if err != nil {
// 		return list, err
// 	}
// 	for rows.Next() {
// 		var item models.Item
// 		err := rows.Scan(&item.ID, &item.Name, &item.Description, &item.CreatedAt)
// 		if err != nil {
// 			return list, err
// 		}
// 		list.Items = append(list.Items, item)
// 	}
// 	return list, nil
// }

// func (db Database) AddItem(item *models.Item) error {
// 	var id int
// 	var createdAt string
// 	query := `INSERT INTO items (name, description) VALUES ($1, $2) RETURNING id, created_at`
// 	err := db.Conn.QueryRow(query, item.Name, item.Description).Scan(&id, &createdAt)
// 	if err != nil {
// 		return err
// 	}
// 	item.ID = id
// 	item.CreatedAt = createdAt
// 	return nil
// }

func (db Database) GetItemById(itemId int) (models.Book, error) {
	book := models.Book{}
	query := `SELECT * FROM book WHERE id = $1;`
	row := db.Conn.QueryRow(query, itemId)
	switch err := row.Scan(&book.BookId, &book.Title, &book.Author, &book.Price); err {
	case sql.ErrNoRows:
		return book, ErrNoMatch
	default:
		return book, err
	}
}
