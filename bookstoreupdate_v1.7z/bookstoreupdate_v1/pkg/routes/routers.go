package routes

import (
	"bookstoreupdate/internal/repository"
	"bookstoreupdate/internal/service/bookservice"
	"bookstoreupdate/pkg/db"
	"bookstoreupdate/pkg/handlers/book"

	"github.com/go-chi/chi/v5"
)

func RegisterRoutes(db *db.DB) *chi.Mux {
	handler := book.BookHander{
		IBookService: &bookservice.BookSV{
			IBookRepo: &repository.BookRepo{
				Conn: db,
			},
		},
	}
	mux := chi.NewRouter()
	mux.Route("/books", func(mux chi.Router) {
		mux.Post("/create", handler.CreateBook)
		mux.Get("/{bookid}", handler.GetBook)
	})
	return mux
}
