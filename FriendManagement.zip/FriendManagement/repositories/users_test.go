package repositories

import (
	"database/sql"
	"errors"
	"testing"

	"FriendManagement/models"
	"FriendManagement/testhelpers"

	"github.com/stretchr/testify/require"
)

func TestUsersRepo_CreateUser(t *testing.T) {
	testCases := []struct {
		name        string
		input       *models.UserRepository
		expectedErr error
		mockDB      *sql.DB
	}{
		{
			name: "Create user success",
			input: &models.UserRepository{
				Email: "abc@example.com",
			},
			expectedErr: nil,
			mockDB:      testhelpers.ConnectDB(),
		},
		{
			name: "Create new user failed with error",
			input: &models.UserRepository{
				Email: "test@example.com",
			},
			expectedErr: errors.New("pq: duplicate key value violates unique constraint \"constraint_email\""),
			mockDB:      testhelpers.ConnectDB(),
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockDB := tc.mockDB

			userRepo := UserRepo{
				Db: mockDB,
			}

			err := userRepo.CreateUser(tc.input)

			if tc.expectedErr != nil {
				require.EqualError(t, err, tc.expectedErr.Error())
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestUserRepo_IsExistedUser(t *testing.T) {
	testCase := []struct {
		name        string
		input       string
		expResult   bool
		expError    error
		mockDB      *sql.DB
		preparePath string
	}{
		{
			name:        "User existed",
			input:       "test@example.com",
			expResult:   true,
			expError:    nil,
			mockDB:      testhelpers.ConnectDB(),
			preparePath: "../testhelpers/preparedata",
		},
	}

	for _, tc := range testCase {
		t.Run(tc.name, func(t *testing.T) {
			testhelpers.PrepareDBForTest(tc.mockDB, tc.preparePath)

			userRepo := UserRepo{
				Db: tc.mockDB,
			}

			result, err := userRepo.IsExistedUser(tc.input)

			// Then
			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expResult, result)
			}
		})
	}
}

func TestUserRepo_GetUserIDByEmail(t *testing.T) {
	testCases := []struct {
		name           string
		input          string
		expectedResult int
		expectedErr    error
		preparePath    string
		mockDb         *sql.DB
	}{
		{
			name:           "Get UserID by email success",
			input:          "test@example.com",
			expectedResult: 1,
			expectedErr:    nil,
			mockDb:         testhelpers.ConnectDB(),
			preparePath:    "../testhelpers/preparedata",
		},
		{
			name:           "The user does not exist",
			input:          "aaa@example.com",
			expectedResult: 0,
			expectedErr:    nil,
			mockDb:         testhelpers.ConnectDB(),
			preparePath:    "../testhelpers/preparedata",
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			// Given
			testhelpers.PrepareDBForTest(tc.mockDb, tc.preparePath)

			userRepo := UserRepo{
				Db: tc.mockDb,
			}

			// When
			result, err := userRepo.GetUserIDByEmail(tc.input)

			// Then
			if tc.expectedErr != nil {
				require.EqualError(t, err, tc.expectedErr.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expectedResult, result)
			}
		})
	}
}

func TestUserRepo_GetEmailsByIDs(t *testing.T) {

	testCases := []struct {
		name           string
		input          []int
		expectedResult []string
		expectedErr    error
		preparePath    string
		mockDb         *sql.DB
	}{
		{
			name:           "Get email list from UserID list success",
			input:          []int{1},
			expectedResult: []string{"test@example.com"},
			expectedErr:    nil,
			mockDb:         testhelpers.ConnectDB(),
			preparePath:    "../testhelpers/preparedata",
		},
		{
			name:           "No data emailsInput",
			input:          []int{},
			expectedResult: []string{},
			expectedErr:    nil,
			mockDb:         testhelpers.ConnectDB(),
			preparePath:    "",
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			// Given
			testhelpers.PrepareDBForTest(tc.mockDb, tc.preparePath)

			userRepo := UserRepo{
				Db: tc.mockDb,
			}

			// When
			result, err := userRepo.GetEmailsByIDs(tc.input)

			// Then
			if tc.expectedErr != nil {
				require.EqualError(t, err, tc.expectedErr.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expectedResult, result)
			}
		})
	}
}
