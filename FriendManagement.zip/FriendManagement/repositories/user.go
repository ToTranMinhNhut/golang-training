package repositories

import (
	"FriendManagement/models/api_model"
	"FriendManagement/models/orm"
	"context"

	"database/sql"
	"log"

	"github.com/volatiletech/sqlboiler/v4/boil"
	"github.com/volatiletech/sqlboiler/v4/queries/qm"
)

type IUserRepo interface {
	CreateUser(*api_model.UserRepository) error
	IsExistedUser(string) (bool, error)
	GetUserIDByEmail(string) (int, error)
	GetEmailsByIDs(userIDs []int) ([]string, error)
}

type UserRepo struct {
	Db *sql.DB
}

func (_self UserRepo) CreateUser(userRepo *api_model.UserRepository) error {
	user := orm.User{
		Email: userRepo.Email,
	}

	if err := user.Insert(context.Background(), _self.Db, boil.Infer()); err != nil {
		return err
	}
	return nil
}

func (_self UserRepo) IsExistedUser(email string) (bool, error) {
	existed, err := orm.Users(qm.Where("email = ?", email)).
		Exists(context.Background(), _self.Db)

	if err != nil {
		return false, err
	}
	if existed {
		return true, nil
	}
	return false, nil
}

func (_self UserRepo) GetUserIDByEmail(email string) (int, error) {
	user, err := orm.Users(
		qm.Select(orm.UserColumns.ID),
		qm.Where("email = ?", email)).
		One(context.Background(), _self.Db)

	if err != nil {
		if err == sql.ErrNoRows {
			return 0, nil
		}
		return 0, err
	}
	return user.ID, nil
}

func (_self UserRepo) GetEmailsByIDs(userIDs []int) ([]string, error) {
	tx, err := _self.Db.Begin()
	if err != nil {
		log.Fatal(err)
	}

	if len(userIDs) == 0 {
		return []string{}, nil
	}

	IDs := make([]interface{}, len(userIDs))
	for i, id := range userIDs {
		IDs[i] = id
	}

	userSlice, err := orm.Users(
		qm.Select(orm.UserColumns.Email),
		qm.WhereIn("id in ?", IDs...)).
		All(context.Background(), _self.Db)

	if err != nil {
		return nil, err
	}

	emails := make([]string, 0)
	for _, u := range userSlice {
		emails = append(emails, u.Email)
	}

	tx.Commit()
	return emails, nil
}
