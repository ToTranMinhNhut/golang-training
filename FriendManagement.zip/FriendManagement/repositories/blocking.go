package repositories

import (
	"context"
	"database/sql"
	"log"

	"FriendManagement/models/api_model"
	"FriendManagement/models/orm"

	"github.com/volatiletech/sqlboiler/v4/boil"
	"github.com/volatiletech/sqlboiler/v4/queries/qm"
)

type IBlockingRepo interface {
	CreateBlocking(*api_model.BlockingRepository) error
	IsExistedBlocking(int, int) (bool, error)
}

type BlockingRepo struct {
	Db *sql.DB
}

func (_self BlockingRepo) CreateBlocking(blocking *api_model.BlockingRepository) error {
	tx, err := _self.Db.Begin()
	if err != nil {
		log.Fatal(err)
	}

	block := orm.Block{
		Requestorid: blocking.Requestor,
		Targetid:    blocking.Target,
	}

	if err := block.Insert(context.Background(), _self.Db, boil.Infer()); err != nil {
		return err
	}

	tx.Commit()
	return nil
}

func (_self BlockingRepo) IsExistedBlocking(requestorID int, targetID int) (bool, error) {
	existed, err := orm.Blocks(qm.Where("requestorid = ?", requestorID), qm.And("targetid = ?", targetID)).
		Exists(context.Background(), _self.Db)

	if err != nil {
		return true, err
	}
	if existed {
		return true, nil
	}
	return false, nil
}
