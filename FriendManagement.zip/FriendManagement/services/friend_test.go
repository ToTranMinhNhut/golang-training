package services

import (
	"FriendManagement/models"
	"errors"
	"testing"

	"github.com/stretchr/testify/require"
)

func TestFriendService_CreateFriend(t *testing.T) {
	testCases := []struct {
		name            string
		input           *models.FriendService
		expError        error
		mockFriendInput *models.FriendRepository
		mockError       error
	}{
		{
			name: "Create friend connection success",
			input: &models.FriendService{
				FirstID:  1,
				SecondID: 2,
			},
			expError: nil,
			mockFriendInput: &models.FriendRepository{
				FirstID:  1,
				SecondID: 2,
			},
			mockError: nil,
		},
		{
			name: "Create friend connection failed with error",
			input: &models.FriendService{
				FirstID:  1,
				SecondID: 2,
			},
			expError: errors.New("create friend connection failed with error"),
			mockFriendInput: &models.FriendRepository{
				FirstID:  1,
				SecondID: 2,
			},
			mockError: errors.New("create friend connection failed with error"),
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockFriendRepo := new(MockFriendRepo)
			mockFriendRepo.On("CreateFriend", tc.mockFriendInput).Return(tc.mockError)

			friendService := FriendService{
				IFriendRepo: mockFriendRepo,
			}

			err := friendService.CreateFriend(tc.input)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
			}

		})
	}
}

func TestFriendService_IsExistedFriend(t *testing.T) {
	testCases := []struct {
		name              string
		firstUserIDInput  int
		secondUserIDInput int
		expResult         bool
		expError          error
		mockFirstUserID   int
		mockSecondUserID  int
		mockResult        bool
		mockError         error
	}{
		{
			name:              "check is existed friend successfully",
			firstUserIDInput:  1,
			secondUserIDInput: 2,
			expResult:         true,
			expError:          nil,
			mockFirstUserID:   1,
			mockSecondUserID:  2,
			mockResult:        true,
			mockError:         nil,
		},
		{
			name:              "check is existed friend failed",
			firstUserIDInput:  1,
			secondUserIDInput: 2,
			expResult:         false,
			expError:          errors.New("query database failed"),
			mockFirstUserID:   1,
			mockSecondUserID:  2,
			mockResult:        false,
			mockError:         errors.New("query database failed"),
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockFriendRepo := new(MockFriendRepo)
			mockFriendRepo.On("IsExistedFriend", tc.mockFirstUserID, tc.mockSecondUserID).Return(tc.mockResult, tc.mockError)

			friendService := FriendService{
				IFriendRepo: mockFriendRepo,
			}

			isExisted, err := friendService.IsExistedFriend(tc.firstUserIDInput, tc.secondUserIDInput)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, isExisted, tc.expResult)
			}
		})
	}
}

func TestFriendService_IsBlockedFriend(t *testing.T) {
	testCases := []struct {
		name              string
		firstUserIDInput  int
		secondUserIDInput int
		expResult         bool
		expError          error
		mockFirstUserID   int
		mockSecondUserID  int
		mockResult        bool
		mockError         error
	}{
		{
			name:              "check is blocked friend successfully",
			firstUserIDInput:  1,
			secondUserIDInput: 2,
			expResult:         true,
			expError:          nil,
			mockFirstUserID:   1,
			mockSecondUserID:  2,
			mockResult:        true,
			mockError:         nil,
		},
		{
			name:              "check is blocked friend failed",
			firstUserIDInput:  1,
			secondUserIDInput: 2,
			expResult:         false,
			expError:          errors.New("query database failed"),
			mockFirstUserID:   1,
			mockSecondUserID:  2,
			mockResult:        false,
			mockError:         errors.New("query database failed"),
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockFriendRepo := new(MockFriendRepo)
			mockFriendRepo.On("IsBlockedFriend", tc.mockFirstUserID, tc.mockSecondUserID).
				Return(tc.mockResult, tc.mockError)

			friendService := FriendService{
				IFriendRepo: mockFriendRepo,
			}

			blocked, err := friendService.IsBlockedFriend(tc.firstUserIDInput, tc.secondUserIDInput)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, blocked, tc.expResult)
			}
		})
	}
}

func TestFriendService_GetFriendsByID(t *testing.T) {
	type mockGetFriendsByID struct {
		input  int
		result []int
		err    error
	}
	type mockGetBlockingFriendsByID struct {
		input  int
		result []int
		err    error
	}
	type mockGetBlockedFriendsByID struct {
		input  int
		result []int
		err    error
	}
	type mockGetEmailsByIDs struct {
		input  []int
		result []string
		err    error
	}

	testCases := []struct {
		name                   string
		input                  int
		expectedResult         []string
		expectedErr            error
		mockGetFriends         mockGetFriendsByID
		mockGetBlockingFriends mockGetBlockingFriendsByID
		mockGetBlockedFriends  mockGetBlockedFriendsByID
		mockGetEmails          mockGetEmailsByIDs
	}{
		// 	{
		// 		name:           "Get friends list failed with error",
		// 		input:          1,
		// 		expectedResult: nil,
		// 		expectedErr:    errors.New("get friends list failed with error"),
		// 		mockGetFriendsList: mockGetFriendListByID{
		// 			input:  1,
		// 			result: nil,
		// 			err:    errors.New("get friends list failed with error"),
		// 		},
		// 	},
		// 	{
		// 		name:           "get blocked list failed",
		// 		input:          1,
		// 		expectedResult: nil,
		// 		expectedErr:    errors.New("get blocked list failed with error"),
		// 		mockGetFriendsList: mockGetFriendListByID{
		// 			input:  1,
		// 			result: []int{2},
		// 			err:    nil,
		// 		},
		// 		mockGetBlockedList: mockGetBlockedListByID{
		// 			input:  1,
		// 			result: []int{3},
		// 			err:    errors.New("get blocked list failed with error"),
		// 		},
		// 	},
		// 	{
		// 		name:           "get blocking list failed",
		// 		input:          1,
		// 		expectedResult: nil,
		// 		expectedErr:    errors.New("get blocking list failed with error"),
		// 		mockGetFriendsList: mockGetFriendListByID{
		// 			input:  1,
		// 			result: []int{2},
		// 			err:    nil,
		// 		},
		// 		mockGetBlockedList: mockGetBlockedListByID{
		// 			input:  1,
		// 			result: []int{3},
		// 			err:    nil,
		// 		},
		// 		mockGetBlockingList: mockGetBlockingListByID{
		// 			input:  1,
		// 			result: nil,
		// 			err:    errors.New("get blocking list failed with error"),
		// 		},
		// 	},
		// 	{
		// 		name:           "Get email list by IDs failed with error",
		// 		input:          1,
		// 		expectedResult: nil,
		// 		expectedErr:    errors.New("get email list by userIDs failed with error"),
		// 		mockGetFriendsList: mockGetFriendListByID{
		// 			input:  1,
		// 			result: []int{2, 3, 4, 5},
		// 			err:    nil,
		// 		},
		// 		mockGetBlockedList: mockGetBlockedListByID{
		// 			input:  1,
		// 			result: []int{3},
		// 			err:    nil,
		// 		},
		// 		mockGetBlockingList: mockGetBlockingListByID{
		// 			input:  1,
		// 			result: []int{4},
		// 			err:    nil,
		// 		},
		// 		mockGetEmailList: mockGetEmailListByIDs{
		// 			input:  []int{2, 5},
		// 			result: nil,
		// 			err:    errors.New("get email list by userIDs failed with error"),
		// 		},
		// 	},
		// 	{
		// 		name:           "Get friend connection list success",
		// 		input:          1,
		// 		expectedResult: []string{"xyz@xyz.com", "xyzk@abc.com"},
		// 		expectedErr:    nil,
		// 		mockGetFriendsList: mockGetFriendListByID{
		// 			input:  1,
		// 			result: []int{2, 3, 4, 5},
		// 			err:    nil,
		// 		},
		// 		mockGetBlockedList: mockGetBlockedListByID{
		// 			input:  1,
		// 			result: []int{3},
		// 			err:    nil,
		// 		},
		// 		mockGetBlockingList: mockGetBlockingListByID{
		// 			input:  1,
		// 			result: []int{4},
		// 			err:    nil,
		// 		},
		// 		mockGetEmailList: mockGetEmailListByIDs{
		// 			input:  []int{2, 5},
		// 			result: []string{"xyz@xyz.com", "xyzk@abc.com"},
		// 			err:    nil,
		// 		},
		// 	},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockFriendRepo := new(MockFriendRepo)
			mockUserRepo := new(MockUserRepo)
			mockFriendRepo.On("GetFriendsByID", tc.mockGetFriends.err).
				Return(tc.mockGetFriends.result, tc.mockGetFriends.err)

			mockFriendRepo.On("GetBlockingFriendsByID", tc.mockGetBlockingFriends.input).
				Return(tc.mockGetBlockingFriends.result, tc.mockGetBlockingFriends.err)

			mockFriendRepo.On("GetBlockedFriendsByID", tc.mockGetBlockedFriends.input).
				Return(tc.mockGetBlockedFriends.result, tc.mockGetBlockedFriends.err)

			mockFriendRepo.On("GetEmailsByIDs", tc.mockGetEmails.input).
				Return(tc.mockGetEmails.result, tc.mockGetEmails.err)

			friendService := FriendService{
				IUserRepo:   mockUserRepo,
				IFriendRepo: mockFriendRepo,
			}

			result, err := friendService.GetFriendsByID(tc.input)

			if tc.expectedErr != nil {
				require.EqualError(t, err, tc.expectedErr.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expectedResult, result)
			}
		})
	}

}

// func TestFriendService_GetCommonFriendsByIDs(userIDList []int) ([]string, error) {
// 	type mockGetFriendListByID struct {
// 		input  int
// 		result []int
// 		err    error
// 	}
// 	type mockGetBlockedListByID struct {
// 		input  int
// 		result []int
// 		err    error
// 	}
// 	type mockGetBlockingListByID struct {
// 		input  int
// 		result []int
// 		err    error
// 	}
// 	type mockGetEmailListByIDs struct {
// 		input  []int
// 		result []string
// 		err    error
// 	}
// }

// GetEmailsReceiveUpdate(senderID int, text string) ([]string, error)
