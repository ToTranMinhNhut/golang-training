package handlers

import (
	"bytes"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"FriendManagement/models/api_model"

	"github.com/stretchr/testify/require"
)

func TestBlockingHander_CreateBlocking(t *testing.T) {
	type mockGetUserIDByEmail struct {
		input  string
		result int
		err    error
	}

	type mockIsExistedBlocking struct {
		requestorID int
		targetID    int
		result      bool
		err         error
	}

	type mockCreateBlocking struct {
		input *api_model.BlockingService
		err   error
	}

	testCases := []struct {
		name                      string
		requestBody               interface{}
		expResponseBody           string
		expResponseStatus         int
		mockGetRequestorUserID    mockGetUserIDByEmail
		mockGetTargetUserID       mockGetUserIDByEmail
		mockIsExistedBlocking     mockIsExistedBlocking
		mockCreateBlockingService mockCreateBlocking
	}{
		{
			name: "Create success",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
				"target":    "test@example.com",
			},
			expResponseBody:   "{\"success\":true}\n",
			expResponseStatus: http.StatusOK,
			mockGetRequestorUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetTargetUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 2,
				err:    nil,
			},
			mockIsExistedBlocking: mockIsExistedBlocking{
				requestorID: 1,
				targetID:    2,
				result:      false,
				err:         nil,
			},
			mockCreateBlockingService: mockCreateBlocking{
				input: &api_model.BlockingService{
					Requestor: 1,
					Target:    2,
				},
				err: nil,
			},
		},
		{
			name: "Create failed with error",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
				"target":    "test@example.com",
			},
			expResponseBody:   "create blocking failed with error\n",
			expResponseStatus: http.StatusInternalServerError,
			mockGetRequestorUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetTargetUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 2,
				err:    nil,
			},
			mockIsExistedBlocking: mockIsExistedBlocking{
				requestorID: 1,
				targetID:    2,
				result:      false,
				err:         nil,
			},
			mockCreateBlockingService: mockCreateBlocking{
				input: &api_model.BlockingService{
					Requestor: 1,
					Target:    2,
				},
				err: errors.New("create blocking failed with error"),
			},
		},
		{
			name: "Body no data",
			requestBody: map[string]interface{}{
				"": "",
			},
			expResponseBody:   "\"requestor\" is required\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "No target email",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
			},
			expResponseBody:   "\"target\" is required\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "Requestor email is invalid",
			requestBody: map[string]interface{}{
				"requestor": "andy",
				"target":    "test@example.com",
			},
			expResponseBody:   "\"requestor\" format is not valid. (ex: \"andy@example.com\")\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "Target email is invalid",
			requestBody: map[string]interface{}{
				"requestor": "test@example.com",
				"target":    "andy",
			},
			expResponseBody:   "\"target\" format is not valid. (ex: \"andy@example.com\")\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "Two email addresses must be different",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
				"target":    "andy@example.com",
			},
			expResponseBody:   "two email addresses must be different\n",
			expResponseStatus: http.StatusBadRequest,
		},
		{
			name: "Get requestor user ID failed with error",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
				"target":    "test@example.com",
			},
			expResponseBody:   "get requestor userID failed with error\n",
			expResponseStatus: http.StatusInternalServerError,
			mockGetRequestorUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 0,
				err:    errors.New("get requestor userID failed with error"),
			},
		},
		{
			name: "Get target user ID failed with error",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
				"target":    "test@example.com",
			},
			expResponseBody:   "get target userID failed with error\n",
			expResponseStatus: http.StatusInternalServerError,
			mockGetRequestorUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetTargetUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 0,
				err:    errors.New("get target userID failed with error"),
			},
		},
		{
			name: "Requestor userID is not exist",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
				"target":    "test@example.com",
			},
			expResponseBody:   "the requestor does not exist\n",
			expResponseStatus: http.StatusBadRequest,
			mockGetRequestorUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 0,
				err:    nil,
			},
		},
		{
			name: "Target userID is not exist",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
				"target":    "test@example.com",
			},
			expResponseBody:   "the target does not exist\n",
			expResponseStatus: http.StatusBadRequest,
			mockGetRequestorUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetTargetUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 0,
				err:    nil,
			},
		},
		{
			name: "Existed blocking",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
				"target":    "test@example.com",
			},
			expResponseBody:   "target's email have already been blocked by requestor's email\n",
			expResponseStatus: http.StatusPreconditionFailed,
			mockGetRequestorUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetTargetUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 2,
				err:    nil,
			},
			mockIsExistedBlocking: mockIsExistedBlocking{
				requestorID: 1,
				targetID:    2,
				result:      true,
				err:         nil,
			},
		},
		{
			name: "Check exist blocking failed with error",
			requestBody: map[string]interface{}{
				"requestor": "andy@example.com",
				"target":    "test@example.com",
			},
			expResponseBody:   "failed with error\n",
			expResponseStatus: http.StatusInternalServerError,
			mockGetRequestorUserID: mockGetUserIDByEmail{
				input:  "andy@example.com",
				result: 1,
				err:    nil,
			},
			mockGetTargetUserID: mockGetUserIDByEmail{
				input:  "test@example.com",
				result: 2,
				err:    nil,
			},
			mockIsExistedBlocking: mockIsExistedBlocking{
				requestorID: 1,
				targetID:    2,
				result:      false,
				err:         errors.New("failed with error"),
			},
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockBlockingService := new(MockBlockingService)
			mockUserService := new(MockUserService)

			mockUserService.On("GetUserIDByEmail", tc.mockGetRequestorUserID.input).
				Return(tc.mockGetRequestorUserID.result, tc.mockGetRequestorUserID.err)

			mockUserService.On("GetUserIDByEmail", tc.mockGetTargetUserID.input).
				Return(tc.mockGetTargetUserID.result, tc.mockGetTargetUserID.err)

			mockBlockingService.On("IsExistedBlocking", tc.mockIsExistedBlocking.requestorID, tc.mockIsExistedBlocking.targetID).
				Return(tc.mockIsExistedBlocking.result, tc.mockIsExistedBlocking.err)

			mockBlockingService.On("CreateBlocking", tc.mockCreateBlockingService.input).
				Return(tc.mockCreateBlockingService.err)

			blockingHander := BlockingHandler{
				IBlockingService: mockBlockingService,
				IUserService:     mockUserService,
			}

			requestBody, err := json.Marshal(tc.requestBody)
			if err != nil {
				t.Error(err)
			}

			request, err := http.NewRequest(http.MethodPost, "/blocking/create", bytes.NewBuffer(requestBody))
			if err != nil {
				t.Error(err)
			}

			responseRecorder := httptest.NewRecorder()
			handler := http.HandlerFunc(blockingHander.CreateBlocking)
			handler.ServeHTTP(responseRecorder, request)

			require.Equal(t, tc.expResponseStatus, responseRecorder.Code)
			require.Equal(t, tc.expResponseBody, responseRecorder.Body.String())
		})
	}
}
