package main

import (
	"bookstoreupdate/pkg/application"
	"bookstoreupdate/pkg/handlers/errors"

	"github.com/go-chi/chi/v5"
)

func registerRoutes(app *application.Application) *chi.Mux {
	mux := chi.NewRouter()
	mux.MethodNotAllowed(errors.MethodNotAllowedHandler)
	mux.NotFound(errors.NotFoundHandler)
	db := app.DB
	mux.Route("/books", func(mux chi.Router) {
		mux.Post("/create", app.BookHander.CreateBook(db))
		mux.Route("/{bookid}", func(mux chi.Router) {
			mux.Use(app.BookHander.BookContext)
			mux.Get("/", app.BookHander.GetBook(db))
		})
	})

	return mux
}
