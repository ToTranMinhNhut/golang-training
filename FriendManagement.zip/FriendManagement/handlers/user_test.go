package handlers

import "net/http"

func CreateUser(w http.ResponseWriter, r *http.Request) {
}
