TRUNCATE TABLE users, friends, subscriptions, blocks;

alter sequence users_id_seq RESTART WITH 1;
alter sequence friends_id_seq RESTART WITH 1;
alter sequence subscriptions_id_seq RESTART WITH 1;
alter sequence blocks_id_seq RESTART WITH 1;

INSERT INTO users(email) VALUES ('andy@example.com');
INSERT INTO users(email) VALUES ('test@example.com');
INSERT INTO users(email) VALUES ('test1@example.com');
INSERT INTO users(email) VALUES ('test2@example.com');

INSERT INTO friends(firstid, secondid) VALUES (1, 2);
INSERT INTO subscriptions(requestorid, targetid) VALUES (3, 1);
INSERT INTO blocks(requestorid, targetid) VALUES (1, 4);