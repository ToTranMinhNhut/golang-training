package repositories

import (
	"errors"
	"testing"

	"FriendManagement/models/api_model"
	"FriendManagement/testhelpers"

	"github.com/stretchr/testify/require"
)

func TestUsersRepo_CreateUser(t *testing.T) {
	testCases := []struct {
		name        string
		input       *api_model.UserRepository
		expectedErr error
		preparePath string
	}{
		{
			name: "Create user success",
			input: &api_model.UserRepository{
				Email: "andy@example.com",
			},
			expectedErr: nil,
			preparePath: "../testhelpers/data_dump/user/truncate_users.sql",
		},
		{
			name: "Create new user failed with error",
			input: &api_model.UserRepository{
				Email: "test@example.com",
			},

			expectedErr: errors.New("orm: unable to insert into users: pq: duplicate key value violates unique constraint \"constraint_email\""),
			preparePath: "../testhelpers/data_dump/user/user.sql",
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockDB := testhelpers.ConnectDB()
			testhelpers.PrepareDBForTest(mockDB, tc.preparePath)

			userRepo := UserRepo{
				Db: mockDB,
			}

			err := userRepo.CreateUser(tc.input)

			if tc.expectedErr != nil {
				require.EqualError(t, err, tc.expectedErr.Error())
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestUserRepo_IsExistedUser(t *testing.T) {
	testCases := []struct {
		name        string
		input       string
		expResult   bool
		expError    error
		preparePath string
	}{
		{
			name:        "Check user exists success",
			input:       "test@example.com",
			expResult:   true,
			expError:    nil,
			preparePath: "../testhelpers/data_dump/user/user.sql",
		},
		{
			name:        "User is not exists",
			input:       "test@example.com",
			expResult:   false,
			expError:    nil,
			preparePath: "../testhelpers/data_dump/user/truncate_users.sql",
		},
	}
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockDB := testhelpers.ConnectDB()
			testhelpers.PrepareDBForTest(mockDB, tc.preparePath)

			userRepo := UserRepo{
				Db: mockDB,
			}

			result, err := userRepo.IsExistedUser(tc.input)
			if tc.expError != nil {
				require.Equal(t, err, tc.expError)
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expResult, result)
			}
		})
	}
}

func TestUserRepo_GetUserIDByEmail(t *testing.T) {
	testCases := []struct {
		name           string
		input          string
		expectedResult int
		expectedErr    error
		preparePath    string
	}{
		{
			name:           "Get UserID by email success",
			input:          "test@example.com",
			expectedResult: 1,
			expectedErr:    nil,
			preparePath:    "../testhelpers/data_dump/user/user.sql",
		},
		{
			name:           "The user does not exist",
			input:          "aaa@example.com",
			expectedResult: 0,
			expectedErr:    nil,
			preparePath:    "../testhelpers/data_dump/user/truncate_users.sql",
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockDB := testhelpers.ConnectDB()
			testhelpers.PrepareDBForTest(mockDB, tc.preparePath)

			userRepo := UserRepo{
				Db: mockDB,
			}

			result, err := userRepo.GetUserIDByEmail(tc.input)

			if tc.expectedErr != nil {
				require.EqualError(t, err, tc.expectedErr.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expectedResult, result)
			}
		})
	}
}

func TestUserRepo_GetEmailsByIDs(t *testing.T) {
	testCases := []struct {
		name           string
		input          []int
		expectedResult []string
		expectedErr    error
		preparePath    string
	}{
		{
			name:           "Get email list from UserID list success",
			input:          []int{1, 2},
			expectedResult: []string{"test@example.com", "andy@example.com"},
			expectedErr:    nil,
			preparePath:    "../testhelpers/data_dump/user/user.sql",
		},
		{
			name:           "No data emails Input",
			input:          []int{},
			expectedResult: []string{},
			expectedErr:    nil,
			preparePath:    "../testhelpers/data_dump/user/user.sql",
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockDB := testhelpers.ConnectDB()
			testhelpers.PrepareDBForTest(mockDB, tc.preparePath)

			userRepo := UserRepo{
				Db: mockDB,
			}

			result, err := userRepo.GetEmailsByIDs(tc.input)

			if tc.expectedErr != nil {
				require.EqualError(t, err, tc.expectedErr.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expectedResult, result)
			}
		})
	}
}
