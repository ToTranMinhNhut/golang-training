package application

import (
	"bookstoreupdate/pkg/config"
	"bookstoreupdate/pkg/db"
	"bookstoreupdate/pkg/handlers"
	"log"
)

type Application struct {
	BookHander *handlers.BookHander
	DB         *db.DB
	Cfg        *config.Config
}

func New(bookHander *handlers.BookHander) (*Application, error) {
	handler := bookHander
	cfg := config.Get()
	db, err := db.Get(cfg.GetDBConnStr())
	if err != nil {
		return nil, err
	}

	log.Println("Successfully connect to database!!!")
	return &Application{
		DB:         db,
		Cfg:        cfg,
		BookHander: handler,
	}, nil
}
