package handler

import (
	"bookstore/db"
	"bookstore/models"
	"context"
	"fmt"
	"net/http"
	"strconv"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/render"
)

var BookIdKey = "bookid"

func books(router chi.Router) {
	// router.Get("/", getAllItems)
	router.Post("/create", createBook)
	router.Route("/{bookid}", func(router chi.Router) {
		router.Use(BookContext)
		router.Get("/", getBook)
	})
}
func BookContext(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		bookId := chi.URLParam(r, "bookid")
		if bookId == "" {
			render.Render(w, r, ErrorRenderer(fmt.Errorf("book ID is required")))
			return
		}

		id, err := strconv.Atoi(bookId)
		if err != nil {
			render.Render(w, r, ErrorRenderer(fmt.Errorf("invalid book ID")))
		}
		ctx := context.WithValue(r.Context(), BookIdKey, id)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

func createBook(w http.ResponseWriter, r *http.Request) {
	item := &models.Book{}
	if err := render.Bind(r, item); err != nil {
		render.Render(w, r, ErrBadRequest)
		return
	}
	if err := dbInstance.AddBook(item); err != nil {
		render.Render(w, r, ErrorRenderer(err))
		return
	}
	if err := render.Render(w, r, item); err != nil {
		render.Render(w, r, ServerErrorRenderer(err))
		return
	}
}

// func getAllItems(w http.ResponseWriter, r *http.Request) {
// 	items, err := dbInstance.GetAllItems()
// 	if err != nil {
// 		render.Render(w, r, ServerErrorRenderer(err))
// 		return
// 	}
// 	if err := render.Render(w, r, items); err != nil {
// 		render.Render(w, r, ErrorRenderer(err))
// 	}
// }

func getBook(w http.ResponseWriter, r *http.Request) {
	BookId := r.Context().Value(BookIdKey).(int)
	book, err := dbInstance.GetBookById(BookId)
	if err != nil {
		if err == db.ErrNoMatch {
			render.Render(w, r, ErrNotFound)
		} else {
			render.Render(w, r, ErrorRenderer(err))
		}
		return
	}
	if err := render.Render(w, r, &book); err != nil {
		render.Render(w, r, ServerErrorRenderer(err))
		return
	}
}
