package book

// import (
// 	"bookstoreupdate/cmd/book/services/book"

// 	"github.com/go-chi/chi/v5"
// )

// func GetBookRouter(mux chi.Router) {
// 	mux.Route("/{bookid}", func(router chi.Router) {
// 		router.Use(book.BookContext)
// 		router.Get("/", book.)
// 	})

// }
