package services

import (
	"FriendManagement/models"
	"errors"
	"testing"

	"github.com/stretchr/testify/require"
)

func TestBlockingService_CreateBlocking(t *testing.T) {
	testCases := []struct {
		name                  string
		input                 *models.BlockingService
		expError              error
		mockBlockingRepoInput *models.BlockingRepository
		mockError             error
	}{
		{
			name: "Create blocking is success",
			input: &models.BlockingService{
				Requestor: 1,
				Target:    2,
			},
			expError: nil,
			mockBlockingRepoInput: &models.BlockingRepository{
				Requestor: 1,
				Target:    2,
			},
			mockError: nil,
		},
		{
			name: "Create blocking failed with error",
			input: &models.BlockingService{
				Requestor: 1,
				Target:    2,
			},
			expError: errors.New("create blocking failed with error"),
			mockBlockingRepoInput: &models.BlockingRepository{
				Requestor: 1,
				Target:    2,
			},
			mockError: errors.New("create blocking failed with error"),
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockBlockingRepo := new(MockBlockingRepo)
			mockBlockingRepo.On("CreateBlocking", tc.mockBlockingRepoInput).
				Return(tc.mockError)

			blockingService := BlockingService{
				IBlockingRepo: mockBlockingRepo,
			}

			err := blockingService.CreateBlocking(tc.input)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestBlockingService_IsExistedBlocking(t *testing.T) {
	testCases := []struct {
		name            string
		requestorID     int
		targetID        int
		expResult       bool
		expError        error
		mockRequestorID int
		mockTargetID    int
		mockResult      bool
		mockError       error
	}{
		{
			name:            "Verify is existed blocking friend success",
			requestorID:     1,
			targetID:        2,
			expResult:       true,
			expError:        nil,
			mockRequestorID: 1,
			mockTargetID:    2,
			mockResult:      true,
			mockError:       nil,
		},
		{
			name:            "Verify is existed blocking friend failed with error",
			requestorID:     1,
			targetID:        2,
			expResult:       false,
			expError:        errors.New("Verify is existed blocking friend failed with error"),
			mockRequestorID: 1,
			mockTargetID:    2,
			mockResult:      false,
			mockError:       errors.New("Verify is existed blocking friend failed with error"),
		},
	}
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockBlockingRepo := new(MockBlockingRepo)
			mockBlockingRepo.On("IsExistedBlocking", tc.mockRequestorID, tc.mockTargetID).
				Return(tc.mockResult, tc.mockError)

			blockingService := BlockingService{
				IBlockingRepo: mockBlockingRepo,
			}

			result, err := blockingService.IsExistedBlocking(tc.requestorID, tc.targetID)

			if tc.expError != nil {
				require.EqualError(t, err, tc.expError.Error())
			} else {
				require.NoError(t, err)
				require.Equal(t, tc.expResult, result)
			}
		})
	}
}
