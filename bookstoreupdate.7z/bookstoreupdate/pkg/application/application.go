package application

import (
	"bookstoreupdate/pkg/config"
	"bookstoreupdate/pkg/db"
	"log"
)

type Application struct {
	DB  *db.DB
	Cfg *config.Config
}

func Get() (*Application, error) {
	cfg := config.Get()
	db, err := db.Get(cfg.GetDBConnStr())

	if err != nil {
		return nil, err
	}
	log.Println("Successfully connect to database!!!")
	return &Application{
		DB:  db,
		Cfg: cfg,
	}, nil
}
